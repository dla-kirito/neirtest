April 6, 2021 

You can now link discussions to new releases!

When drafting a new release, check the `Create a discussion for this release` box, choose a category, and publish. Your community will be able to react and comment on the release notes, giving projects more opportunities to celebrate and receive feedback. Release discussions are also available natively on [GitHub Mobile](https://docs.github.com/en/github/getting-started-with-github/github-for-mobile). 

![enable discussion creation on a release](https://i0.wp.com/user-images.githubusercontent.com/1923260/113341794-76e64a00-92e2-11eb-9d35-3f843d0a313c.png?w=1208&ssl=1)

For more information, see [GitHub Discussions](https://docs.github.com/en/discussions), [GitHub Releases](https://docs.github.com/en/github/administering-a-repository/about-releases) and [GitHub Mobile](https://docs.github.com/en/github/getting-started-with-github/github-for-mobile) documentation.

For questions or feedback, join the conversation in [GitHub Product Feedback](https://github.com/github/feedback/discussions).