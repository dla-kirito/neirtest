May 13, 2020 

As a GitHub Enterprise Server customer, you can now access your Enterprise Server licenses on GitHub. With this change, you no longer need to login to the Enterprise Server license management portal. The new license management provides better support for billing and organization managers to manage their licenses, create support tickets, and upload support bundles on GitHub.