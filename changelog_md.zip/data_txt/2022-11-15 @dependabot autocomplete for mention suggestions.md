November 15, 2022 

Dependabot is a friendly co-developer supporting millions of repositories, but previously wasn't included in mention suggestions.

Starting today, you can more easily mention Dependabot, thanks to autocomplete.

![Dependabot Autocomplete](https://i0.wp.com/user-images.githubusercontent.com/5788563/201985664-df77bb44-c355-4eec-85a9-239302d76f04.png?ssl=1)