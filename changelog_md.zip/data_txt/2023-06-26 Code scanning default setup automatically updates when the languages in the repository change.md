June 26, 2023 

Code scanning default setup now automatically updates when the languages in a repository change.

If a repository that uses default setup changes to include the languages JavaScript/TypeScript, Ruby, Python, or Go, the configuration will automatically update to include these languages. If the new configuration fails, we’ll resume the previous configuration automatically so that the repository does not lose coverage. The configuration will also automatically update if a repository removes a language.

You can always view the repository’s default setup configuration from the Code security and analysis settings page. Additionally, you can use the [tool status page](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-the-tool-status-page) to view useful information about your setup and debug any failed languages.

Default set up makes it easy to get started with code scanning. The supported languages are currently JavaScript/TypeScript, Python, Ruby and Go and the list is constantly evolving. For more information on code scanning default setup, see [Configuring code scanning automatically](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/configuring-code-scanning-for-a-repository#configuring-code-scanning-automatically).