October 26, 2022 

![a photo of a devcontainer.json with openFiles, postAttachCommand, and onAutoForward defined](https://i0.wp.com/user-images.githubusercontent.com/55998770/198056008-95229431-8683-47b9-8e71-8e0f7d3a080d.png?w=501&ssl=1)

A development container allows you to create a full-featured development environment to use in your codespace. Codespaces use the `devcontainer.json` file to define the environment you will be working in within your codespace. We've added new features to `devcontainers.json` to help you customize the initial experience when you open a codespace.

## Define the initial layout of your codespace with `openFiles`[](#define-the-initial-layout-of-your-codespace-with-openfiles)

You can use `openFiles` to define what files are open by default. If you specify multiple files, the files will open up in order from left to right. The first file defined will be the focused file. `openFiles` is specific to the Codespaces customization, and is only enabled in the Codespaces web editor for now. Use `openFiles` to improve your default development environment and ensure that you're setting contributors up for success!

## Run scripts after your client connects to your codespace with `postAttachCommand`[](#run-scripts-after-your-client-connects-to-your-codespace-with-postattachcommand)

`postAttachCommand` enables you to run scripts in the terminal after your client connects to the codespace. This change enables you to define multiple `postAttachCommand` definitions and they will run on separate terminals. This enables you to start your server and watch for changing files after launch from your `devcontainer.json`.

## Combine these features into a full initial codespace experience[](#combine-these-features-into-a-full-initial-codespace-experience)

These changes to `postAttachCommand`, combined with the existing `openPreview` option in the `onAutoForward` property, enable you to create codespaces with a default layout that ensures a great Codespaces launch experience for users of your repository.

Read more about [postAttachCommand](https://containers.dev/implementors/json%5Freference/#lifecycle-scripts), [onAutoForward](https://containers.dev/implementors/json%5Freference/#port-attributes), [openFiles](https://docs.github.com/codespaces/setting-up-your-project-for-codespaces/automatically-opening-files-in-the-codespaces-for-a-repository), and [openPreview](https://containers.dev/implementors/json%5Freference/#port-attributes) on our docs pages!