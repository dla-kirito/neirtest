August 10, 2021 

As [previously announced](https://github.blog/changelog/2021-04-19-sunsetting-api-authentication-via-query-parameters-and-the-oauth-applications-api/), on August 11 2021 at 14:00 UTC, GitHub will be removing the OAuth Application API to avoid unintentional logging of in-transit access tokens.

Please refer to this [blog post](https://developer.github.com/changes/2020-02-14-deprecating-oauth-app-endpoint) on migrating to the replacement endpoints.

#### Removal[](#removal)

* August 11 2021 at 14:00 UTC

Please check the latest [Enterprise release](https://enterprise.github.com/releases/) notes to learn in which version the OAuth Application API will be removed.