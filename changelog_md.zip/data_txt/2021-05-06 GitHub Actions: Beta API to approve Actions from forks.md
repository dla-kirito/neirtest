May 6, 2021 

You can now use a Beta API to approve workflow runs from public forks of first time contributors.

[Learn more about using this API](https://docs.github.com/rest/reference/actions#approve-a-workflow-run-for-a-fork-pull-request)

[Learn more about approving first time contributor pull requests](https://docs.github.com/en/actions/managing-workflow-runs/approving-workflow-runs-from-public-forks)