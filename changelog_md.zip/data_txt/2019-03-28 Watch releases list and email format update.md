March 28, 2019 

Releases are now listed on <https://github.com/watching> so you can easily unwatch releases you no longer want to be notified about.

The email format for Releases has been updated so you can more easily distinguish Release notifications from other GitHub activity.

[Learn more about the watch releases list](https://help.github.com/en/articles/listing-the-repositories-youre-watching)