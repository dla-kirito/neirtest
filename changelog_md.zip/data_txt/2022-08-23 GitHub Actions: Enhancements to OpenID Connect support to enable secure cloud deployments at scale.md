August 23, 2022 

OpenID Connect (OIDC) support in GitHub Actions is now enhanced to support secure cloud deployments at scale.

Org & repo admins can use the new [OIDC API support](https://docs.github.com/en/rest/actions/oidc) to:

* enable a standard OIDC configuration across their cloud deployment workflows by customizing the `subject` claim format.
* ensure additional compliance & security for their OIDC based deployments by appending the `issuer` url with their enterprise slug
* configure advanced OIDC policies by using the additional [OIDC token claims](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect#understanding-the-oidc-token) like `repository_id` and `repo_visibility`.

Learn more about [Security hardening your GitHub Workflows using OpenID Connect](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments).