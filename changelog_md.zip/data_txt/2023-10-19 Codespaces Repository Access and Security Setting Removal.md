October 19, 2023 

On December 21st, 2023 GitHub Codespaces plans to remove the deprecated [Repository Access and Security setting](https://docs.github.com/en/codespaces/managing-codespaces-for-your-organization/managing-repository-access-for-your-organizations-codespaces).

![repository-access-setting-disabled](https://i0.wp.com/user-images.githubusercontent.com/4679612/275510393-b13a7879-3fb4-4ac8-80f6-6c75a1cfb5e3.png?ssl=1)

Rather than configuring cross-repository access at the account level, we now recommend declaring cross-repository dependencies and permissions [directly within your devcontainer.json](https://docs.github.com/en/codespaces/managing-your-codespaces/managing-repository-access-for-your-codespaces#setting-additional-repository-permissions). This approach enables each development container to declare its own minimum set of permissions to operate, rather than allowing unrestricted access to other repositories your account can access.

This change will impact users and organizations that have set the Repository Access and Security setting to either selected or all repositories, and have not configured any development container level permissions. You will receive an email if you or any organizations you own may be impacted by this change.

To ensure continuity of usage, you will need to declare [cross-repository permissions within each devcontainer.json](https://docs.github.com/en/codespaces/managing-your-codespaces/managing-repository-access-for-your-codespaces#setting-additional-repository-permissions), enabling access to each repository that a development container needs to access. You can test that you have successfully transferred all permissions by toggling the Access and Security setting to **Selected Repositories** and removing all entries once you have completed the conversion.

Please reach out to GitHub Support if you have any issues or questions.

### Additional References[](#additional-references)

* [Repository Access and Security setting for personal accounts](https://docs.github.com/en/codespaces/managing-your-codespaces/managing-repository-access-for-your-codespaces#access-and-security)
* [Repository Access and Security setting for organizations](https://docs.github.com/en/enterprise-cloud@latest/codespaces/managing-codespaces-for-your-organization/managing-repository-access-for-your-organizations-codespaces)
* [Managing repository access with the devcontainer.json file](https://docs.github.com/en/codespaces/managing-your-codespaces/managing-repository-access-for-your-codespaces#setting-additional-repository-permissions)