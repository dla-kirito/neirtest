May 4, 2023 

If you are an organization or enterprise owner, you will now receive a secret scanning summary email when the historical scan completes. The email notification will tell you how many, if any, secrets were detected across all repositories within your organization or enterprise. You'll also receive a link to your security overview page for each secret, where you can view details for each detected secret.

Previously, secret scanning would send one email per repository where secrets were detected, provided that you were watching the repository and had email notifications enabled in your user settings enabled. While repository administrators will still receive an email notification per repository, organization and enterprise owners will now receive only a single notification upon the historical scan's completion.

To receive notifications:

* For the first historical scan after you enable secret scanning, you must have [email notifications enabled](https://github.blog/changelog/2023-03-17-secret-scanning-changes-to-how-you-opt-in-to-notifications/) in your user settings. You do not need to watch any repositories to receive the secret scanning summary email.
* For future historical scans, such as for newly added patterns, you will receive an email notification for each repository where a secret was found. You must be watching the repository where the secret was detected and have email notifications enabled in your user settings.

![summary email after backfill scan](https://i0.wp.com/user-images.githubusercontent.com/81782111/235810096-fb4eb0ac-1db6-4f1e-a3ca-257113798156.png?w=466&ssl=1)

* [Learn more about secret scanning](https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning)
* Got feedback? Open a discussion in our [code security discussion](https://github.com/orgs/community/discussions/categories/code-security)