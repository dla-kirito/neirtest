January 15, 2019 

The 2.15.5, 2.14.12 and 2.13.18 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

View the full release notes:

* [See Enterprise 2.15.5 release notes](https://enterprise.github.com/releases/2.15.5/notes)
* [See Enterprise 2.14.12 release notes](https://enterprise.github.com/releases/2.14.12/notes)
* [See Enterprise 2.13.18 release notes](https://enterprise.github.com/releases/2.13.18/notes)