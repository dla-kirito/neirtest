June 7, 2021 

If your organization uses [IP allow lists](https://docs.github.com/en/organizations/keeping-your-organization-secure/managing-allowed-ip-addresses-for-your-organization) to restrict access, any API requests made with an installation access token for a GitHub App installed on your organization already respects those settings.

GitHub is extending this so that the API request to [create the installation access token](https://docs.github.com/en/rest/reference/apps#create-an-installation-access-token-for-an-app) will also respect your organization's allowed IP addresses.