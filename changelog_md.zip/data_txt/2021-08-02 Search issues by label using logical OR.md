August 2, 2021 

You can now search issues by label using logical OR. Simply use a comma to separate the labels. For example `label:"good first issue",bug` will list all issues with a label `good first issue` or `bug`.