April 28, 2022 

We continue to iterate and address your feedback for GitHub projects (beta) and in this week's Changelog we are including improvements to our settings and insights features.

### ⚙️ Create and delete fields from the Settings page[](#⚙️-create-and-delete-fields-from-the-settings-page)

Previously, you could only create and delete fields from the Table view, but with today's update, you'll be able to add and delete fields directly from the Settings page.

![settings_fields](https://i0.wp.com/user-images.githubusercontent.com/16281246/165530790-375f4a9e-104c-4bcc-ae8d-e37d71cb75b5.gif?ssl=1)

### Group by custom fields for time-based charts (alpha)[](#group-by-custom-fields-for-time-based-charts-alpha)

Project insights now supports the ability to `Group by` custom fields for time-based charts, giving you the power to analyze trends over time for the fields you care about most.

![Historical-Insights](https://i0.wp.com/user-images.githubusercontent.com/3174849/165657775-282dff3b-bde2-4953-bcb0-82e6696fd919.png?ssl=1)

### ✨ Bug fixes & improvements[](#✨-bug-fixes--improvements)

Other changes include:

* Bug fix to resolve drop-down arrow illogically persisting after grouping by a field then sorting by a different field.