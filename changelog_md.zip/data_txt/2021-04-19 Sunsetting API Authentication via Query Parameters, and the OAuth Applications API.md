April 19, 2021 

In February 2020, to strengthen the security of our API, we deprecated [API Authentication via Query Parameters](https://developer.github.com/changes/2020-02-10-deprecating-auth-through-query-param/) and the [OAuth Application API](https://developer.github.com/changes/2020-02-14-deprecating-oauth-app-endpoint) to avoid unintentional logging of in-transit access tokens. In the coming months, we'll be removing these endpoints and authentication flow according to the following schedule:

### OAuth Application API[](#oauth-application-api)

Please refer to this [blog post](https://developer.github.com/changes/2020-02-14-deprecating-oauth-app-endpoint) on migrating to the replacement endpoints.

#### Brownouts[](#brownouts)

* May 5, 2021: For 12 hours starting at 14:00 UTC
* June 9, 2021: For 24 hours starting at 14:00 UTC

#### Removal[](#removal)

* August 11 2021 at 14:00 UTC

### Authentication via Query Parameters[](#authentication-via-query-parameters)

Please refer to this [blog post](https://developer.github.com/changes/2020-02-10-deprecating-auth-through-query-param/) for authentication via headers.

#### Brownouts[](#brownouts-1)

* May 5, 2021: For 12 hours starting at 14:00 UTC
* June 9, 2021: For 24 hours starting at 14:00 UTC
* August 11, 2021: For 48 hours starting at 14:00 UTC

#### Removal[](#removal-1)

* September 8 2021 at 14:00 UTC

Please check the latest [Enterprise release](https://enterprise.github.com/releases/) notes to learn in which version these functionalities will be removed.