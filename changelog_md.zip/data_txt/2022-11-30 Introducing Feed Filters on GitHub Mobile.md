November 30, 2022 

![Feed filters@2x](https://i0.wp.com/user-images.githubusercontent.com/3252375/204404052-f38c6b8f-c33c-420e-ab1c-cd4438641c0e.png?w=1200&ssl=1)

Personalize your feed with activity filters, now available on GitHub Mobile!

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/orgs/community/discussions/categories/mobile) to help us improve.