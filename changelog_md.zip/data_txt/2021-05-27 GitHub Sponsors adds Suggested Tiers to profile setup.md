May 27, 2021 

GitHub Sponsors now suggests sponsorship tiers when new makers set up their sponsors profile.

![Sponsors suggested tiers UI](https://github.blog/wp-content/uploads/2021/05/119889794-e09e6100-beeb-11eb-81f7-b5b0f401600b.png)