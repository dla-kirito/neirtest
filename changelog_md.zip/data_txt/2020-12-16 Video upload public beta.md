December 16, 2020 

You can now upload `.mp4` and `.mov` files to issue, pull request, and discussion comments to share reproduction steps, design ideas, and experience details with your team.

![](https://i0.wp.com/user-images.githubusercontent.com/22751162/101841526-ebf6ff00-3afa-11eb-965d-5ce11efdb9f8.png?ssl=1)

The public beta will gradually rollout to all GitHub accounts over the coming week.

[Send us your feedback](https://support.github.com/contact/feedback?contact%5Bcategory%5D=issues-projects&contact%5Bsubject%5D=Video+Upload+Feedback)