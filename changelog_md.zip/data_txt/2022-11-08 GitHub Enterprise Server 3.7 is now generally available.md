November 8, 2022 

GitHub Enterprise Server 3.7 is now generally available. This release continues our trend of bringing new features to GitHub Enterprise Server (GHES) in record numbers. Beyond the numbers, the features in GHES 3.7 not only enable developers to build world class software every day, but also provide administrators with the tools needed to reliably run GitHub at scale.

We're making more than 70 features available, including:

* **Reusable workflows and new support for Google Cloud Storage,** making it easier to build with GitHub Actions at scale.
* **Security Overview dashboard** to give all security teams a single view of code risk.
* **An improved management console** to keep your instance more secure than ever with automated user onboarding and offboarding.
* **New forking and repository policies**, so adopting innersource best practices is easier, all while balancing auditability and project maintenance in the long term.
* **Code scanning alerts** are now more collaborative and part of the flow for GitHub Advanced Security customers.

To learn more about GitHub Enterprise Server 3.7, read the [release notes](https://docs.github.com/en/enterprise-server@3.7/admin/release-notes), and [download it now](https://enterprise.github.com/releases/3.7.0/download).