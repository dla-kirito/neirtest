February 7, 2023 

Code scanning can now be set up to never cause a pull request check failure.

By default, any code scanning alerts with a `security-severity` of `critical` or `high` will cause a pull request check failure.  
You can specify which `security-severity` level for code scanning results should cause the code scanning check to fail, including `None`, by going to the **Code security and Analysis** tab in the repository settings.

![Screenshot code-scanning-settings](https://i0.wp.com/user-images.githubusercontent.com/54394529/217245862-9c98e4c9-1c55-4fa5-a907-5b80300ffbe6.png?ssl=1)

This has shipped to GitHub.com and will be available in GitHub Enterprise Server 3.9\. Learn more about [severity levels for security alerts](https://github.blog/changelog/2021-07-19-codeql-code-scanning-new-severity-levels-for-security-alerts/) and [Code scanning results check failures on pull requests.](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/triaging-code-scanning-alerts-in-pull-requests#code-scanning-results-check-failures)