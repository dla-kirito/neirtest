August 30, 2021 

You can now run Java projects faster on GitHub Actions by enabling dependency caching on the [setup-java](https://github.com/actions/setup-java) action. `setup-java` supports caching for both Gradle and Maven projects. 

The following example enables caching for a Java project with Gradle:

```yaml
steps:
- uses: actions/checkout@v2
- uses: actions/setup-java@v2
  with:
    distribution: 'temurin'
    java-version: '11'
    cache: 'gradle'
- run: ./gradlew build
```

For additional examples, visit the [setup-java repository](https://github.com/actions/setup-java#caching-packages-dependencies).