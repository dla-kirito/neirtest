July 19, 2021 

GitHub has a brand new onboarding experience for users creating an account on [github.com](https://www.github.com). From the homepage's vantage point in outer space, we'll guide you to a soft landing and get you started in no time!

![New User Onboarding](https://i0.wp.com/user-images.githubusercontent.com/1016190/126225459-4742157c-052d-4135-93ef-545e99066307.png?ssl=1)