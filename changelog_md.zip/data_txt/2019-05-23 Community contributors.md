May 23, 2019 

Users can hover over a repository’s contributor count, and community contributors will show a hovercard of direct and transitive contributors to dependencies parsed from that repository’s dependency graph.

[Learn more about community contributors](https://help.github.com/articles/viewing-a-projects-contributors)