February 8, 2019 

We added zero to the search results counter. Now, it’s easier to see what queries generate empty results when switching between different tabs in the search results menu.

[Learn more about searching for code on Github](https://help.github.com/articles/searching-code/)