September 25, 2018 

The system calculating the outdating of code review comments has been updated to a more precise method such that the exact line of code that anchors the comment must change to outdate the conversation. Users should now only see their conversations as outdated when the line of code that started the conversation is changed.