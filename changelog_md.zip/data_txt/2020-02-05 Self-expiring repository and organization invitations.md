February 5, 2020 

Invitations to join an organization or become a collaborator on a repository will expire seven days after they are created.

For more information, see the [inviting collaborators to a personal repository](https://help.github.com/en/github/setting-up-and-managing-your-github-user-account/inviting-collaborators-to-a-personal-repository) and [inviting users to join your organization](https://help.github.com/en/github/setting-up-and-managing-organizations-and-teams/inviting-users-to-join-your-organization) documentation.