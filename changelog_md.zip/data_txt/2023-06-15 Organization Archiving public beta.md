June 15, 2023 

You can now archive all repositories in an organization with a single click. Archiving an organization will:

* Archive all repositories in the organization
* Set a key in the API to indicate the org has been archived
* Restrict activities in that organization such as creating new repos
* Display a banner on the organization's profile indicating that it's been archived

To archive an organization, go to the organization's settings page and click the "Archive organization" button in the Danger Zone. This will launch a background job which performs the archiving; once complete, the banner will show up on the organization's profile page.

For more information on organization archiving, including how to un-archive an organization, see "[Archiving an organization](https://docs.github.com/en/organizations/managing-organization-settings/archiving-an-organization)"

This feature is in public beta. We'd love to [hear your feedback](https://gh.io/archive-organizations-beta-feedback) on how it works for you.