September 27, 2022 

Additional information has been added to the payload of `github.event` for scheduled runs. Before this change, `github.event` for scheduled runs would only include the cron schedule. This change adds information about the repository, organization, and enterprise (when available).

For questions, [visit the GitHub Actions community](https://github.com/orgs/community/discussions/categories/actions-and-packages).

To see what’s next for Actions, [visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions).