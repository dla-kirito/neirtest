March 7, 2023 

The [Custom Repository Roles](https://docs.github.com/en/enterprise-cloud@latest/rest/orgs/custom-roles?apiVersion=2022-11-28) REST API has moved to general availability, with a breaking change to the path used.  
Previously, the API was found at `/orgs/{org}/custom_roles` – it has been moved to `/orgs/{org}/custom-repository-roles`. With [organization-level custom roles](https://github.com/github/roadmap/issues/586) in progress, we found that the `custom_roles` path was wasn't specific enough and could generate confusion.  
The deprecated beta API will be removed from `api.github.com` in 6 months, on September 7th, 2023.  
On GitHub Enterprise Server, the API will be available at its new path in version 3.9\. The previous API to [list roles](https://docs.github.com/en/enterprise-server@3.4/rest/orgs/custom-roles) was added in GHES 3.4, and will be removed with the next [API version](https://docs.github.com/en/rest/overview/api-versions?apiVersion=2022-11-28).

To learn more about custom repository roles, see ["About custom repository roles"](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/about-custom-repository-roles) and ["Custom repository roles REST API"](https://docs.github.com/en/enterprise-cloud@latest/rest/orgs/custom-roles#create-a-custom-repository-role&apiVersion=2022-11-28).