September 14, 2020 

We've refreshed the landing page for containers in GitHub Container Registry. You can now see an organized snapshot of the description, versions, tags, and downloads.

You can also [connect your containers to a repository via an OCI label](https://docs.github.com/packages/managing-container-images-with-github-container-registry/connecting-a-repository-to-a-container-image) or through the UI. The landing page will show relevant links and content from the linked repository.

![Container landing page](https://i0.wp.com/user-images.githubusercontent.com/20052233/93354149-b2b83700-f80a-11ea-9aee-0ec695fe09c7.png?ssl=1)