November 30, 2023 

GitHub Codespaces recently released multiple updates to improve visibility into monthly spend:

* Organization administrators whose organization's codespace usage is paid for by the enterprise can now see month-to-date spending in their organization, even though their organization is not directly paying for this usage.
* All organization administrators with access to billing reports can now see projected codespaces spend in the month. This calculation is an estimate based on the past seven days of codespace usage.

![org admin billing screen with projected usage](https://i0.wp.com/user-images.githubusercontent.com/4679612/286721104-908091d3-19fa-484a-a934-bba1535c6219.png?ssl=1)

With these improvements, organization administrators can get a better sense of how large of a bill they can expect to pay at the end of the month, and remain aware of how much they are billing back to their enterprise.

### Additional Resources[](#additional-resources)

* [About billing for GitHub Codespaces](https://docs.github.com/billing/managing-billing-for-github-codespaces/about-billing-for-github-codespaces)
* [Viewing projected usage for an organization](https://docs.github.com/billing/managing-billing-for-github-codespaces/about-billing-for-github-codespaces#viewing-projected-usage-for-an-organization)
* [Viewing GitHub Codespaces usage for an organization](https://docs.github.com/billing/managing-billing-for-github-codespaces/viewing-your-github-codespaces-usage#viewing-github-codespaces-usage-for-your-organization-account)