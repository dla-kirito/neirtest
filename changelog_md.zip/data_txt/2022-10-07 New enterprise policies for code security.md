October 7, 2022 

[Enterprise owners](https://docs.github.com/en/enterprise-cloud@latest/admin/user-management/managing-users-in-your-enterprise/roles-in-an-enterprise#enterprise-owners) can now configure whether repository administrators can enable or disable Dependabot alerts.

If you are owner of an enterprise with GitHub Advanced Security, you can now also set policies to allow or disallow repository administrators access to enablement for:

* GitHub Advanced Security
* Secret scanning

![image](https://i0.wp.com/user-images.githubusercontent.com/2262535/194653210-fe26f2a0-bbe6-44ea-88a0-07213992e780.png?w=1223&ssl=1)

[Learn more about enterprise policies for code security](https://docs.github.com/en/enterprise-cloud@latest/admin/policies/enforcing-policies-for-your-enterprise/enforcing-policies-for-code-security-and-analysis-for-your-enterprise) and [send us your feedback](https://github.com/github-community/community/discussions/categories/code-security)