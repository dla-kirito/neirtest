February 15, 2022 

We've gotten a lot of feedback from users that it's hard to differentiate multiple codespaces in the same repo, especially if they're on the same branch. To make it a little easier to tell codespaces apart, we've started automatically creating "friendly" (and fun) names for your codespaces.

![codespace_friendly_names](https://i0.wp.com/user-images.githubusercontent.com/2575327/154125880-cceb928f-eaed-4b81-96aa-e17c17708162.png?w=600&ssl=1)

If you don't like our names, we're also working on the ability for users to re-name their codespaces.

For more information on Codespaces, see "[GitHub Codespaces overview](https://docs.github.com/en/codespaces/overview)".