September 11, 2018 

The 2.14.5, 2.13.11, 2.12.19, and 2.11.25 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

View the full release notes:

* [See Enterprise 2.14.5 release notes](https://enterprise.github.com/releases/2.14.5/notes)
* [See Enterprise 2.13.11 release notes](https://enterprise.github.com/releases/2.13.11/notes)
* [See Enterprise 2.12.19 release notes](https://enterprise.github.com/releases/2.12.19/notes)
* [See Enterprise 2.11.25 release notes](https://enterprise.github.com/releases/2.11.25/notes)