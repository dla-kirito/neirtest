November 2, 2022 

Organization administrators can now filter fine-grained personal access tokens (PATs) by their permissions in the organization settings UI. Both [pending token requests](https://docs.github.com/en/organizations/managing-programmatic-access-to-your-organization/managing-requests-for-personal-access-tokens-in-your-organization) and [active tokens](https://docs.github.com/en/organizations/managing-programmatic-access-to-your-organization/reviewing-and-revoking-personal-access-tokens-in-your-organization) can be filtered by permission, such as `issues_write` and `members_read`.

![image](https://i0.wp.com/user-images.githubusercontent.com/1666363/199575858-247c5b6a-9e10-4c36-83ed-ac14cf2ee182.png?ssl=1)

After setting a filter, only tokens with that permission will be shown in the table.

To learn more about fine-grained PATs, see "[Reviewing fine-grained personal access tokens](https://docs.github.com/en/organizations/managing-programmatic-access-to-your-organization/reviewing-and-revoking-personal-access-tokens-in-your-organization#reviewing-and-revoking--fine-grained-personal-access-tokens)" and "[Managing requests for fine-grained personal access tokens](https://docs.github.com/en/organizations/managing-programmatic-access-to-your-organization/managing-requests-for-personal-access-tokens-in-your-organization#managing-fine-grained-personal-access-token-requests)".