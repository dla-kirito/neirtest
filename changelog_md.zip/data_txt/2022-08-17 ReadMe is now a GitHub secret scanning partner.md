August 17, 2022 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [ReadMe](https://readme.com/) to scan for their API keys and help secure our mutual users on public and private repositories. ReadMe’s API keys allow users to sync OpenAPI and Markdown files to their developer hubs using [the rdme GitHub Action](https://github.com/marketplace/actions/rdme-sync-to-readme), as well as perform other programmatic updates using the ReadMe API. We’ll forward exposed API keys found in public repositories to ReadMe, who will immediately revoke the token and notify the project administrators via email. More information about ReadMe’s API keys can be found [here](https://docs.readme.com/reference/authentication).

GitHub Advanced Security customers can also scan for ReadMe tokens and block them from entering their private and public repositories with [push protection](https://github.blog/changelog/2022-04-04-secret-scanning-prevents-secret-leaks-with-protection-on-push/).

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Learn more about protecting pushes](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)