May 8, 2020 

In the billing tab, you can now get a detailed breakdown in CSV format for metered resources including Actions, Packages, and Storage.

The usage report provides the following information:

* Date
* Product (Actions, Packages, or Shared Storage)
* Repository Slug
* Quantity Consumed
* Unit Type (Machine Minutes or GB)
* Price Per Unit (USD)