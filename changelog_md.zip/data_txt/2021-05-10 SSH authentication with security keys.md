May 10, 2021 

You can now authenticate to SSH using a FIDO2 security key by adding a `sk-ecdsa-sha2-nistp256@openssh.com` or `sk-ssh-ed25519@openssh.com` SSH key to your account. SSH security keys store secret key material on a separate hardware device that requires verification, such as a tap, to operate.

This combination of storing the key on separate hardware and requiring physical interaction for your SSH key offers additional security. Since the key is stored on hardware and is non-extractable, it can't be read or stolen by software running on the computer. Additionally, the tap prevents unauthorized use of the key since the security key will not operate until you physically interact with it.

Learn more about this feature from the accompanying [blog post](https://github.blog/2021-05-10-security-keys-supported-ssh-git-operations/). 

[Learn more about adding an SSH key to your account](https://docs.github.com/en/github/authenticating-to-github/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent#generating-a-new-ssh-key-for-a-hardware-security-key).