June 27, 2023 

We are introducing a number of enhancements, bug fixes and a breaking API change to repository rules.  
![](https://github.blog/wp-content/uploads/2023/06/GitHubScreenShot-Arc-12-06-2023-001243.png?resize=906%2C606)

**1\. UI Updates**  
\* Added a repository picker to target select repositories for organization rulesets.  
\* Improvements to rule violations in the WebUI and git client.

![](https://github.blog/wp-content/uploads/2023/06/GitHubScreenShot-Arc-16-06-2023-001296.gif?resize=1066%2C638)

**2\. Ruleset Bypass updates**

* Bypass can be limited to pull request exemptions only.
* Single UI for bypass, collapsing bypass mode, and bypass list into one experience.
* Support for using repository roles as a bypass type
* Integrations (bots/apps) are now bypassable at the org.  
![](https://github.blog/wp-content/uploads/2023/06/GitHubScreenShot-Arc-16-06-2023-001297.gif?resize=1066%2C638)

**3\. API Enhancements**

* Add fields for created and updated date
* Permission changes so all repo contributors can query the API for relevant rules enforced on branches.

**4\. Bug fixes**

* Linear merge history could block bypass
* Branches could not always be created when using commit metadata rules
* Tag protections were failing for apps

**5\. API Changes**

* ~~GraphQL changes will be delayed by 24-72 hours.~~
* **Breaking Change** Remove `bypass_mode` from the Ruleset object and input
* **Breaking Change** Add `bypass_mode` as a required field for bypass actors to indicate if an actor can “always” bypass a ruleset or can only bypass for a “pull\_request”
* **Breaking Change for GraphQL** Change `bypass_actor_ids` to a new bypass\_actors object on the create and update mutations that can accept repository roles and organization admins
* Add `repository_role_database_id`, `repository_role_name`, and `organization_admin` fields to `RepositoryRulesetBypassActor `to indicate when the bypass actor is a role or org admin bypass
* “get rules for a branch” REST API endpoint now returns ruleset source info for each rule.
* “get a repo ruleset” REST API endpoint now has a `current_user_can_bypass` field that indicates whether the user making the request can bypass the ruleset.
* `source` field for rulesets returned via the REST API will now properly contain the repo in `owner/name` syntax when the ruleset is configured on a repository, rather than just the repository’s name.

We want to hear from you on how we can improve repository rules! Join the conversation in the repository rules [public beta discussion](https://github.com/orgs/community/discussions/52652).