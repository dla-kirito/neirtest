April 24, 2023 

You can now customize your GitHub Actions Importer experience using feature flags. You can use the `--enable-features` and `--disable-features` options to select specific features to enable or disable for the duration of the command.  
![image](https://github.com/github/gh-actions-importer/assets/9662209/8c2e06bd-c803-4825-bed2-71cc06955278)

For details on how to get started, please check out our [documentation](https://gh.io/actions-importer-docs). For questions and feedback, visit the [GitHub Actions Importer community](https://gh.io/actions-importer-feedback).