December 16, 2022 

Secret scanning alerts for third party API key detections now include a link to relevant documentation provided by the service provider, where available. These links are intended to help users better understand detections and take appropriate action.

The links will appear in the alert view for all repositories with secret scanning enabled. You can enable secret scanning on your public repositories and any private repository with GitHub Advanced Security. If you have feedback on any provided links, please write us a note in our [code security discussion](https://github.com/orgs/community/discussions/categories/code-security).

![example alert with provider docs](https://i0.wp.com/user-images.githubusercontent.com/81782111/204634104-6a28e954-b4ed-4e44-b6d2-5b2282458483.png?w=712&ssl=1)

For more information:

* [Read our blog post to learn how you can secure your public repositories…for free](https://github.blog/2022-12-15-leaked-a-secret-check-your-github-alerts-for-free)
* [Learn about secret scanning for private repositories](https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning#about-secret-scanning-for-private-repositories)