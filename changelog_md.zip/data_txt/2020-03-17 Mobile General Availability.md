March 17, 2020 

GitHub for mobile is now generally available for all GitHub users on iOS and Android. Take GitHub to go with the new, fully-native mobile app. Quickly jump back into your work, triage notifications, and collaborate with peers from anywhere.

[Learn more about GitHub for mobile](https://github.com/mobile)