March 1, 2023 

Rich diffs of Jupyter Notebook files in pull requests are now available in preview. With the feature preview enabled, you can compare cell-level inputs and outputs (including images), as well as notebook and cell metadata, thanks to [nbdime](https://github.com/jupyter/nbdime). Check it out:

![image](https://i0.wp.com/user-images.githubusercontent.com/7219923/221975386-9d8dc807-593a-4123-855b-487308901bf3.png?ssl=1)

The rich diff functionality will need to be enabled via the Feature Preview menu found when clicking on your avatar. [Click here](https://docs.github.com/en/get-started/using-github/exploring-early-access-releases-with-feature-preview) to learn more about feature previews and how to enable it. Please note that this is an early-access feature and there are some limitations; most notably, you cannot currently comment on lines in rich diff mode and will need to toggle the source diff to do so.

We'd love to hear from you! Once you try it out, let us know what you think in this [feedback discussion](https://github.com/orgs/community/discussions/37376). Stay tuned for future updates!

**Note**: If you were previously enrolled in the private beta for this feature and no longer see rich diffs, you may have to re-enable the feature preview via the menu.