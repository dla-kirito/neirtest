March 17, 2020 

GitHub token scanning now scans inside any `zip`\-encoded file. This covers files with a `.zip` extension and many other common file formats, like `.xlsx` and `.numbers`, that are `zip`\-encoded. These scans are in addition to the existing scans of the text content of every commit to every public repository. In all cases, we scan for both GitHub tokens and tokens for [a number of our partners](https://help.github.com/en/github/administering-a-repository/about-token-scanning).

When GitHub detects a set of credentials, we notify the service provider who issued the token. The service provider validates the credential and then decides whether they should revoke the token, issue a new token, or reach out to you directly, which will depend on the associated risks to you or the service provider. These steps can protect you from data loss and from unexpected large bills from your service providers.

[Learn more about how to become a token scanning partner](https://developer.github.com/partnerships/token-scanning/)