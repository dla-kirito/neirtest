March 10, 2023 

Dependency graph and Dependabot now parse and update `package-lock.json` files set with [lockfileVersion: 3](https://docs.npmjs.com/cli/v9/configuring-npm/package-lock-json#lockfileversion), which is used by npm v9\. Users will receive Dependabot alerts for dependencies with known vulnerabilities.

* [Learn more about the dependency graph](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-the-dependency-graph)
* [Learn more about Dependabot](https://docs.github.com/en/code-security/dependabot)