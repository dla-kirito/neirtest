July 24, 2023 

On October 11, 2022, [we annouced plans](https://github.blog/changelog/2022-10-11-github-actions-deprecating-save-state-and-set-output-commands/) to deprecate the `save-state` and `set-output` workflow commands on May 31, 2023\. We have since decided to postpone the removal given the amount of usage we are still seeing with these commands.

Workflows using `save-state` or `set-output` in their workflows will continue to work as expected, however, a warning will appear under annotations indicating the planned deprecation. We recommend customers using these commands to upgrade their workflows to use environment files.

For more information on environment files, please check out our [documentation](https://docs.github.com/actions/using-workflows/workflow-commands-for-github-actions#environment-files). To see what's next for Actions, [visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions).