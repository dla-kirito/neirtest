August 9, 2022 

The Ubuntu 18.04 Actions runner image [started our deprecation process](https://github.com/actions/runner-images/issues/6002) on 8/8/22 and will be fully unsupported by 12/1/22\. To raise awareness of the upcoming removal, jobs using Ubuntu 18.04 will temporarily fail during scheduled time periods defined below:

* October 3, 12:00 UTC – October 3, 14:00 UTC
* October 18, 14:00 UTC – October 18, 16:00 UTC
* November 15, 18:00 UTC – November 15, 20:00 UTC
* November 30, 20:00 UTC – November 30, 22:00 UTC
* December 15, 20:00 UTC – December 16 00:00 UTC
* January 5, 10.00 UTC – January 5, 14.00 UTC
* January 13, 12.00 UTC – January 13, 16.00 UTC
* January 18, 14.00 UTC – January 18, 18.00 UTC
* January 24, 16.00 UTC – January 24, 20.00 UTC
* February 7, 16.00 UTC – February 7, 22.00 UTC
* February 21, 10.00 UTC – February 21, 22.00 UTC
* March 6, 00.00 UTC – March 7, 00.00 UTC
* March 13, 00.00 UTC – March 14, 00.00 UTC
* March 21, 00.00 UTC – March 22, 00.00 UTC
* March 28, 00.00 UTC – March 29, 00.00 UTC

**What you need to do**

Workflows using the `ubuntu-18.04` YAML workflow label should be updated to `ubuntu-20.04`, `ubuntu-22.04`, or `ubuntu-latest`. You can always get up-to-date information on our tools by reading about the [software](https://github.com/actions/virtual-environments) in GitHub Actions virtual environments. Please contact GitHub [Support](https://support.github.com/contact?form%5).

\*update: we extended the deprecation schedule until April 2023 with updated dates for brownouts.