November 6, 2019 

The GitHub Actions macOS virtual environment has been upgraded to Catalina (v10.15). Jobs using the \`macos-10.14\` virtual environment will not run and must be migrated to use \`macos-latest\`.

In addition to Catalina, other changes include:

* Xcode 11.1 will be set as default
* Mono 6.4, Xamarin.iOS 13.4, Xamarin.Android 10.0, Xamarin.Mac 6.2 will be set as default
* .NET Core 3.0 will be set as default
* Node.JS 12 will be set as default
* Removed Xamarin.iOS 13.2
* Removed Xamarin.iOS SDK 12.\*
* Removed Xamarin.iOS SDK 11.\*
* Removed Xamarin.iOS SDK 10.\*
* Removed Xamarin.Android SDK 9.\*
* Removed Xamarin.Android SDK 8.\*
* Removed Xamarin.Android SDK 7.\*
* Removed Xamarin.Mac SDK – 5.\*
* Removed Xamarin.Mac SDK – 4.\*
* Removed Xamarin.Mac SDK – 3.\*
* Removed Mono 4.x
* Removed Mono 5.x
* Removed Mono 6.0
* Removed Xcode 10.\*
* Removed Xcode 9.\*
* Removed legacy iOS Simulators (iOS 8.4 – 10.2)
* Removed .NET Core 2.x (only 3.x are on image)
* Removed Android build tools less than 24.0.0

To learn more about the different virtual environments and included software, please read [Virtual Environments for GitHub Actions](https://help.github.com/en/github/automating-your-workflow-with-github-actions/virtual-environments-for-github-actions). Also, please contact [GitHub Support](https://github.com/contact?form%5Bsubject%5D=Re:%20GitHub%20Actions) if you run into any problems or need help.