April 15, 2020 

The multi-line code suggestions feature is now generally available to all GitHub users.

With multi-line suggestions you can suggest a specific change to multiple lines of code when reviewing a pull request. To select a multi-line code block, either:

* click and hold to the right of a line number, drag and then release the mouse when you’ve reached the last line of the desired selection; or
* click on a line number, hold `Shift`, click on a second line number and click the "+" button to the right of the second line number.

Once you've selected the code block, click the diff icon and edit the text within the suggestion block.

[Learn more about pull request comments](https://help.github.com/en/github/collaborating-with-issues-and-pull-requests/commenting-on-a-pull-request) and [send us your feedback.](https://support.github.com/contact/feedback?contact%5Bcategory%5D=prs-and-code-review&contact%5Bsubject%5D=Multi-line+suggestions)