December 1, 2021 

You can now control which GitHub App a [required status check](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/defining-the-mergeability-of-pull-requests/about-protected-branches#require-status-checks-before-merging) is provided by. If status is then provided by a different app or by a user via a commit status, merging will be prevented. This ensures all changes are validated by the intended app.

![Screenshot of a repository's required status check settings, specifying which GitHub App is required for each status check](https://i0.wp.com/user-images.githubusercontent.com/2503052/143027201-6c5017fe-b5d3-4aa9-8124-5d96001ce8ce.png?ssl=1)

Existing required status checks will continue to accept status from any app, but can be updated to only accept status from a specific app (see [Editing a branch protection rule](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/defining-the-mergeability-of-pull-requests/managing-a-branch-protection-rule#editing-a-branch-protection-rule)). Newly-added required status checks will default to the app that most recently reported the status, but you can choose a different app or allow any app to provide the status.

For more information see our [documentation about protected branches](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/defining-the-mergeability-of-pull-requests/about-protected-branches#require-status-checks-before-merging).