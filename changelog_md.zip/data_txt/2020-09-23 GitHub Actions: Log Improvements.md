September 23, 2020 

Logs for GitHub Actions have gotten a significant update. Some major enhancements and new features include:

* Styling changes to improve readability
* An improved search experience for large logs
* Auto-scrolling and expansion if a step fails
* Redesigned errors and warnings
* Clickable URLs
* Support for more colors
* Full-screen mode

Check out our detailed [blog post](https://github.blog/2020-09-23-a-better-logs-experience-with-github-actions/) on the new Logs Experience for more information.

[For questions please visit the GitHub Actions community forum](https://github.community/t5/GitHub-Actions/bd-p/actions)

[To see what's next for GitHub Actions, visit our public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=label%3Aactions)