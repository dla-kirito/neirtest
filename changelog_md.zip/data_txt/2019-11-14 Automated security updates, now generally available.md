November 14, 2019 

Automated security updates (formerly Dependabot and automated security fixes) are now generally available in all public repositories on GitHub. After a popular debut at Satellite 2019, more than 3.5 million active repositories have the feature enabled and receive automated pull requests that update them to the nearest non-vulnerable dependency versions. Thanks to all of our beta testers and Dependabot users for your feedback and support.

[Learn more about automated security updates](https://help.github.com/github/managing-security-vulnerabilities/configuring-automated-security-updates)