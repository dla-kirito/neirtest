September 27, 2022 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [DevCycle](https://devcycle.com/) to scan for their SDK tokens and help secure our mutual users on public repositories. DevCycle tokens allow users to target and toggle feature flags by environment and platform. GitHub will forward access tokens found in public repositories to DevCycle, who will immediately mark the token as compromised. More information about DevCycle Tokens can be found [here](https://docs.devcycle.com/docs/home/feature-management/organizing-your-flags-and-variables/api-and-sdk-keys).

GitHub Advanced Security customers can also scan for DevCycle tokens and block them from entering their private and public repositories with [push protection](https://github.blog/changelog/2022-04-04-secret-scanning-prevents-secret-leaks-with-protection-on-push/).

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Learn more about protecting pushes](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)