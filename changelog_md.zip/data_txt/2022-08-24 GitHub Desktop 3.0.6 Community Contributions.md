August 24, 2022 

GitHub Desktop 3.0.6 brings a slew of community contributions! As an open source project, we are always so grateful to our contributors who make Desktop better for themselves and others. Additionally, we’ve improved the recognition of default branch changes.

## Adds:[](#adds)

* Add Warp terminal integration for macOS. Thanks @lhvy!
* Add PyCharm Community Edition support on macOS. Thanks @tsvetilian-ty!
* Add context menu to the current branch and current repository toolbar. Thanks @uttiya10!

## Fixes:[](#fixes)

* Older versions of Sublime Text and SlickEdit are also recognized as external editors. Thanks @vbwx!
* Fix commit shortcut (Ctrl/Cmd + Enter). Thanks @tsvetilian-ty!
* Show 'Email' label on the preferences form when user is not signed in. Thanks @andymckay!
* Fix invalid URL state while the "Clone Repository" modal is open. Thanks @tsvetilian-ty!
* Fix commit description with three lines overflowing when it shouldn't. Thanks @HeCorr!
* 'Update from default branch\` menu item allows quick merge of upstream. Thanks @uttiya10!
* Unified diff line gutter context menu items for discard changes no longer enabled when whitespace is hidden.
* 'Show Whitespace Changes' popover appears as expected on unified diff.
* On pull or fetch, make sure the default branch is updated to match the repository settings.
* Fix notifications on Windows 10 builds prior to the Creators Update.

## Improvements:[](#improvements)

* Add ability to skip staggered release to ensure the latest version is downloaded.

[Learn more about GitHub Desktop](https://desktop.github.com)