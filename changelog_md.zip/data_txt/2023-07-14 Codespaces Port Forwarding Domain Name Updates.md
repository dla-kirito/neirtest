July 14, 2023 

# Codespaces is updating the domain used for forwarded ports[](#codespaces-is-updating-the-domain-used-for-forwarded-ports)

Starting in August, Codespaces will be updating web client port forwarding to improve security, reliability, and performance for users. As part of this update, the URL for forwarded ports will change from `https://*.preview.app.github.dev` to `https://*.app.github.dev`.

To prepare for this change, replace any hardcoded references to `preview.app.github.dev` in your code with the `GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN` environment variable by July 31 to avoid any disruptions. The environment variable value will be updated from `preview.app.github.dev` to `app.github.dev` when the migration completes. Learn more about environments variables [here](https://docs.github.com/en/codespaces/developing-in-codespaces/default-environment-variables-for-your-codespace).