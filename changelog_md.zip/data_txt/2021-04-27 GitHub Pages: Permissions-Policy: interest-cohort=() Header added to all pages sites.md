April 27, 2021 

All GitHub Pages sites served from the github.io domain will now have a `Permissions-Policy: interest-cohort=()` header set.

Pages sites using a custom domain will not be impacted.

[Learn more about GitHub Pages](https://docs.github.com/en/pages)

[For questions, visit the GitHub Pages community](https://github.community/c/github-help/github-pages/31)