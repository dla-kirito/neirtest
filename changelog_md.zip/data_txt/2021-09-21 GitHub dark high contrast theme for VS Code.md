September 21, 2021 

A new `GitHub Dark High Contrast` theme matching the official github.com theme is now available in VS Code. To start using the new theme, go to the [VS Marketplace](https://marketplace.visualstudio.com/items?itemName=GitHub.github-vscode-theme), click on the "Install" button, and [select your preferred theme](https://code.visualstudio.com/docs/getstarted/themes#%5Fselecting-the-color-theme) in VS Code. This release also includes recent improvements to our color system across the other GitHub VS Code themes.

![GitHub dark high contrast vs code theme](https://i0.wp.com/user-images.githubusercontent.com/378023/134259152-942ae8bc-6c01-4d15-b3c8-1bcb2f70f83e.png?ssl=1)