September 30, 2019 

We’ve fully deployed several updates to the [GitHub Actions virtual environments](https://help.github.com/en/articles/software-in-virtual-environments-for-github-actions).

**Ubuntu 16.04 LTS**

* Upgraded Ansible 2.8.4 to 2.8.5
* Upgraded Azure CLI 2.0.71 to 2.0.73
* Upgraded AWS CLI 1.16.221 to 1.16.241
* Upgraded Firefox 68.0.2 to 69.0
* Upgraded Google Chrome 76.0.3809.100 to 77.0.3865.90
* Upgraded Google Cloud SDK 258.0.0 to 263.0.0
* Added Go 1.13
* Upgraded Heroku 7.28.0 to 7.30.0
* Upgraded HHCM 4.19.0 to 4.23.0
* Upgraded Gradle 5.6 to 5.6.2
* Upgraded kubectl 1.15.3 to 1.15.4
* Upgraded Mono 6.0.0.319 to 6.0.0.334
* Upgraded Typescript 3.5.3 to 3.6.3
* Upgraded Webpack 4.39.2 to 4.40.2
* Upgraded Webpack CLI 3.3.7 to 3.3.9
* Upgraded PHP 5.6.40-10 to 5.6.40-12
* Upgraded PHP 7.0.33-10 to 7.0.33-11
* Upgraded PHP 7.1.31-1 to 7.1.32-1
* Upgraded PHP 7.2.21-1 to 7.2.22-1
* Upgraded PHP 7.3.8-1 to 7.3.9-1
* Upgraded PHPUnit 7.5.14 to 7.5.16
* Upgraded Powershell 6.2.2 to 6.2.3
* Upgraded rustup 1.18.3 to 1.19.0
* Upgraded cbindgen 0.9.0 to 0.9.1
* Upgraded Terraform 0.12.6 to 0.12.9
* Upgraded vcpkg 2019.07.19 to 2019.09.12
* Upgraded Zeit Now CLI 16.1.1 to 16.2.0
* Added Android SDK 29, Android SDK Build-Tools 29.0.0, 29.0.2
* Upgraded Android SDK Platform-Tools 29.0.2 to 29.0.4
* Upgraded cached container images
* Reduced the disk size to increase operational efficiency, resulting in a decrease of approximately 40GB of free space

**Ubuntu 18.04 LTS**

* Upgraded Ansible 2.8.4 to 2.8.5
* Upgraded Azure CLI 2.0.71 to 2.0.73
* Upgraded AWS CLI 1.16.221 to 1.16.241
* Added .NET Core SDKs 2.1.509, 2.1.606, 2.1.802, 2.2.109, 2.2.206, 2.2.402
* Upgraded Firefox 68.0.2 to 69.0
* Upgraded Google Chrome 76.0.3809.100 to 77.0.3865.90
* Upgraded Google Cloud SDK 258.0.0 to 263.0.0
* Added Go 1.13
* Upgraded Heroku 7.28.0 to 7.30.0
* Upgraded HHCM 4.19.0 to 4.23.0
* Upgraded Gradle 5.6 to 5.6.2
* Upgraded kubectl 1.15.3 to 1.15.4
* Upgraded Mono 6.0.0.319 to 6.0.0.334
* Upgraded Typescript 3.5.3 to 3.6.3
* Upgraded Webpack 4.39.2 to 4.40.2
* Upgraded Webpack CLI 3.3.7 to 3.3.9
* Upgraded PHP 7.1.31-1 to 7.1.32-1
* Upgraded PHP 7.2.21-1 to 7.2.22-1
* Upgraded PHP 7.3.8-1 to 7.3.9-1
* Upgraded PHPUnit 7.5.14 to 7.5.16
* Upgraded Powershell 6.2.2 to 6.2.3
* Upgraded rustup 1.18.3 to 1.19.0
* Upgraded cbindgen 0.9.0 to 0.9.1
* Upgraded Terraform 0.12.6 to 0.12.9
* Upgraded vcpkg 2019.07.19 to 2019.09.12
* Upgraded Zeit Now CLI 16.1.1 to 16.2.0
* Added Android SDK 29, Android SDK Build-Tools 29.0.0, 29.0.2
* Upgraded Android SDK Platform-Tools 29.0.2 to 29.0.4
* Upgraded cached container images
* Reduced the disk size to increase operational efficiency, resulting in a decrease of approximately 40GB of free space

**Windows Server 2019**

* Upgraded Docker 19.03.1 to 19.03.2
* Upgraded Powershell Core 6.2.2\. to 6.2.3
* Upgraded Visual Studio 16.2 to 16.3
* Upgraded cached container images
* Added Android SDK 29, Android SDK Build-Tools 29.0.0, 29.0.2
* Upgraded Azure CLI 2.0.70 to 2.0.74
* Upgraded Ruby 2.4.5 to 2.4.6
* Upgraded Ruby 2.5.3 to 2.5.5
* Upgraded Ruby 2.6.1 to 2.6.3
* Upgraded Git 2.22.0 to 2.23.0
* Upgraded Git LFS 2.7.2 to 2.8.0
* Added Go 1.13
* Upgraded PHP 7.3.7 to 7.3.10
* Upgraded Rust 1.36 to 1.37
* Upgraded Google Chrome 75.0.3770.142 to 76.0.3809.132
* Upgraded Firefox 68.0.1 to 69.0
* Upgraded Chrome Driver 75.0.3770.140 to 76.0.3809.132
* Upgraded Node 10.16.1 to 10.16.3
* Downgraded and pinned npm 6.10.3 to 6.9.0
* Upgraded Gradle 5.5.1 to 5.6.2
* Upgraded Cmake 3.15.1 to 3.15.3
* Upgraded SQL Server Data Tier Application Framework 15.0.4384.2 to 15.0.4538.1
* Added .NET Core SDK 3.0.100 and Runtime 3.0.0
* Upgraded .NET Core Runtime 2.1.12 to 2.1.13
* Upgraded Typescript 3.5.3 to 3.6.3
* Upgraded CosmosDb Emulator 2.4.5 to 2.5.6
* Upgraded jq 1.5 to 1.6
* Upgraded GitVersion 5.0.0.0 to 5.0.1.0
* Upgraded Cloud Foundry CLI 6.46.0 to 6.46.1
* Upgraded vcpkg 2019.07.18 to 2019.09.12

**macOS 10.14**

* Set Xcode 10.3 by default
* Upgraded OS X 10.14.6 (18G87) to OS X 10.14.6 (18G95)
* Upgraded Node 12.8.1 to 12.10.0
* Upgraded Powershell 6.2.2 to 6.2.3
* Upgraded Ruby 2.6.3 to 2.6.4
* Upgraded Go 1.12.9 to 1.13
* Upgraded Homebrew 2.1.10 to 2.1.11
* Upgraded Apache Maven 3.6.1 to 3.6.2
* Upgraded curl 7.65.3 to 7.66.0
* Upgraded GNU parallel 20190722 to GNU parallel 20190822
* Upgraded fastlane 2.129.0 to fastlane 2.131.0
* Upgraded Azure CLI 2.0.71 to 2.0.72
* Upgraded Xcode 11-beta (11M382q) to 11.0 (11A420a)
* Added xcversion 2.6.1
* Added DriverKit 19.0
* Upgraded Android SDK Platform-Tools 29.0.1 to 29.0.4
* Upgraded Android SDK Platform 29, Revision 1 to 29, Revision 3
* Added Android SDK Build-Tools 29.0.0, 29.0.2
* Upgraded lldb 2.3.3614996 to 3.1.4508709
* Upgraded Android Emulator 29.0.11 to 29.2.0
* Upgraded Google API Hardware\_Accelerated\_Execution\_Manager Intel x86 Emulator Accelerator 7.3.2 to 7.5.1
* Updated Visual Studio for Mac 8.1.5.9 to 8.2.6.26
* Added Xamarin.iOS SDK 12.14.0.114
* Added Xamarin.Android SDK 9.4.1.0
* Added Xamarin.Mac SDK 5.16.1.17