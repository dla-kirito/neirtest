September 17, 2020 

GitHub Container Registry now supports Docker images that have [support for multiple operating systems and architectures](https://docs.docker.com/docker-for-mac/multi-arch/).

The installation instructions will also show how to download the image on different operating systems and architectures.

![image](https://i0.wp.com/user-images.githubusercontent.com/20052233/93238279-3c0a3380-f74f-11ea-8420-e3aba5551d9c.png?ssl=1)