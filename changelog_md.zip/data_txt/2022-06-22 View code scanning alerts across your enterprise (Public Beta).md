June 22, 2022 

GitHub Advanced Security customers can now see an overview of code scanning alerts at the enterprise level. This page provides a repo-centric view of application security risks, as well as an alert-centric view of all secret scanning, Dependabot and now code scanning alerts. This view is beta and will be followed in the coming weeks with an enterprise level REST API to retrieve code scanning alerts.

![Code scanning alerts at the enterprise level](https://i0.wp.com/user-images.githubusercontent.com/1865328/175122213-28d9d8c5-4fb7-4ac7-8657-d05e4744c657.png?resize=1354%2C689&ssl=1)

[Learn more about security overview](https://docs.github.com/en/code-security/security-overview/exploring-security-alerts)  
[Learn more about GitHub Advanced Security](https://github.com/features/security)