August 2, 2021 

If you use notifications on [GitHub Mobile](https://github.com/mobile), you've probably had the frustrating experience of tapping on a notification only to end up in the wrong place on the timeline, unsure of exactly what triggered the notification and where to start reading. We've improved this experience so that notifications and other app deep links will scroll you to the correct place. Triaging notifications on the go should now feel much faster and reliable!

<https://github.blog/wp-content/uploads/2021/08/127174125-91ac8592-750d-4580-bbda-b47b8b6d1d84.mp4>

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/github/feedback/discussions/categories/mobile-feedback) to help us improve.