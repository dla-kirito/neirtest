October 17, 2019 

On 10/23/2019 we will change the default shell for the `run` step on Windows runners to PowerShell.

If your `run` step contains Windows batch scripting you should update it to specify `cmd` as the `shell` to avoid being broken.

- run: |
    ...
  shell: cmd

[Learn more about scripts in GitHub Actions here](https://help.github.com/en/articles/workflow-syntax-for-github-actions#jobsjob%5Fidstepsrun).

If you have any questions or thoughts about these changes, we recommend sharing in our GitHub Community Forum’s [Actions Board](https://github.community/t5/GitHub-Actions/bd-p/actions)!