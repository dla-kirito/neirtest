June 12, 2023 

If you manage your node.js dependencies with the pnpm package manager, you can now use Dependabot to keep those dependencies updated with automatic pull requests. You can easily configure this feature by adding or updating your dependabot.yml file in your repository. At this time, Dependabot will not open security alerts against pnpm dependencies.

* [Learn more about setting up Dependabot version updates](https://docs.github.com/en/enterprise-cloud@latest/code-security/dependabot/dependabot-version-updates/about-dependabot-version-updates)