March 7, 2023 

Dependency graph no longer ingests `go.sum` files for Go repositories, and Dependabot no longer alerts on vulnerabilities for dependencies found in `go.sum` files. Dependencies previously ingested from `go.sum` files have been removed from the dependency graph for all repositories on github.com. 

`go.sum` files are not lock files but a log of all packages downloaded by Go when building a project. They may include multiple versions of a dependency, which may result in false positive Dependabot alerts for a vulnerable version that isn't actually used in the project. 

Dependency graph continues to support `go.mod` files, the recommended format for Go projects. Use Go 1.17 or higher to ensure your `go.mod` file is a comprehensive view of all direct and transitive dependencies.

[Learn more about the dependency graph](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-the-dependency-graph)