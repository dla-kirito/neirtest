November 12, 2021 

On Saturday November 13, 2021 from 7:00PM to 9:00PM PST, GitHub’s billing systems will undergo scheduled maintenance. 

During this time period, certain payment functionalities will be unavailable including:

* Adding a new payment method or updating existing payment methods
* Signing up for a new paid GitHub account
* Upgrading existing account to a new paid GitHub plan
* Paying invoices
* Making new Marketplace purchases
* Adding new sponsorships or changing tiers of existing sponsorships

Thank you for your patience as we work to improve our systems. 