December 1, 2022 

GitHub organizations can now use the code scanning organization-level API endpoint to retrieve code scanning alerts on public repositories; this no longer requires a GitHub Advanced Security license. This new endpoint supplements the existing repository-level endpoint.

Learn more about the [code scanning organization-level REST API](https://docs.github.com/en/enterprise-cloud@latest/rest/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization).