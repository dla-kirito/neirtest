January 31, 2023 

In January 2022, GitHub announced [audit log streaming to AWS is generally available](https://github.blog/changelog/2022-01-20-audit-log-streaming-is-generally-available/). By [streaming the audit log for your enterprise](https://docs.github.com/en/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise/reviewing-audit-logs-for-your-enterprise/streaming-the-audit-log-for-your-enterprise), enterprises benefit from:

* **Data exploration:** Examine streamed events using your preferred tool for querying large quantities of data. The stream contains both audit and Git events across the entire enterprise account.
* **Data continuity:** Pause the stream for up to seven days without losing any audit data.
* **Data retention:** Keep your exported audit logs and Git events data as long as you need to.

To expand on this offering, enterprises streaming their audit log to AWS S3 now have the ability to use AWS CloudTrail Lake integration to automatically consolidate and ingest GitHub audit logs into [AWS Cloud Trail Lake](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-lake.html). AWS CloudTrail Lake is a managed security and audit data lake that allows organizations to aggregate, immutably store, and query events. By deploying this integration in your own AWS account, AWS CloudTrail Lake will capture and provide tools to analyze GitHub audit log events using SQL-based queries.

To learn more, read our documentation on [integrating with AWS CloudTrail Lake.](https://docs.github.com/enterprise-cloud@latest/admin/monitoring-activity-in-your-enterprise/reviewing-audit-logs-for-your-enterprise/streaming-the-audit-log-for-your-enterprise#integrating-with-aws-cloudtrail-lake)