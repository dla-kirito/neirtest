May 23, 2019 

Currently in limited public beta, GitHub Sponsors is a tool to financially support the developers who build the open source software you use every day. Open source developers can now receive funding from the community directly through their GitHub profile.

[Learn more about GitHub Sponsors](https://github.com/sponsors)