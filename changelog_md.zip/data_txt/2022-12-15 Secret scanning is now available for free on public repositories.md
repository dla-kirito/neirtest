December 15, 2022 

Previously, only organizations with GitHub Advanced Security could enable secret scanning's user experience on their repositories. Now, any admin of a public repository on GitHub.com can detect leaked secrets in their repositories with GitHub secret scanning.

The new secret scanning user experience complements the [secret scanning partner program](https://docs.github.com/en/developers/overview/secret-scanning-partner-program), which alerts over 100 service providers if their tokens are exposed in public repositories. You can read more about this change and how secret scanning can protect your contributions in our blog post.

* [Read our blog post to learn how you can secure your public repositories…for free](https://github.blog/2022-12-15-leaked-a-secret-check-your-github-alerts-for-free)
* [Learn how to secure your repositories with secret scanning](https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning)