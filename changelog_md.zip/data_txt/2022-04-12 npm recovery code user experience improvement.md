April 12, 2022 

After setting up 2FA on npmjs.com recovery codes can now more easily be copied, printed, or saved by customers.