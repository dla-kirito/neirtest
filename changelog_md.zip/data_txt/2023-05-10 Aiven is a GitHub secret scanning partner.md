May 10, 2023 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [Aiven](https://aiven.io/) to scan for their tokens and help secure our mutual users on public repositories. Aiven tokens allow users to interact with Aiven hosted services and the Aiven API. GitHub will forward access tokens found in public repositories to Aiven, and the Aiven Customer Success Team will contact project owners via the normal service channel and work with them to rotate and revoke the affected credentials. Aiven will not revoke credentials without prior communication and acknowledgement from the project owner. You can read more information about Aiven’s tokens [here](https://docs.aiven.io/docs/platform/concepts/authentication-tokens).

GitHub Advanced Security customers can also scan for Aiven tokens and block them from entering their private repositories. All users can [enable push protection](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning) for public repositories, for free.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)