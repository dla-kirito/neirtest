December 14, 2021 

GitHub Desktop now supports reviewing the statuses of individual check runs for a pull request directly in GitHub Desktop. This includes statuses of job steps for check runs generated through GitHub Actions. Customers can review the results of check runs on a PR, re-run jobs, and quickly navigate to the logs on github.com.

[Learn more about GitHub Desktop](https://desktop.github.com)