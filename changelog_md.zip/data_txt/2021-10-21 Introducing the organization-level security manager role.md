October 21, 2021 

Organizations can now grant teams permission to manage security alerts and settings on all their repositories. The "security manager" role can be applied to any team and grants the team's members the following permissions:

* Read access on all repositories in the organization
* Write access on all security alerts in the organization
* Access to the organization-level security tab
* Write access on security settings at the organization level
* Write access on security settings at the repository level

![Security manager configuration](https://i0.wp.com/user-images.githubusercontent.com/1144873/138259431-27991c7a-99d6-4252-ac88-ee6fc0c76a80.png?ssl=1)

[Learn more about the security manager role](https://docs.github.com/en/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)