February 8, 2019 

We added an animation that widens the search input field on focus for logged-in, desktop users. Now, long repo names are not truncated, making it easier to read suggested repo names in the quick search box.

[Learn more about searching on GitHub](https://help.github.com/articles/searching-on-github/)