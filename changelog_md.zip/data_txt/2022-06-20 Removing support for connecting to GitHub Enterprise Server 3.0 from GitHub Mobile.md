June 20, 2022 

GitHub Mobile can no longer connect to GitHub Enterprise Server 3.0\. To enable connections from GitHub Mobile to GitHub Enterprise Server, a site administrator must upgrade to GitHub Enterprise Server 3.1 or later. Newer versions of GitHub Enterprise Server improve performance, enhance security, and provide new features. For more information, see "[GitHub Enterprise Server releases](https://docs.github.com/enterprise-server/admin/all-releases)" and "[Upgrading GitHub Enterprise Server](https://docs.github.com/enterprise-server/admin/enterprise-management/updating-the-virtual-machine-and-physical-resources/upgrading-github-enterprise-server)."

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/github-community/community/discussions/categories/mobile) to help us improve.