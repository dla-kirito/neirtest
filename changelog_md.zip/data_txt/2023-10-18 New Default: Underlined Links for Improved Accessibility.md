October 18, 2023 

By default, links within text blocks on GitHub are now underlined. This ensures links are easily distinguishable from surrounding text. If preferred, you can "hide" underlines for these links in the [accessibility settings](https://github.com/settings/accessibility). More details can be found in the [documentation – managing the appearance of links](https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-personal-account-on-github/managing-user-account-settings/managing-accessibility-settings#managing-the-appearance-of-links).

Should you encounter any issues with this feature during its public beta, please [provide feedback](https://gh.io/link%5Funderline%5Ffeedback).

Thanks for aiding our mission to enhance [GitHub's accessibility](https://accessibility.github.com/)!