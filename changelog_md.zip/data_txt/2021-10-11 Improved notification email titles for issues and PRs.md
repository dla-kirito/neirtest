October 11, 2021 

For all issues and PRs created on or after October 18th, 2021, you'll see `(Issue #xx)` or `(PR #xx)` in the notification email title, so you can more easily distinguish between these two notification types.