September 26, 2023 

To help users better understand the state of a pull request, we now provide more details in two specific cases.

### Merged indirectly[](#merged-indirectly)

If a pull request's commits are merged into the base branch by another pull request (or directly), the pull request is still marked as merged, but previously, it was not clear from the timeline that the pull request was merged this way. This could result in confusion if the pull request was still awaiting approvals or had failing status checks. Now, the timeline provides more details, including a link to the merged pull request that caused the pull request to be marked as merged.  
![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/270781971-ed50f20a-2adf-4221-8a44-5f2b5d92b25d.png?w=700)

> Note: this message only appears when using rulesets.

### Pushed commits are still being processed[](#pushed-commits-are-still-being-processed)

If new commits are pushed to a pull request's branch and it takes longer than usual for them to be processed and appear in the commit list, an informational message is now presented at the top of the pull request page.  
![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/270782283-b3083500-90ef-4208-965a-db878c69cc20.png?w=550)