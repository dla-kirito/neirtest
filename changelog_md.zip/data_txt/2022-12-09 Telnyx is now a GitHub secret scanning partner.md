December 9, 2022 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [Telnyx](https://telnyx.com/) to scan for their tokens and help secure our mutual users on all public repositories and private repositories with GitHub Advanced Security. Telnyx tokens allow users to manage their usage and resources on the Telnyx communications and connectivity platform.

GitHub will forward access tokens found in public repositories to Telnyx, who will immediately reach out to the user and work to swiftly rotate the key. More information about Telnyx tokens can be found [here](https://developers.telnyx.com/docs/api/v2/overview#authentication).

GitHub Advanced Security customers can also block Telnyx tokens from entering their private and public repositories with [push protection](https://github.blog/changelog/2022-04-04-secret-scanning-prevents-secret-leaks-with-protection-on-push/).

[Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)  
[Learn more about protecting pushes](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)  
[Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)