December 11, 2018 

GitHub status will now be displayed at <https://www.githubstatus.com>. The old GitHub status at [https://status.github.com/](https://status.github.com) will be deprecated February 28, 2019\. During the month of February, brownouts on <https://status.github.com> will be done to help identify systems that may have dependencies on the old status site.