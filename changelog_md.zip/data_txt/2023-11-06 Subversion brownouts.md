November 6, 2023 

As announced earlier this year, GitHub is [removing support for the Subversion protocol](https://github.blog/2023-01-20-sunsetting-subversion-support/). Before permanent removal, we're running two brownouts where we will temporarily disable Subversion support.

Those brownouts are scheduled for:

* An 8 hour period on November 13, 2023, from 14:00 – 22:00 UTC / 7:00am – 3:00pm Pacific
* A 24 hour period beginning December 5, 2023 at 10:00 UTC / 2:00am Pacific and ending at the same time on December 6

As a reminder, Subversion support will be permanently removed on January 8, 2024.