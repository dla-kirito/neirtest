September 3, 2021 

Forked repositories can now be synced with their upstream using the merge upstream API. For more info, see the documentation [here](https://docs.github.com/en/rest/reference/repos#sync-a-fork-branch-with-the-upstream-repository).

You can also sync forks through the web UI, see [here](https://github.blog/changelog/2021-05-06-sync-an-out-of-date-branch-of-a-fork-from-the-web/).