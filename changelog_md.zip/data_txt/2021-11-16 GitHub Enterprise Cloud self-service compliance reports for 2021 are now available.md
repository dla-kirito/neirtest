November 16, 2021 

GitHub Enterprise Cloud administrators can now download and view the latest GitHub SOC 1, Type 2 and SOC 2, Type 2 compliance reports for 2021\. These reports can be found under the `Compliance` settings tab of their enterprise account: `https://github.com/enterprises/"your-enterprise"/settings/compliance`.

For organizations, these reports can be found under the `Organization Security` settings tab of their organization: `https://github.com/organizations/"your-org"/settings/security`.