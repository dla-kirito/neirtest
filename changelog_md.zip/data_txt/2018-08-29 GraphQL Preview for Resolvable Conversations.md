August 29, 2018 

With the release of resolvable conversations, we’re releasing some new GraphQL  
mutations and fields to help people automate their workflows and create new  
integrations.

[Learn more](https://developer.github.com/changes/2018-08-29-resolvable-threads)