March 13, 2019 

**GitHub.com and supporting services are not vulnerable.** Patches and mitigations were applied as necessary ahead of the public vulnerability disclosure. Standard incident response procedures were enacted to ensure no earlier attempts were made to exploit the vulnerabilities.

Common Vulnerability and Exposure (CVE) references have been issued for the vulnerabilities:

* CRITICAL: A specially crafted request could allow arbitrary files to be read and the file content to be disclosed. For more information, see the associated Rails CVE: [CVE-2019-5418](https://groups.google.com/forum/#!topic/rubyonrails-security/pFRKI96Sm8Q)
* HIGH: High CPU usage could be triggered by a specially crafted request resulting in Denial of Service (DoS). For more information see the associated Rails CVE: [CVE-2019-5419](https://groups.google.com/forum/#!topic/rubyonrails-security/GN7w9fFAQeI)