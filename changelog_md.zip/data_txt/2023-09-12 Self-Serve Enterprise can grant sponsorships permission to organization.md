September 12, 2023 

Self-serve enterprise accounts can now grant member organizations permission to create sponsorships. Sponsorships created by a member organization will charge the enterprise account's credit card on file.

Learn more about [granting permissions](https://docs.github.com/enterprise-cloud@latest/admin/policies/enforcing-policies-for-your-enterprise/enforcing-policies-for-github-sponsors-in-your-enterprise).