October 21, 2022 

Adding a [configuration for Codespaces](https://docs.github.com/en/codespaces/setting-up-your-project-for-codespaces/introduction-to-dev-containers) involves adding a [Development Container](https://containers.dev/) to a repository and editing it to meet your needs. Previously, a dev container configuration could either be written manually or created with a VS Code extension. We have now added the ability to create or edit a configuration directly from the Code drop down on a GitHub repository page.

![Code dropdown showing the new Codespaces configuration option](https://i0.wp.com/user-images.githubusercontent.com/9445180/197280999-2bffe0c5-cb4b-4222-85b5-c6e208a450ba.png?ssl=1)

Whether you use this mechanism, or you already have a dev container in your repository, you can now edit that configuration within GitHub using the new configuration editor. To open the editor from the code view in a repository, click the pencil icon while viewing a `devcontainer.json` file.

![screenshot of view of devcontainer.json file](https://i0.wp.com/user-images.githubusercontent.com/9445180/197277219-e92ee2ee-d0b0-4263-9e16-716d20f7d89c.png?ssl=1)

You are now editing the `devcontainer.json` file in place in the browser. The dev container needs to conform to the [Development Container specification](https://containers.dev/implementors/json%5Freference/). The editor makes using [dev container Features](https://containers.dev/implementors/features/) easy. Dev container Features provide reusable configurations for Codespaces created from the repository. Browse available features from right side of the dev container editor.

![screenshot of editor and marketplace](https://i0.wp.com/user-images.githubusercontent.com/9445180/197276727-984cf174-d68d-4b4e-92a7-62059bc55da8.png?ssl=1)

To use a dev container feature, copy the snippet of `json` and place it in the `features` object of your `devcontainer.json` file. Once you have the features you want, commit those changes to the repository by clicking the "Start commit" button.

![screenshot of the start commit button function](https://i0.wp.com/user-images.githubusercontent.com/9445180/197070557-be1f3477-3684-4393-88c5-3a8ce53ee8e6.png?ssl=1)

We hope this will make configuring your repositories for Codespaces significantly easier.