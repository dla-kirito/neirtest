May 17, 2018 

You can now navigate back to recent projects and other activities, directly from your personal or organization dashboards with a new Recent Activity component, better ranked repositories in the sidebar, and interactive grouped events in your activity feed.

* [Read more about your personal dashboard](https://help.github.com/articles/about-your-personal-dashboard/)
* [Read more about your organization dashboard](https://help.github.com/articles/about-your-organization-dashboard/)