August 29, 2023 

GitHub Actions asks customers to review their network allow list for self-hosted runners according to the [requirements in our documentation](https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners/about-self-hosted-runners#communication-between-self-hosted-runners-and-github).

Network access to GitHub's `*.actions.githubusercontent.com` is essential for the self-hosted runners. Requiring wildcard access allows GitHub Actions to be flexible moving forward as we improve the service. Customers that do not allow wildcard access risk having interruptions in their GitHub Actions usage as we start enforcing this requirement on September 12, 2023\. Please reach out to the [customer support](https://support.github.com) if you have limitations with configuring wildcard access in the on-premises firewall solution.

[Learn more about GitHub Actions self-hosted runners](https://docs.github.com/actions/hosting-your-own-runners/managing-self-hosted-runners/about-self-hosted-runners).

For questions, [visit the GitHub Actions community](https://github.com/orgs/community/discussions/categories/actions-and-packages).

To see what's next for Actions, [visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions).