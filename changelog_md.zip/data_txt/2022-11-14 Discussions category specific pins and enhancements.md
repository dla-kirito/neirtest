November 14, 2022 

Previously, repository admins could [pin up to four important discussions](https://docs.github.com/en/discussions/managing-discussions-for-your-community/managing-discussions#pinning-a-discussion) above the list of discussions for the repository or organization. Now, they can also pin discussions to a specific discussion category to provide context relevant to that category. These pins appear above the list of discussions in that category and are not affected by pagination or search.

![category specific pins](https://i0.wp.com/user-images.githubusercontent.com/2993937/200872495-7d0964fb-3e98-4009-913e-57005187fefd.png?ssl=1)

More enhancements to Discussions available today:

* Category titles and descriptions are surfaced on a discussion category page, to help guide your community.
* If your GitHub organization is renamed, and you use [organization discussions](https://docs.github.com/en/organizations/managing-organization-settings/enabling-or-disabling-github-discussions-for-an-organization), links to the old discussions will now redirect appropriately.
* As an organization admin, when [blocking a user from your organization](https://docs.github.com/en/communities/maintaining-your-safety-on-github/blocking-a-user-from-your-organization#blocking-a-user-in-the-organization-settings) via a discussion or discussion comment, you now have the option to also [hide their existing comments in the organization](https://docs.github.com/en/communities/maintaining-your-safety-on-github/blocking-a-user-from-your-organization#blocking-a-user-in-a-comment).

To learn more about GitHub Discussions, read the [overview](https://github.com/features/discussions) or [documentation](https://docs.github.com/en/discussions), and [start conversations with your community today](https://docs.github.com/en/discussions/quickstart).