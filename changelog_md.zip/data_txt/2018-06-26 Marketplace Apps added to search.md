June 26, 2018 

You can now use the global index search to find apps that are listed on the GitHub Marketplace. We have also added a new search `type` for marketplace objects. [Here’s an example](https://github.com/search?q=ci&type=Marketplace) of how this works. These new set of items will be added to the search API in the coming weeks.

This feature is available for the Developer, Team, and Business Cloud plans.