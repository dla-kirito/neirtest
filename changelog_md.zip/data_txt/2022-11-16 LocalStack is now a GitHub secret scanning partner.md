November 16, 2022 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [LocalStack](https://localstack.cloud/) to scan for their API key tokens and help secure our mutual users on public repositories. LocalStack's tokens allow for activation of the advanced LocalStack features for their Pro/Team/Enterprise products. GitHub will forward access tokens found in public repositories to LocalStack, who will immediately notify users and revoke any compromised tokens. You can read more information about LocalStack's tokens [here](https://docs.localstack.cloud/get-started/pro/#getting-your-api-key).

GitHub Advanced Security customers can also scan for LocalStack tokens and block them from entering their private and public repositories with [push protection](https://github.blog/changelog/2022-04-04-secret-scanning-prevents-secret-leaks-with-protection-on-push/).

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Learn more about protecting pushes](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)