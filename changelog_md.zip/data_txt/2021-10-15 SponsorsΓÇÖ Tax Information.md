October 15, 2021 

Sponsors will now be asked to provide location information for the purposes of taxes. Accordingly, maintainers will now see the VAT status and location of their sponsors in their transaction export. This information is to assist users in calculating their sales tax obligations.

[Learn more in the documentation](https://docs.github.com/en/sponsors/receiving-sponsorships-through-github-sponsors/tax-information-for-github-sponsors#sales-tax).