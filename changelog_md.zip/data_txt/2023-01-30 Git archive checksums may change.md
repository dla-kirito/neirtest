January 30, 2023 

We are reverting this change for now. More details to follow.

The default compression for Git archives has [recently changed](https://github.com/git/git/commit/4f4be00d302bc52d0d9d5a3d4738bb525066c710). As result, archives downloaded from GitHub may have different checksums even though the contents are completely unchanged.&lt

GitHub doesn’t guarantee the stability of checksums for automatically generated archives. These are marked with the words “Source code (zip)” and “Source code (tar.gz)” on the Releases tab. If you need to rely on a consistent checksum, you may upload archives directly to GitHub Releases.  
These are guaranteed not to change.