May 23, 2019 

The internal repository visibility option is available to customers with an [Enterprise account](https://help.github.com/articles/about-enterprise-accounts). This new visibility option makes it easier to innersource code and projects to your organization members while restricting access to outside collaborators.

[Learn more about internal repositories](https://help.github.com/articles/creating-an-internal-repository)