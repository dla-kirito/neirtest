October 19, 2022 

We are excited to share with you that we have added a bunch of new capabilities to our GitHub app in Slack. You can now create, track and manage your GitHub issues directly from Slack.

### Create issues as you collaborate[](#create-issues-as-you-collaborate)

You can now create issues with just a click, right from the place where you interact with your team i.e. from your channel, personal app, group or direct chat.  
![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/196711678-30af4ab7-5cbc-4d3b-a1e9-f38abd0cb0e1.png?w=1023&ssl=1)

* The content of the chat is automatically added into the description along with the link to the slack conversation.
* The last used repo in the channel will be automatically filled in. However, you can go ahead and change to the repo if needed.
* You can optionally fill in labels, assignees and milestones when you create an issue.

Once the issue is created you will receive a confirmation card in the channel/chat where you created the issue.

### Issue card updates and threading[](#issue-card-updates-and-threading)

You can also update the issue directly from slack. When you see an issue notification card in Slack, you will now be able to comment, edit and close/reopen.  
![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/196716281-83f4dcee-b9c5-4b9f-aaaf-01c0d81e6f69.png?w=1023&ssl=1)

As part of this enhancement, we have also introduced threading functionality. Notifications for any issue are grouped under a parent card as replies. Threading gives context, reduces noise in the channel and helps improve collaboration.

For more information about these enhancements, please visit the GitHub app guidance for [Slack](https://github.com/integrations/slack/blob/main/README.md).