November 9, 2022 

GitHub's code navigation features _jump to definition_ and _find all references_ are now available for all Rust projects on GitHub.

When you view an Rust file on github.com, you can click on the name of a function, module, or macro to see its definition and its references within that repository. We use the [tree-sitter](https://github.com/tree-sitter/tree-sitter) library to find definitions and call sites in your code.

Learn more about code navigation for Rust and other languages in the GitHub documentation: [Navigating code on GitHub](https://help.github.com/en/github/managing-files-in-a-repository/navigating-code-on-github).

Also, check out the [tree-sitter library](https://github.com/tree-sitter/tree-sitter) to learn how support for different languages is implemented.