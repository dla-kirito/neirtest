December 17, 2019 

GitHub Enterprise Cloud customers that use [enterprise SAML SSO](https://help.github.com/en/github/setting-up-and-managing-your-enterprise-account/enforcing-security-settings-in-your-enterprise-account#enabling-saml-single-sign-on-for-organizations-in-your-enterprise-account) can now enable team synchronization services for their organizations.

Learn more about the [enterprise SAML team synchronization public beta](https://help.github.com/en/github/setting-up-and-managing-your-enterprise-account/enforcing-security-settings-in-your-enterprise-account#managing-team-synchronization-for-organizations-in-your-enterprise-account)