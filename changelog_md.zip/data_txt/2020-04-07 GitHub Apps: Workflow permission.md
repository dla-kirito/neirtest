April 7, 2020 

A new permission has been added that enables GitHub Apps to edit GitHub Actions workflow files.

[Learn more about updating permissions](https://developer.github.com/apps/managing-github-apps/editing-a-github-app-s-permissions/)

If you have any questions or thoughts about these changes, we recommend asking in our GitHub Community Forum’s [Actions Board](https://github.community/t5/GitHub-Actions/bd-p/actions)!