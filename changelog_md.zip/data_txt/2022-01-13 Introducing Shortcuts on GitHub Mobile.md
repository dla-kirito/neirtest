January 13, 2022 

![Introducing Shortcuts](https://i0.wp.com/user-images.githubusercontent.com/59900904/145284638-7c5d3494-4518-48ac-8a75-8757331278d7.png?ssl=1)

Shortcuts give quick access to the work you care about most. Customize and save filtered lists of issues, pull requests, and discussions right to your home tab on GitHub Mobile.

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/github/feedback/discussions/categories/mobile-feedback) to help us improve.