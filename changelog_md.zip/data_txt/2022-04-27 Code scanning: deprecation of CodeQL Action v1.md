April 27, 2022 

On March 30, 2022, we released CodeQL Action v2, which runs on the Node.js 16 runtime. The CodeQL Action v1 will be deprecated at the same time as GHES 3.3, which is currently scheduled for January 2023.

## How does this affect me?[](#how-does-this-affect-me)

### Users of GitHub.com, GitHub AE, and GitHub Enterprise Server 3.5 (and later)[](#users-of-github-com-github-ae-and-github-enterprise-server-3-5-and-later)

All users of GitHub code scanning (which by default uses the CodeQL analysis engine) on GitHub Actions on the following platforms should update their workflow files:

* GitHub.com (including open source repositories, users of GitHub Teams and GitHub Enterprise Cloud)
* GitHub AE
* GitHub Enterprise Server (GHES) 3.5 and later

Users of the above-mentioned platforms should update their CodeQL workflow file(s) to refer to the new `v2` version of the CodeQL Action.

### Users of GitHub Enterprise Server 3.4 (and older)[](#users-of-github-enterprise-server-3-4-and-older)

Users of GitHub Enterprise Server 3.4 (and older) are **not** recommended to update their configuration to use the `v2` version of the CodeQL Action:

* GHES 3.3 (and older) does not support running Actions using the Node 16 runtime and is therefore unable to run the `v2` version of the CodeQL Action. Please upgrade to a newer version of GitHub Enterprise Server prior to changing your CodeQL Action workflow files.
* While GHES 3.4 _does_ support Node 16 Actions, it does _not_ ship with `v2` of the CodeQL Action. Users who want to migrate to `v2` on GHES 3.4 should request that their system administrator enables [GitHub Connect](https://docs.github.com/en/enterprise-server@3.4/admin/github-actions/managing-access-to-actions-from-githubcom/using-the-latest-version-of-the-official-bundled-actions#using-github-connect-to-access-the-latest-actions) to download `v2` onto GHES before updating their workflow files.

The upcoming release of GitHub Enterprise Server 3.5 will ship with `v2` of the CodeQL Action included.

## Exactly what do I need to change?[](#exactly-what-do-i-need-to-change)

To upgrade to the CodeQL Action v2, open your CodeQL workflow file(s) in the `.github` directory of your repository and look for references to:

* `github/codeql-action/init@v1`
* `github/codeql-action/autobuild@v1`
* `github/codeql-action/analyze@v1`
* `github/codeql-action/upload-sarif@v1`

These entries need to be replaced with their `v2` equivalents:

* `github/codeql-action/init@v2`
* `github/codeql-action/autobuild@v2`
* `github/codeql-action/analyze@v2`
* `github/codeql-action/upload-sarif@v2`

## Can I use Dependabot to help me with this upgrade?[](#can-i-use-dependabot-to-help-me-with-this-upgrade)

Yes, you can! For more details on how to configure Dependabot to automatically upgrade your Actions dependencies, [please see this page](https://docs.github.com/en/code-security/dependabot/working-with-dependabot/keeping-your-actions-up-to-date-with-dependabot).

## What happens in January 2023?[](#what-happens-in-january-2023)

In January 2023, the CodeQL Action v1 will be officially deprecated (at the same time as the GHES 3.3 deprecation). At that point, no new updates will be made to `v1`, which means that new CodeQL analysis capabilities will only be available to users of `v2`. We will keep a close eye on the migration progress across GitHub. If many workflow files still refer to `v1` of the CodeQL Action we might consider scheduling one or more brownout moments later in the year to increase awareness.