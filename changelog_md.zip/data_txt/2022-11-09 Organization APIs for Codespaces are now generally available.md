November 9, 2022 

We recently released [organization-level API](https://github.blog/changelog/2022-09-28-organization-level-apis-for-codespaces/) support that enables administrators to programmatically manage their organization-owned codespaces at scale. Today we're announcing that these APIs are generally available.

With organization APIs providing a wide range of management operations, organizations can seamlessly integrate GitHub Codespaces into their existing workflows to automate and manage their development processes at scale.

Organization-level APIs are generally available to GitHub Team and Enterprise Cloud plans. Here is a link to our documentation to get started:

* [Codespaces Organization APIs](https://docs.github.com/en/rest/codespaces/organizations)