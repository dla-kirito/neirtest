September 14, 2023 

In October 2022, we released a [private beta](https://github.blog/changelog/2022-10-28-display-saml-sso-authentication-data-in-audit-log-private-beta/) adding linked SAML single sign-on (SSO) identities for relevant users to GitHub Enterprise audit log events. 

We are expanding the private beta to now include linked identities within git events, making this information available across all relevant events.

Enterprise owners interested in participating in the private beta should reach out to your GitHub account manager or [contact our sales team](https://github.com/enterprise/contact) to have this feature enabled for your enterprise. Once enabled, enterprise and organization owners can provide feedback at the [logging SAML SSO authentication data for enterprise and org audit log events community discussion page](https://github.com/community/community/discussions/37136).