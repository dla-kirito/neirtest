October 1, 2018 

The release of GitHub for Visual Studio 2.5.6 introduces a new and improved clone dialog.

[View the full release notes](https://visualstudio.github.com/release-notes.html)