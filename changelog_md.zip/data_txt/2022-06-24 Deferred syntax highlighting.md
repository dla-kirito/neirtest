June 24, 2022 

Pull Requests will now load more quickly thanks to deferred syntax highlighting.

When you first land on a Pull Request’s _Conversation_ or _Files_ tab we will show plain text diffs, and then swap in the syntax highlighted versions as soon as they are ready.