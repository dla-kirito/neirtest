July 24, 2018 

The 2.14.1, 2.13.7, 2.12.15, and 2.11.21 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

View the full release notes:

* [See Enterprise 2.14.1 release notes](https://enterprise.github.com/releases/2.14.1/notes)
* [See Enterprise 2.13.7 release notes](https://enterprise.github.com/releases/2.13.7/notes)
* [See Enterprise 2.12.15 release notes](https://enterprise.github.com/releases/2.12.15/notes)
* [See Enterprise 2.11.21 release notes](https://enterprise.github.com/releases/2.11.21/notes)