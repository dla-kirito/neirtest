June 15, 2018 

We’ve released new endpoints to help you find installations of your app for a given organization, repository, or user.

[Read more](https://developer.github.com/changes/2018-06-15-find-app-installations/)