May 27, 2020 

We have released v2 versions of the [cache](https://github.com/actions/cache) actions.

New features:

* Added support for caching multiple paths, wildcard patterns path or single file path
* Increased performance and improved cache sizes using `zstd` for compression for Linux and macOS runners
* Allowed caching for all events with a ref
* Created the [@actions/cache](https://github.com/actions/toolkit/tree/master/packages/cache) npm package to allow other actions to utilize caching
* Added a best-effort step to delete the archive after extraction to reduces storage space

[For questions, visit the GitHub Actions community](https://github.community/t5/GitHub-Actions/bd-p/actions)