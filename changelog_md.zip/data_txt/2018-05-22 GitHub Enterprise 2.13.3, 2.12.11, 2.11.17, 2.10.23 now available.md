May 22, 2018 

The 2.13.3, 2.12.11, 2.11.17 and 2.10.23 releases for GitHub Enterprise are now available for download from <https://enterprise.github.com/releases>.

View the full release notes:

* <https://enterprise.github.com/releases/2.13.3/notes>
* <https://enterprise.github.com/releases/2.12.11/notes>
* <https://enterprise.github.com/releases/2.11.17/notes>
* <https://enterprise.github.com/releases/2.10.23/notes>