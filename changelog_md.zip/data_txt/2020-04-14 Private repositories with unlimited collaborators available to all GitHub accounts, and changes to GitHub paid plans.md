April 14, 2020 

We’ve made some updates to our plans for developers and teams.

Free plans: 

* GitHub Team For Open Source is now GitHub Free
* Organizations and individuals on GitHub Free can now create unlimited private repositories with unlimited collaborators

GitHub Pro:

* GitHub Pro pricing is reduced from $7/month to $4/month
* GitHub Pro now includes 2GB of storage and 10GB of data transfer for GitHub Packages

GitHub Team:

* GitHub Team pricing is reduced from $9 per user/month to $4 per user/month with no minimum seat requirements

[Learn more about our plans and pricing](https://github.com/pricing)