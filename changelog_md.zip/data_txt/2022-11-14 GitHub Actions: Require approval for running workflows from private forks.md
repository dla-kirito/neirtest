November 14, 2022 

You can now require approval from a user with write permissions to the repository before a workflow run can be triggered from a private fork. This can be useful for some inner source scenarios, where you want to ensure that the code is reviewed before it is run.

![image](https://i0.wp.com/user-images.githubusercontent.com/185122/197212239-fe6eecb1-d8f9-4384-ac72-03d3f5fffa03.png?ssl=1)

[Learn more about enabling workflows for forks of private repositories](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#enabling-workflows-for-forks-of-private-repositories)  
For questions, visit the [GitHub Actions community.](https://github.com/orgs/community/discussions/categories/actions-and-packages)  
To see what's next for Actions, visit our [public roadmap.](https://github.com/orgs/github/projects/4247)