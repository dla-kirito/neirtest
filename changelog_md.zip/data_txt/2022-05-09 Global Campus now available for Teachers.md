May 9, 2022 

Big news for computer science teachers! Today, we invite teachers to join GitHub Global Campus, the new home for all computer science teachers at GitHub! On Global Campus, teachers can access education resources and learn about new programs and events-all in one place! Teachers can also:

* Upgrade their GitHub organizations to GitHub Team.
* Connect with the teacher community on GitHub Discussions.
* Request swag for their classroom.
* Manage active GitHub Classrooms.

If you’re a teacher, you can join Global Campus by completing a short application for [teacher benefits](https://education.github.com/discount%5Frequests/teacher%5Fapplication). Once accepted, you will be officially welcomed as a Global Campus teacher. Once verified, you can access Global Campus anytime at <https://education.github.com>.