July 18, 2022 

GitHub Advanced Security customers can now retrieve repository code scanning results at the enterprise level via the GitHub REST API. This new endpoint supplements the existing [repository-level](https://docs.github.com/en/enterprise-cloud@latest/rest/code-scanning#list-code-scanning-alerts-for-a-repository) and [organization-level](https://docs.github.com/en/enterprise-cloud@latest/rest/code-scanning#list-code-scanning-alerts-for-an-organization) endpoints.

[Learn more about the code scanning enterprise-level REST API](https://docs.github.com/en/rest/code-scanning#list-code-scanning-alerts-for-an-enterprise) and [send us your feedback.](https://github.com/github-community/community/discussions/categories/code-security)

[Learn more about GitHub Advanced Security](https://github.com/features/security)