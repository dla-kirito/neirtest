May 10, 2022 

A beta of the Ubuntu 22.04 runner image for GitHub Actions is now available. Start using GitHub Actions to build software on the latest version of Ubuntu by updating your jobs to include `runs-on: ubuntu-22.04`

```yaml
jobs:
  build:
    runs-on: ubuntu-22.04
     steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '14'
      - run: npm install -g bats
      - run: bats -v
```

The Ubuntu 22.04 Actions runner image has different tools and tool versions than ubuntu 20.04\. See the difference between the two OS versions [here](https://github.com/actions/virtual-environments/issues/5490). Click [here](https://github.com/actions/virtual-environments/blob/main/images/linux/Ubuntu2204-Readme.md) for the full list of software available on Ubuntu 22.04\. 

If you spot any issues with your workflows when using the image, please let us know by creating an issue in the [virtual-environments repository](https://github.com/actions/virtual-environments).

While the runner image is in beta, you may experience longer queue times during peak usage hours.