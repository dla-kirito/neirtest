November 10, 2021 

We’ve improved the depth of CodeQL's analysis by adding support for more [libraries and frameworks](https://codeql.github.com/docs/codeql-overview/supported-languages-and-frameworks/) and increasing the coverage of our existing library and framework models. [JavaScript](https://github.com/github/codeql/tree/main/javascript) analysis now supports most common templating languages, and [Java](https://github.com/github/codeql/tree/main/java) now covers more than three times the endpoints of previous CodeQL versions. As a result, CodeQL can now detect even more potential sources of untrusted user data, steps through which that data flows, and potentially dangerous sinks in which this data could end up. This results in an overall improvement of the quality of the code scanning alerts.

We carefully choose and prioritize the libraries and frameworks supported by CodeQL based on their popularity and through user feedback. These improvements are now available to users of CodeQL code scanning on GitHub.com, and will also be available in the next release of GitHub Enterprise Server (3.3).

**Java**

We've improved coverage for the following libraries:

* [Guava](https://github.com/google/guava)
* [JAX-RS](https://github.com/jax-rs)
* Java Standard Library
* [Apache Commons Lang library](https://commons.apache.org/proper/commons-lang/)
* [Apache Commons Collections](https://commons.apache.org/proper/commons-collections/)
* [Spring](https://spring.io/)
* [JSON-java](https://github.com/stleary/JSON-java)

**JavaScript**

We've added support for the following templating languages:

* [Handlebars](https://handlebarsjs.com/)
* [Mustache](https://mustache.github.io/)
* [Nunjucks](https://mozilla.github.io/nunjucks/)
* [Hogan](https://twitter.github.io/hogan.js/)
* [Swig](https://node-swig.github.io/swig-templates/)
* [EJS](https://ejs.co/)

Learn more about [CodeQL](https://codeql.github.com/docs/codeql-overview/about-codeql/) and [code scanning](https://docs.github.com/en/github/finding-security-vulnerabilities-and-errors-in-your-code/about-code-scanning).