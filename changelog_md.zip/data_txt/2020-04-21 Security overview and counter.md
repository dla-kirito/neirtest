April 21, 2020 

The repository security tab now includes two new experiences to help you better understand your repository's security at a glance. 

* First, we have added a counter which makes it easy to understand how many security alerts your repository has active. The counter only includes information which is otherwise visible to the logged in user. This change will be rolling out gradually over the next couple of days.
* Second, we have added an overview experience for your repository security tab which is located at `https://github.com/:org/:repo/security`. This new overview provides helpful insights about how to configure your repository to make the most of GitHub's built-in security and analysis features. It also provides a summary of known security issues.

![Screenshot of new security overview experience](https://i0.wp.com/user-images.githubusercontent.com/12853539/78591821-e4a78500-77f8-11ea-8fb0-0fe4b09bf866.png?ssl=1)