October 10, 2023 

![](https://github.blog/wp-content/uploads/2023/10/274044327-933a4c96-2042-4d2d-b980-632218658b49.png?resize=2400%2C1260)

Code Search: Easily search for code within repositories on GitHub Mobile.

Unlock the power to locate specific code snippets within a repository while on the go. This feature empowers users to efficiently access and share code snippets, fostering collaboration and knowledge sharing among team members.  
Whether you’re pinpointing crucial code elements or sharing insights with your colleagues, GitHub Mobile code search ensures that you stay productive and connected to your projects, no matter where you are.

Download or update GitHub Mobile today from the [Apple App Store](https://apps.apple.com/us/app/github/id1477376905) or [Google Play Store](https://play.google.com/store/apps/details?id=com.github.android) to get started.

---

[Learn more about GitHub Mobile](https://github.com/mobile) and [share your feedback](https://github.com/orgs/community/discussions/categories/mobile) to help us improve.