September 25, 2018 

The 2.14.6, 2.13.12, and 2.12.20 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

View the full release notes:

* [See Enterprise 2.14.6 release notes](https://enterprise.github.com/releases/2.14.6/notes)
* [See Enterprise 2.13.12 release notes](https://enterprise.github.com/releases/2.13.12/notes)
* [See Enterprise 2.12.20 release notes](https://enterprise.github.com/releases/2.12.20/notes)