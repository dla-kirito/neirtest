June 29, 2023 

Code scanning default setup is now available for all [CodeQL supported languages](https://codeql.github.com/docs/codeql-overview/supported-languages-and-frameworks/), excluding Swift. This includes supporting JavaScript/TypeScript, Ruby, Python, Go, Java/Kotlin, C/C++, and C# at the repository level. We will extend support to include Swift soon. We are also working to extend all CodeQL language support to the organization level.

Default setup detects the languages in the repository and automatically analyzes JavaScript/TypeScript, Ruby, Python, and Go. With this enhancement, you can customize the configuration to also analyze Java/Kotlin, C/C++, and C#. The configuration can be viewed and edited at any time, during or after set up. 

You can also use the [REST API](https://docs.github.com/en/rest/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration) to include CodeQL supported languages in the default setup configuration. 

<https://user-images.githubusercontent.com/19343236/247068739-a93d98f1-d028-4e40-b9df-8da7c5a892ab.mp4>

### What if the analysis for a language fails in default setup?[](#what-if-the-analysis-for-a-language-fails-in-default-setup)

It is possible for the CodeQL analysis for a particular language to fail, such as when the code can't be compiled. If the CodeQL analysis for a language fails in default setup, you will see an error message on the repository's settings page, in the code security and analysis section. To resolve the situation you can:

1. Deselect the language from the configuration and continue to use default setup for the successful languages.

<https://user-images.githubusercontent.com/19343236/247066564-1547a89e-0b37-47a9-bb72-8da476cdaae8.mp4>

1. Convert to [advanced setup](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/configuring-code-scanning-for-a-repository#creating-an-advanced-setup). The advanced setup uses a `yml` file and allows you to provide the build information required for the CodeQL analysis to succeed.

<https://user-images.githubusercontent.com/19343236/247067476-c7b358ef-a51d-4104-bd31-b8cd779da7fc.mp4>

1. Debug and fix the cause of the language failure. The Actions log will provide the failure reason so you can resolve this for a successful analysis.

<https://user-images.githubusercontent.com/19343236/247067515-66f5abce-8858-41f6-96b2-9f8009ec28fb.mp4>

### Why aren't some languages automatically included in the default setup configuration ?[](#why-arent-some-languages-automatically-included-in-the-default-setup-configuration-)

Java (including Kotlin), C/C++, and C# are not automatically included in the default setup configuration because they often require more advanced configuration. Code written in these languages needs to be compiled in order for CodeQL analysis to proceed. CodeQL will attempt to build your code automatically but may fail if your code requires bespoke build steps.

Java (including Kotlin), C/C++, and C# are not included in bulk code scanning setup from the organization level. We are working to extend all CodeQL language support to the organization level soon.

For more information on code scanning default setup, see [Configuring code scanning automatically](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/configuring-code-scanning-for-a-repository#configuring-code-scanning-automatically).