April 7, 2022 

Security Overview at the organization level is now out of beta and generally available. GitHub Advanced Security customers can use Security Overview to view a repo-centric view of application security risks. They can also see an alert-centric view of all Code Scanning, Dependabot, and Secret Scanning alerts, across all repositories in an organization.

![Security overview at the organization level](https://i0.wp.com/user-images.githubusercontent.com/1865328/161590843-2d102ba3-b40d-41b7-a990-7fe1ada63759.png?ssl=1)

[Learn more about security overview](https://docs.github.com/en/code-security/security-overview/exploring-security-alerts)  
[Learn more about GitHub Advanced Security](https://github.com/features/security)