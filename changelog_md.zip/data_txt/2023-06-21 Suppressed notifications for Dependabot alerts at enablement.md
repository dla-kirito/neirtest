June 21, 2023 

### Suppressed notifications for Dependabot alerts at enablement time[](#suppressed-notifications-for-dependabot-alerts-at-enablement-time)

At first time enablement, Dependabot will no longer send web or email notifications that summarize when a repository is populated with Dependabot alerts. Now, you'll have visibility across all your Dependabot alerts without immediately notifying developers who watch security alerts across your repository or organization. This change applies across all levels: repository, organization, and enterprise.

For any developers both watching a repository and opted in to receive Dependabot alert notifications, future notifications will still be sent for incoming alerts after enablement, as well as for daily and weekly digests.

### About this change[](#about-this-change)

We’ve been working to steadily improve our security alert notifications. As part of our notification strategy, notifications will no longer be sent at first time enablement for Dependabot alerts. Notifications are muted across all levels of enablement: repository, organization, and enterprise.

This change does not affect email digests or notifications on newly created alerts after enablement.

#### Available alert notifications and indicators[](#available-alert-notifications-and-indicators)

Today, when a dependency-based vulnerability is detected, Dependabot lets you know based on your user notifications settings and repository watching settings. You can opt to receive:

* Web-based notifications on alerts in your GitHub inbox
* Email-based notifications on alerts
* Email digests (weekly or daily roll-ups of alerts).

From the UI, you can also use the "Security" alert count in your repository navigation as an indicator for when your repository has alerts. This Security tab includes the count for all active Dependabot alerts, code scanning alerts, secret scanning alerts, and any security advisories that you have permissions to view.

Learn more about [Dependabot alerts](https://docs.github.com/en/code-security/dependabot/dependabot-alerts) and [configuring notifications for alerts](https://docs.github.com/en/code-security/dependabot/dependabot-alerts/configuring-notifications-for-dependabot-alerts).