June 7, 2023 

Searching code globally across GitHub.com already requires users to login, but starting today, we are extending that to include repository-scoped search as well.

To access the full capabilities of [GitHub’s powerful new code search and code navigation](https://github.com/features/code-search), create an account or log in to GitHub.com.