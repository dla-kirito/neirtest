October 5, 2023 

Repository rule insights now make finding more details about how someone merged specific code into your repos even easier.

## 🔍 Filter by status[](#filter-by-status)

If you want only to see bypassed rules, you can now filter rule insight by the status of the results.

No more scrolling through and sorting through all the insight activity to find that one bypass situation. You can now filter by **All Statuses**, **Pass**, **Fail**, and **Bypass**.

![Overview of selecting different rule insights status types. And showing the change between pass, fail, and bypass](https://github.com/github/release-assets/assets/7575792/24c19c4f-d101-4b6c-ae62-303e2e0efb0f)

## 👀 Clamoring for more insight into your rule insights?[](#clamoring-for-more-insight-into-your-rule-insights)

Well, now you have access to way more information, including who ✅ approved and ❌ denied a pull request. As well as having access to the results of all required status checks and deployment status states right in rule insights.

![Rule insight instance showing a specific passed status check.](https://github.com/github/release-assets/assets/7575792/c1fa5965-f45c-44bb-aeb0-c2c5f4128272)

## 👩‍💻 REST API Endpoint[](#rest-api-endpoint)

Want to look for ruleset failures for a specific app programmatically?  
With the new REST endpoint, you can now view and query rule insights via your favorite API tools.

### Repository Endpoint[](#repository-endpoint)

All repo insight activity

– `GET http://api.github.com/repos/{owner}/{repo}/rulesets/rule-suites`

Specific insight rule suite for a repository ruleset  
– `GET http://api.github.com/repos/{owner}/{repo}/rulesets/rule-suites/{rule _suite_id}`

### Organization Endpoint[](#organization-endpoint)

All org insight activity  
– `GET http://api.github.com/orgs/{org}/rulesets/rule-suites`

Specific insight rule suite for an organization ruleset  
– `GET http://api.github.com/orgs/{org}/rulesets/rule-suites/{rule_suite_id}`

[Click here to learn more](https://docs.github.com/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets). If you have feedback, please share and let us know in our [feedback discussion](https://github.com/orgs/community/discussions/61107).