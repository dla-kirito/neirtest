September 22, 2021 

We've added support for Java 16 standard language features (such as records and pattern matching) to CodeQL. Code using those features can now benefit from CodeQL's security analysis as part of code scanning.

We also continue to support older Java versions. CodeQL is able to analyze [code written in Java version 7 through 16](https://codeql.github.com/docs/codeql-overview/supported-languages-and-frameworks/#id5).

Learn more about [CodeQL](https://codeql.github.com/docs/codeql-overview/about-codeql/) and [code scanning](https://docs.github.com/en/github/finding-security-vulnerabilities-and-errors-in-your-code/about-code-scanning).