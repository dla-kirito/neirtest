May 17, 2023 

You may start seeing a temporary authorization hold after accruing usage of metered products (GitHub Actions, Packages, or Codespaces). This will appear as a pending charge in your account's payment method and will be immediately reversed as soon as your bank authorizes the amount. You will not be charged for the hold.

For more information, visit documentation for [Actions](https://docs.github.com/en/billing/managing-billing-for-github-actions/about-billing-for-github-actions), [Packages](https://docs.github.com/en/billing/managing-billing-for-github-packages/about-billing-for-github-packages), and [Codespaces](https://docs.github.com/en/billing/managing-billing-for-github-codespaces/about-billing-for-github-codespaces).