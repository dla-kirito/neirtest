October 12, 2023 

**Need to roll back a change to a ruleset? How about easily moving your ruleset around?**

With today’s public beta you now have new tools to manage your ruleset.

## Import and Export[](#import-and-export)

Rulesets are now easier to share and reuse, with the ability to import and export rulesets as JSON files. Giving you the ability to share rules across repositories and organizations or to share your favorite rules with the community. Which is what we’re doing. The [ruleset-recipes](https://github.com/github/ruleset-recipes) repository is home to a collection of pre-baked rulesets covering a number of popular scenarios ready for you to use.

![Gif walking through the steps outline above to import a ruleset from a JSON file.](https://github.com/github/release-assets/assets/7575792/8806fa8c-b874-4a4e-97ef-4f8c238f4d29)

## History[](#history)

If you are a repository or organization administrator of GitHub Enterprise cloud, we’re adding a history experience so you can track changes and revert rulesets. Now, it’s easy in the ruleset UI to see who changed a ruleset, when it happened, and what changed. Then, quickly get back to a known good state.

> Only changes made to a ruleset after the public beta are included in ruleset history.

![Gif walking through the step of using history, and selecting a ruleset version to restore.](https://github.com/github/release-assets/assets/7575792/71b2321f-64b8-4fa6-a8fc-8e4ac257632d)![Screenshot of Ruleset history comparison screen.](https://github.com/github/release-assets/assets/7575792/7994c855-f27c-4600-b1a7-299ed53380a4)

[Click here to learn more](https://docs.github.com/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets). If you have feedback, please share and [let us know in our community discussion](https://github.com/orgs/community/discussions/69918).