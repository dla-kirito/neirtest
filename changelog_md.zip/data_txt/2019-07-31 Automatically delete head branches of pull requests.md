July 31, 2019 

Repositories can now be set to delete the head branch of a pull request once it has merged into the base branch.

[Learn more about automatic deletion of branches on GitHub](https://help.github.com/en/articles/managing-the-automatic-deletion-of-branches)