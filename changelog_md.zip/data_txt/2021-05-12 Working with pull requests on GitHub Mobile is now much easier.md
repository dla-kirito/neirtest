May 12, 2021 

We are shipping improvements to pull request workflows on GitHub Mobile, making reviewing and merging pull requests much easier on the go!

* The pull request description has been moved into the header, providing quick context about the changes without having to scroll to the timeline. Longer descriptions are truncated and can be expanded inline with a tap.
* We brought the merge box designs more closely in line with GitHub.com. By using clear colors and iconography, it is easier to scan through the overall status of a pull request to understand the current state of reviews, checks, and overall mergeability.
* We added a contextual call to action in the Files Changed cell that will help people understand when their review is required, or when new changes have been pushed to the pull request since their last review.
* When reviews and checks are passing, pull requests can be merged directly from the view without having to open new dialogs. We've also built a fun animation that plays during a merge which will make working on the go feel more satisfying!

![](https://i0.wp.com/user-images.githubusercontent.com/1923260/117361178-8d963880-ae6e-11eb-9b89-bc7e00b26bd3.png?ssl=1)

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/github/feedback/discussions/categories/mobile-feedback) to help us improve.