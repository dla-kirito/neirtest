August 16, 2022 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [UNIwise](https://www.uniwise.co.uk/) to scan for their access tokens and help secure our mutual users on public and private repositories. The WISEflow API Key allows for institutions to manage key aspects of their license, such as exams and their life cycle. GitHub forwards access tokens found in public repositories to UNIwise, who will immediately disable the API Key and contact the customer. More information about WISEflow API Keys can be found [here](https://docs.wiseflow.net/)

GitHub Advanced Security customers can also scan for UNIwise tokens and block them from entering their private and public repositories with [push protection](https://github.blog/changelog/2022-04-04-secret-scanning-prevents-secret-leaks-with-protection-on-push/).

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Learn more about protecting pushes](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)