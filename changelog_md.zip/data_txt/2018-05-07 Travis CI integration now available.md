May 7, 2018 

Checks API now integrates with Travis CI, letting you share the results of your project’s branch and pull request builds with your team. View your build’s stages, jobs, results, and associated configuration to get a complete picture of your project’s health directly from GitHub.

[Read more](https://blog.github.com/2018-05-07-introducing-checks-api/)