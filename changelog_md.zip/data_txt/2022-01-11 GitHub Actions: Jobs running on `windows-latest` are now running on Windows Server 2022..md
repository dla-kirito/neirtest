January 11, 2022 

Windows Server 2022 became [generally available on GitHub-hosted runners](https://github.blog/changelog/2021-11-16-github-actions-windows-server-2022-with-visual-studio-2022-is-now-generally-available-on-github-hosted-runners/) in November 2021\. Over the next 8 weeks, jobs using the `windows-latest` runner label will migrate from Windows Server 2019 to Windows Server 2022\. During migration, you can determine if your job has migrated by viewing the `Virtual Environment` information in the `Set up job` step of your logs.

Use GitHub Actions to build your apps with the latest Visual Studio 2022 by updating your workflows to include `runs-on: windows-latest`

```yaml
jobs:
  build:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-dotnet@v1
      - name: Build
        run: dotnet build
      - name: Run tests
        run: dotnet test
```

The Windows Server 2022 runner image has different tools and tool versions than Windows Server 2019\. See the [full list](https://github.com/actions/virtual-environments/blob/main/images/win/Windows2022-Readme.md) of changed software.

If you spot any issues with your workflows when using Windows Server 2022, please let us know by creating an issue in the [virtual-environments repository](https://github.com/actions/virtual-environments).