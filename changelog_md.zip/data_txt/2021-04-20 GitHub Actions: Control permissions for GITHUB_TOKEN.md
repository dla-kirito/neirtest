April 20, 2021 

GitHub Actions now lets you control the permissions granted to the `GITHUB_TOKEN` secret.

The `GITHUB_TOKEN` is an automatically generated secret that lets you make authenticated calls to the GitHub API in your workflow runs. Actions generates a new token for each job and expires the token when a job completes. The token has `write` permissions to a number of [API endpoints](https://docs.github.com/en/actions/reference/authentication-in-a-workflow#permissions-for-the-github%5Ftoken) except in the case of pull requests from forks which are always `read`. These new settings allow you to follow a principle of least privilege in your workflows.

### Setting permissions in the workflow[](#setting-permissions-in-the-workflow)

A new `permissions` key supported at the workflow and job level enables you to specify which permissions you want for the token. Any permission that is absent from the list will be set to `none`.

```
permissions:
  actions: read|write|none
  checks: read|write|none
  contents: read|write|none
  deployments: read|write|none
  issues: read|write|none
  packages: read|write|none
  pull-requests: read|write|none
  repository-projects: read|write|none
  security-events: read|write|none
  statuses: read|write|none
```

Pull requests from public forks are still considered a special case and will receive a read token regardless of these settings.

### Setting the default permissions for the organization or repository[](#setting-the-default-permissions-for-the-organization-or-repository)

A new admin setting lets you set the default permissions for the token in your organization or repository.

You can choose between two options:

* Read/write for all scopes (current default)
* Read repo contents

Setting the default to `contents:read` is sufficient for any workflows that simply need to clone and build. If you need additional permissions you will need to specify those in your workflow yaml.

![image](https://i0.wp.com/user-images.githubusercontent.com/185122/115415646-1487b780-a1c5-11eb-99e2-1cafe81873b5.png?ssl=1)

[Learn more about setting the token permissions](https://docs.github.com/en/actions/reference/authentication-in-a-workflow#modifying-the-permissions-for-the-github%5Ftoken)

[For questions, visit the GitHub Actions community](https://github.community/c/code-to-cloud/github-actions/41)

[To see what’s next for Actions, visit our public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=label%3Aactions)