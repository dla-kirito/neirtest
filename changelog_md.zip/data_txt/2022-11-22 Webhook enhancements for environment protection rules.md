November 22, 2022 

A GitHub Actions workflow run is made up of one or more jobs and each job is associated with a check run. The [workflow\_job webhook](https://docs.github.com/en/developers/webhooks-and-events/webhooks/webhook-events-and-payloads#workflow%5Fjob) is sent during state transitions of a workflow job. The job state is included in the webhook payload as the `action` property, which currently takes the values of `queued`, `in_progress`, or `completed`.

With this change, the `workflow_job` webhook will now support a new `waiting` state whenever a job is waiting on an [environment protection rule](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#environment-protection-rules), aligning with the `waiting` state of the corresponding check run. This enables better insight into the progress of a job when using environment protection rules.

In addition, when a job refers to an [environment](https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#jobsjob%5Fidenvironment) key in its YAML definition, the resulting `workflow_job` webhook payload will also include a new property, `deployment` with the metadata about the deployment created by the check run.

[Learn more about using environments for deployment Jobs in a Workflow](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment)

For questions, visit the [GitHub Actions community.](https://github.com/orgs/community/discussions/categories/actions-and-packages)

To see what's next for Actions, visit our [public roadmap.](https://github.com/orgs/github/projects/4247)