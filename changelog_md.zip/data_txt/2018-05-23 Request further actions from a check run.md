May 23, 2018 

Building on the recent Checks API release, we’re providing further actions that users can request from a check run. This feature enables users to select an action offered by the app. For example, users can push a button in GitHub to request that the app fixes previously found linter errors.

[Learn more](https://developer.github.com/changes/2018-05-23-request-actions-on-checks/)