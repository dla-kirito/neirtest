April 4, 2022 

If you manage self-hosted runners for GitHub Actions, you can now specify shell scripts that run before the runner starts running a job from a workflow, and after a job completes.

This allows you to perform a task on your self-hosted runner before a job starts and after a job ends, so you can set up your execution environment and clean up after workflow runs to ensure a consistent state on the runner itself, without requiring users to add that to their workflows.

[Learn more about running scripts before or after a job](https://docs.github.com/actions/hosting-your-own-runners/running-scripts-before-or-after-a-job)

[For questions, visit the GitHub Actions community](https://github.community/c/code-to-cloud/github-actions/41)

[To see what's next for Actions, visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions)