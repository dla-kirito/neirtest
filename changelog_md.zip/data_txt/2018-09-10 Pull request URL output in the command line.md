September 10, 2018 

When you push a new branch to GitHub from the command line, you’ll now notice a URL within the output which you can copy in order to quickly open a new pull request.

![pull request URL output in the command line](https://github.blog/wp-content/uploads/2018/09/45300188-f6865080-b50d-11e8-9a82-866c9d7e9546.png?resize=1268%2C438)