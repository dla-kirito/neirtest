October 1, 2020 

[Temporary interaction limits](https://docs.github.com/en/free-pro-team@latest/github/building-a-strong-community/limiting-interactions-in-your-repository) give you control over who interacts with your public repositories. You can use them to force a cool-down period during heated discussions, or to prevent spam or abuse.

You can now set interaction limits for 24 hours, 3 days, 1 week, 1 month, or 6 months. This lets you control unwanted interactions on your projects.

![interaction-limits](https://i0.wp.com/user-images.githubusercontent.com/811954/94873697-67f61a80-04ac-11eb-82bc-ef77acf50fb7.gif?ssl=1)

You can set interaction limits for all public repositories in an [organization](https://docs.github.com/en/free-pro-team@latest/github/building-a-strong-community/limiting-interactions-in-your-organization), or for a single [repository](https://docs.github.com/en/free-pro-team@latest/github/building-a-strong-community/limiting-interactions-in-your-repository).