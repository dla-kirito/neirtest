October 6, 2023 

We now allow defining selected tag patterns for securing your deployments that can run against Actions environments.

Previously environments supported 'Protection Rules' for restricting deployments only for selected deployment branches. We are now enhancing this feature for securing deployments based on selected ["Deployment branches and tags"](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#deployment-branches-and-tags).

Admins who want to have more secure and controlled deployments can now specify selected tags or tag patterns on their protected environments – Ex: They could now define that only deployments triggered by tags that match the pattern of "releases/\*" could deploy to their "Production" environment.  
![Deployment Branches and Tags](https://i0.wp.com/user-images.githubusercontent.com/25389593/273319498-77aaed3b-9507-486e-9ff6-707e765efc90.png)

Learn more about securing environments using [deployment protection rules](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#deployment-protection-rules).  
For questions, visit the [GitHub Actions community](https://github.com/orgs/community/discussions/categories/actions-and-packages).  
To see what's next for Actions, visit our [public roadmap](https://github.com/orgs/github/projects/4247).