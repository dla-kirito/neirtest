January 20, 2023 

![gif of adding note to blocked user](https://i0.wp.com/user-images.githubusercontent.com/1305617/213721658-94e5920f-8732-4799-ab3a-3b90821adf5b.gif?ssl=1)

You can now add a note to describe why the blocking of a user took place, to provide projects and teams with the context around privacy and safety decisions. Notes on blocked users at the organization level will be visible to the owners and moderators of that organization. Notes on blocked users from your personal account will be visible just to you.