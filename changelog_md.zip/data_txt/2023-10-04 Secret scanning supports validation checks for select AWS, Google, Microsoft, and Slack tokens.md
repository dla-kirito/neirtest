October 4, 2023 

GitHub Advanced Security customers that have [validity checks](https://github.blog/changelog/2023-04-28-secret-scanning-now-supports-validation-checks-for-supported-partner-patterns/) enabled will see the validation status for select AWS, Google, Microsoft, and Slack tokens on the alert. 

The following tokens are supported: 

* aws\_access\_key\_id
* aws\_secret\_access\_key
* aws\_session\_token
* aws\_temporary\_access\_key\_id
* aws\_secret\_access\_key
* google\_oauth\_access\_token
* google\_api\_key
* nuget\_api\_key
* slack\_api\_token

AWS tokens will have validation checks performed periodically in the background, with [on-demand validity checks](https://github.blog/changelog/2023-08-11-secret-scanning-supports-on-demand-token-validity-checks/) to come in the future. 

View our [supported secrets documentation](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/secret-scanning-patterns#supported-secrets) to keep up to date as we expand validation support. 

* [Learn more about secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning)
* [Become a secret scanning partner](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/secret-scanning-partner-program)
* Got feedback? Open a discussion in our [code security community](https://github.com/orgs/community/discussions/categories/code-security)