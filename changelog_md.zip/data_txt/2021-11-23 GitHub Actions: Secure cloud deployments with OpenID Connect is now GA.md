November 23, 2021 

The OpenID Connect (OIDC) support for secure cloud deployments with GitHub Actions is now generally available.You can configure your workflows to request short-lived access tokens that are automatically rotated for each deployment.

Learn more about hardening your GitHub workflows using OpenID Connect [in our Docs](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments) and on the [GitHub Blog](https://github.blog/2021-11-23-secure-deployments-openid-connect-github-actions-generally-available/).