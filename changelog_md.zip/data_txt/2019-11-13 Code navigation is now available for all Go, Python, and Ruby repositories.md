November 13, 2019 

Jump to definition and find all references are now available for all Go, Python, and Ruby repositories on GitHub, with more languages coming soon. When viewing a Go, Python, or Ruby file on GitHub.com, clicking on a function or method name exposes a code navigation card with links to all of its definitions and references within the same repository. We use the [semantic library](https://github.com/github/semantic) to find definitions and call sites in your code.

[Learn more about jump to definition and find all references](https://help.github.com/en/github/managing-files-in-a-repository/navigating-code-on-github)

[Check out the semantic library](https://github.com/github/semantic)