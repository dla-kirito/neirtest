November 1, 2021 

You can now use GitHub Actions to run workflows when branch protection rules change on a repository. For more info, see [our docs](https://docs.github.com/en/actions/learn-github-actions/events-that-trigger-workflows#branch%5Fprotection%5Frule).