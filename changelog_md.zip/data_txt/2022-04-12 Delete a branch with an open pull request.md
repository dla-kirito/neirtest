April 12, 2022 

Previously, GitHub's web UI did not allow deleting a branch that was associated with an open pull request. Now you can delete such a branch from the UI. However, doing so will close all open pull requests associated with the branch. Before the branch is deleted, you must confirm that the pull requests may be closed.

![Confirm deleting a branch](https://i0.wp.com/user-images.githubusercontent.com/90000203/163011276-15060d2d-8a66-44e6-8c89-bef1c58fcb0b.png?ssl=1)

[Read more about working with branches](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-branches).

[Read more about collaborating with pull requests](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests).