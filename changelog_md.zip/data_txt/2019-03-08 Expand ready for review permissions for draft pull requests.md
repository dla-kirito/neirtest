March 8, 2019 

Any user with repository write permissions will now be able to click the \`Ready for review\` button on a [draft pull request](https://github.blog/2019-02-14-introducing-draft-pull-requests/) in order to enable mergeability.

[Learn more about draft pull requests on GitHub](https://help.github.com/en/articles/about-pull-requests#draft-pull-requests)