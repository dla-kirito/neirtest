December 2, 2021 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans may prevent data leaks and any fraud associated with exposed data.

We have partnered with [Typeform](https://www.typeform.com/) to scan for their access tokens and help secure our mutual users. Typeform API tokens allow Typeform users to create forms, retrieve responses, and configure webhooks. More information about Typeform API tokens can be found [here](https://developer.typeform.com/get-started/personal-access-token/).

We’ll forward access tokens found in public repositories to Typeform, who will verify and automatically disable the token. Typeform will then notify the user with the detection details (token name, where it was detected, and the token scopes).

We continue to welcome new partners for public repo secret scanning. GitHub Advanced Security customers can also scan their private repositories for leaked secrets.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)