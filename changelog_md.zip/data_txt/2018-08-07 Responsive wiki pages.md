August 7, 2018 

We have updated all wiki pages to be responsive so you can more easily view and edit a repository’s wiki page.

[Learn more about GitHub wikis](https://help.github.com/articles/about-github-wikis/)