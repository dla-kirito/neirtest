February 14, 2023 

GitHub Copilot for Business is now available to Free, Team, and GitHub Enterprise Cloud customers. This update allows more organizations to give their developers access to GitHub Copilot’s powerful AI while providing administrators with license management and centralized policy controls on top of industry-leading privacy.

With this announcement, we’re also excited to share that we’ve made enhancements to:  
– security vulnerability filtering  
– improved Codex model  
– VPN proxy support via self-signed certs

These improvement mean that GitHub Copilot’s code suggestions are more secure, better utilized, and work in more environments.

* [Read our blog post for more details on this announcement](https://github.blog/2023-02-14-github-copilot-for-business-is-now-available)
* [Get started with Copilot for Business today](https://github.com/github-copilot/business%5Fsignup)