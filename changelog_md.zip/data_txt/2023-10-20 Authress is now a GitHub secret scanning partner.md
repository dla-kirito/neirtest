October 20, 2023 

GitHub secret scanning protects users by searching repositories for known types of secrets such as tokens and private keys. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [Authress](https://authress.io/?utm%5Fsource=github&utm%5Fmedium=announcement&utm%5Fcampaign=secrets&utm%5Fcontent=product) to scan for their service client access keys and their user API tokens to help secure our mutual users in public repositories. Authress access keys allow users to secure applications and platforms through machine-to-machine authentication and they enable granular resource-based authorization. GitHub will forward any exposed access keys found in public repositories to Authress, who will automatically revoke the exposed access key, create an audit trail message that can be ingested by SIEM technologies, and send an email alert to your Authress account admin. [Read more information about Authress API access keys](https://authress.io/knowledge-base/docs/authorization/service-clients/secrets-scanning/?utm%5Fsource=github&utm%5Fmedium=announcement&utm%5Fcampaign=secrets&utm%5Fcontent=more%5Finformation).

All users can scan for and block Authress keys from entering their public repositories for free with [push protection](https://docs.github.com/en/code-security/secret-scanning/protecting-pushes-with-secret-scanning). GitHub Advanced Security customers can also scan for and block Authress keys in their private repositories.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)