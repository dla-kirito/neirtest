August 24, 2022 

GitHub Enterprise Cloud administrators who have IP allow lists set up for their enterprises, organizations, or GitHub Apps can now check whether an IP address is permitted within the IP allow list.

To learn more, read our 'Checking if an IP address is permitted' documentation for [enterprises](https://docs.github.com/en/enterprise-cloud@latest/admin/policies/enforcing-policies-for-your-enterprise/enforcing-policies-for-security-settings-in-your-enterprise#checking-if-an-ip-address-is-permitted) and [organizations](https://docs.github.com/en/enterprise-cloud@latest/organizations/keeping-your-organization-secure/managing-security-settings-for-your-organization/managing-allowed-ip-addresses-for-your-organization#checking-if-an-ip-address-is-permitted).