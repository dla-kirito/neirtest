May 16, 2022 

Dependabot alerts now show all affected files if your repository code is calling known vulnerable functions from the dependency’s vulnerability. Previously, we only highlighted one of these matches on an alert’s detail page, but now users can view all affected files.

This feature supports our public beta of [exposure detection](https://github.blog/2022-04-14-dependabot-alerts-now-surface-if-code-is-calling-vulnerability) for Python alerts. After beta testing with Python we will add support for other ecosystems. Keep an eye on the [public roadmap for more information](https://github.com/github/roadmap).

For more information, see our [product documentation](https://docs.github.com/en/code-security/dependabot/dependabot-alerts/viewing-and-updating-dependabot-alerts#about-the-detection-of-calls-to-vulnerable-functions).