October 10, 2023 

You can now filter and return only answered, unanswered, or all discussions through the GraphQL API.