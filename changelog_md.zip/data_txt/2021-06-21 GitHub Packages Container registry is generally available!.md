June 21, 2021 

GitHub Packages Container registry, [ghcr.io](https://ghcr.io), is now generally available! Container registry provides the best developer experience for publishing, managing, and consuming containers on GitHub. For more information, check out the [Container registry general availability blog post](https://github.blog/2021-06-21-github-packages-container-registry-generally-available/).

Learn more about [GitHub Container registry](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry)

[For questions, visit the GitHub Packages community](https://github.community/c/code-to-cloud/github-packages/43)

[To see what's next for Packages, visit our public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=label%3Apackages)