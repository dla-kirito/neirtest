July 22, 2020 

We’ve made some changes in GitHub Actions to better support communities who have chosen to move away from using `master` as their default branch name.

We have updated all of our [starter workflows](https://github.com/actions/starter-workflows) to use a new `$default-branch` macro rather than the previously hardcoded `master`. You can take advantage of this feature in your [custom starter workflow templates as well](https://docs.github.com/en/actions/configuring-and-managing-workflows/sharing-workflow-templates-within-your-organization).

In addition, we have renamed the default branch for most of the GitHub-authored actions from `master` to `main`. All of your workflows that reference the old branch name will still work. However, you’ll see a prompt to change to the new name when you edit the workflow on the web.

This change is one of many changes GitHub is making to support projects and maintainers that want to rename their default branch. To learn more about the changes we’re making, see [github/renaming](https://github.com/github/renaming/).