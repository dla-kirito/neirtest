May 3, 2023 

GitHub Desktop 3.2.3 makes force pushing and fetching through the newly added fetch/pull dropdown menu items as well as adding pull request comment notifications. Since 3.2.1, GitHub Desktop has also released more than 30 accessibility improvements.

### Force-pushing and Fetching[](#force-pushing-and-fetching)

In [GitHub Desktop 3.1.5](https://github.blog/changelog/2023-01-27-github-desktop-improves-force-pushing-and-fetching-along-with-many-great-open-source-contributions/), we added the ability to force-push and fetch to the `Repository` menu item when applicable. Now, when those menu items would be available, the pull/push/fetch button becomes a dropdown so users can easily force push or fetch.

![Gif that shows a user pressing fetch to put the repository in a diverged state. Then, shows the user opening the new dropdown and force pushing their changes to overwrite the changes in the remote.](https://i0.wp.com/user-images.githubusercontent.com/75402236/235489783-3e4c8290-fd79-48da-b446-03c43e82697a.gif?ssl=1)

### Pull Request Comment Notifications[](#pull-request-comment-notifications)

If you have been enjoying our Pull Request notifications on your repositories, you will be happy to hear we have expanded those notifications to include when someone has commented on your pull request as well so that you can keep up to date on the latest conversations happening on your pull request.

### Accessibility[](#accessibility)

GitHub Desktop is actively working to improve accessibility in support of [GitHub's mission to be a home for all developers](https://accessibility.github.com/).

#### GitHub Desktop 3.2.1[](#github-desktop-321)

* Misattributed warning is announced in 'Git' preferences/options by screen readers – [#16239](https://github.com/desktop/desktop/pull/16239)
* The Preferences/Options dialog content is still visible when zoomed at 200% – [#16317](https://github.com/desktop/desktop/pull/16317)
* Up/down arrow can be used to navigate autocomplete lists like emoji again – [#16044](https://github.com/desktop/desktop/pull/16044)
* Focus history and changes list when accessed via keyboard shortcut or menu – [#16360](https://github.com/desktop/desktop/pull/16360)
* On Windows, app level menu bar and menu items are announced by screen readers – [#16315](https://github.com/desktop/desktop/pull/16315)
* Keyboard shortcuts for resizing app sidebar and file lists – [#16332](https://github.com/desktop/desktop/pull/16332)
* Misattributed commit popover does not clip when app is zoomed – [#16407](https://github.com/desktop/desktop/pull/16407)
* Accessibility improvements for the co-authors input – [#16335](https://github.com/desktop/desktop/pull/16335)
* Commit completion status is announced by screen readers – [#16371](https://github.com/desktop/desktop/pull/16371), [#16340](https://github.com/desktop/desktop/pull/16340)
* Improve accessibility of dialogs for screen reader users – [#16350](https://github.com/desktop/desktop/pull/16350)
* Accessibility improvements for autocompletion suggestions – [#16324](https://github.com/desktop/desktop/pull/16324)
* Learn more links are descriptive for screen readers – [#16274](https://github.com/desktop/desktop/pull/16274)
* Popover titles are announced by screen readers – [#16270](https://github.com/desktop/desktop/pull/16270)
* Show offset focus ring for buttons, vertical tabs etc – [#16288](https://github.com/desktop/desktop/pull/16288)
* Application main menu on Windows doesn't clip when zoom is set to 200% – [#16290](https://github.com/desktop/desktop/pull/16290)
* Button and text box contrast bumps – [#16287](https://github.com/desktop/desktop/pull/16287)
* Other email input in "Git" preferences/Options and misattributed popover email select have a screen readable label – [#16240](https://github.com/desktop/desktop/pull/16240)
* Add/remove co-authors button is now keyboard accessible – [#16200](https://github.com/desktop/desktop/pull/16200)

#### GitHub Desktop 3.2.3[](#github-desktop-323)

* NVDA reads number of suggestions when an autocompletion list shows up – [#16526](https://github.com/desktop/desktop/pull/16526)
* The undo commit confirmation modal message is screen reader announced – [#16472](https://github.com/desktop/desktop/pull/16472)
* Clipping and overlapping of the changes list is fixed at 200% zoom – [#16425](https://github.com/desktop/desktop/pull/16425)
* The commit message avatar is now a toggle tip making the commit author details keyboard accessible – [#16272](https://github.com/desktop/desktop/pull/16272)
* The commit length hint is keyboard and screen reader accessible – [#16449](https://github.com/desktop/desktop/pull/16449)
* The changes list header checkbox tooltip description is announced by screen readers – [#16457](https://github.com/desktop/desktop/pull/16457)
* The changes list header checkbox tooltip is keyboard accessible – [#16487](https://github.com/desktop/desktop/pull/16487)
* Announce a file's state of inclusion in the commit on the changes list – [#16420](https://github.com/desktop/desktop/pull/16420)
* Display focus ring around focused control after dismissing a dialog – [#16528](https://github.com/desktop/desktop/pull/16528)
* Identify the changes list and history commit list as the changes and history tab panels for screen readers – [#16463](https://github.com/desktop/desktop/pull/16463)
* Windows title bar controls do not interrupt screen readers in browse mode – [#16483](https://github.com/desktop/desktop/pull/16483)
* Make radio theme selection look like radio buttons. – [#16525](https://github.com/desktop/desktop/pull/16525)
* Improve accessibility of GitHub Enterprise login flow – [#16567"](https://github.com/desktop/desktop/pull/%22)
* Screen readers announce sign in errors – [#16556"](https://github.com/desktop/desktop/pull/%22)

Automatic updates will roll out progressively, or you can [download the latest GitHub Desktop here.](https://desktop.github.com)