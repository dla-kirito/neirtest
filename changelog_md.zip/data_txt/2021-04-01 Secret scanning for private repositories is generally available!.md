April 1, 2021 

Secret scanning for private repositories is now generally available for all GitHub Advanced Security customers on GitHub Enterprise Cloud. Since announcing the [beta](https://github.blog/changelog/2020-05-06-github-advanced-security-secret-scanning-for-private-repositories-now-available-in-limited-public-beta/) last year, we've:

* Expanded our [pattern coverage](https://docs.github.com/en/code-security/secret-security/about-secret-scanning#about-secret-scanning-for-private-repositories) from 24 partners to 37
* Added an [API](https://docs.github.com/en/rest/reference/secret-scanning) and [webhooks](https://docs.github.com/en/developers/webhooks-and-events/webhook-events-and-payloads#secret%5Fscanning%5Falert)
* Added [notifications for commit authors](https://github.blog/changelog/2021-03-05-secret-scanning-notifications-for-commit-authors-on-private-repositories/) when they commit secrets
* Updated the index view to made it easy to triage secrets in bulk
* Reduced the false positive rate on many patterns

We have lots more improvements planned for secret scanning, including [support for custom patterns](https://github.com/github/roadmap/projects/1#card-54656341) in June.

[Learn more about secret scanning](https://docs.github.com/en/code-security/secret-security/about-secret-scanning)  
[Learn more about GitHub Advanced Security](https://github.com/features/security)