September 17, 2019 

On September 30, 2019, GitHub Actions will stop running workflows written in HCL. You’ll need to [migrate your HCL workflows to the new YAML syntax](https://help.github.com/en/articles/migrating-github-actions-from-hcl-syntax-to-yaml-syntax) using the migration script.