June 30, 2020 

Releases now show a preview of the version number, repo name, and release notes when shared on social media sites like Twitter and Facebook.

Previously a link to <https://github.com/github/fetch/releases/tag/v3.0.0> would have looked like this:

![Social preview of a link to a release before this change](https://i0.wp.com/user-images.githubusercontent.com/811954/85962857-13ec1d80-ba07-11ea-8a93-4c3bdecc9e7e.png?w=438&ssl=1)

Now it looks like this:

![Social preview of a link to a release after this change with a custom title and description](https://i0.wp.com/user-images.githubusercontent.com/811954/85962948-8826c100-ba07-11ea-8b22-42ad4bc3446c.png?w=438&ssl=1)