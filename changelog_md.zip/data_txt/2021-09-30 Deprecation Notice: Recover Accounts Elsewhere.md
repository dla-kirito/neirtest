September 30, 2021 

[Recover Accounts Elsewhere](https://docs.github.com/authentication/securing-your-account-with-two-factor-authentication-2fa/recovering-your-account-if-you-lose-your-2fa-credentials#authenticating-with-an-account-recovery-token) allows a user to store a recovery token with a third-party recovery partner to use as a recovery method when their account is protected by two-factor authentication. Effective immediately, we will no longer be allowing new recovery tokens to be stored using Recover Accounts Elsewhere.

On **December 1st, 2021**, account recovery tokens stored using Recover Accounts Elsewhere will no longer be accepted as a recovery option when contacting support to recover access to your account. You will still be able to use our [other recovery mechanisms](https://docs.github.com/authentication/securing-your-account-with-two-factor-authentication-2fa/recovering-your-account-if-you-lose-your-2fa-credentials#authenticating-with-a-verified-device-ssh-token-or-personal-access-token) to recover your account.

If you have registered an account recovery token using this feature, we recommend you take this opportunity to [download your two-factor recovery codes](https://docs.github.com/authentication/securing-your-account-with-two-factor-authentication-2fa/configuring-two-factor-authentication-recovery-methods#downloading-your-two-factor-authentication-recovery-codes). You can also revoke your recovery tokens using these steps:

1. Navigate to the [Account Security](https://github.com/settings/security) page.
2. Scroll down to "Recovery tokens" and client "Edit".
3. Click "Revoke token" for each token.

We'll be sending occasional email notifications throughout the deprecation period to all users with recovery tokens registered.

Questions? Take a look at our [updated documentation on account recovery](https://docs.github.com/authentication/securing-your-account-with-two-factor-authentication-2fa/recovering-your-account-if-you-lose-your-2fa-credentials), or [contact GitHub Support](https://support.github.com/contact).