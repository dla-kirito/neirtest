June 20, 2022 

Enterprise owners can join organizations in their enterprise via the enterprise account `Organizations` page: `https://github.com/enterprises/<enterprise>` as either a member or an admin. This feature has graduated from beta to general availability.

To learn more, please read our article about [managing your role within an organization your enterprise owns](https://docs.github.com/en/enterprise-cloud@latest/admin/user-management/managing-organizations-in-your-enterprise/managing-your-role-in-an-organization-owned-by-your-enterprise).