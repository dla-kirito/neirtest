October 4, 2022 

![Actions on GitHub Mobile](https://i0.wp.com/user-images.githubusercontent.com/976424/192228952-cd1793ae-99d3-4c17-9383-b20695d93c34.jpg?ssl=1)

Actions are coming to GitHub Mobile! You can now view and manage your pull requests on the go.

Tapping on checks when viewing a pull request now leads to a vastly improved experience, including the ability to view a workflow-run, its jobs and even the logs of completed steps inside.

A run did not go as planned? No problem. GitHub Mobile now supports re-running single jobs, failed jobs as well as entire workflows directly from your mobile device. For checks that are already running, support for cancellation has been added as well.

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/orgs/community/discussions/categories/mobile) to help us improve.