August 31, 2020 

Account and billing admins can now provide a list of email addresses to receive billing notifications, including threshold notifications for Actions and Packages.

The email addresses may belong to users such as repo admins, individuals who are not actually part of your GitHub organization (e.g. in the procurement department at your company), or even be distribution lists.

Visit the [documentation on how to set a billing email](https://docs.github.com/github/setting-up-and-managing-billing-and-payments-on-github/setting-your-billing-email) to learn more.