December 15, 2022 

Previously, GitHub Advanced Security customers could enable push protection for all [patterns supported by default](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/secret-scanning-patterns#supported-secrets-for-push-protection).

Now, admins can also enable [push protection for any custom pattern](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/defining-custom-patterns-for-secret-scanning) defined at the repository or organization level. Push protection for enterprise-level custom patterns will come in January.

![blocked custom pattern](https://i0.wp.com/user-images.githubusercontent.com/81782111/207498360-10037928-bd7b-4379-83db-16e234db4880.png?w=960&ssl=1)

* [Read our blog post to learn how you can push protect your custom patterns](https://github.blog/2022-12-15-github-advanced-security-customers-can-now-push-protect-their-custom-patterns)
* [Learn how to secure your repositories with secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning)