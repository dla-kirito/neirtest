March 23, 2020 

Token leaks are one of the most common security mistakes, and they can have disastrous consequences. GitHub token scanning looks for leaked tokens in public repositories and works with the issuer to notify the developer and/or revoke the token as appropriate. This protects users from fraud and data leaks. Starting today, GitHub has partnered with [Adafruit](https://io.adafruit.com/) and [Samsara](https://www.samsara.com/) to scan for their respective developer tokens! This brings our [total number of token scanning partners](https://help.github.com/en/articles/about-token-scanning) to 21.

* [Learn more about token scanning](https://help.github.com/en/articles/about-token-scanning)
* [Partner with GitHub on token scanning](https://developer.github.com/partnerships/token-scanning/)