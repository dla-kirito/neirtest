April 1, 2021 

You can now configure which events you would like to be notified about on GitHub Mobile, [just like on GitHub.com](/2020-11-19-custom-notifications-controls/). Tap the "Watch" button for a repository to customize your watch settings:

![](https://i0.wp.com/user-images.githubusercontent.com/15086212/111175020-41cebd80-85a8-11eb-8555-339a29e2d539.png?w=346&ssl=1)

![Screenshot of watch settings for an individual repository on GitHub for iOS](https://i0.wp.com/user-images.githubusercontent.com/52571688/109631879-b46e8080-7b46-11eb-8f43-65274f422f23.png?w=320&ssl=1)

[Learn more about configuring your watch settings](https://docs.github.com/en/github/managing-subscriptions-and-notifications-on-github/viewing-your-subscriptions#configuring-your-watch-settings-for-an-individual-repository).

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/github/feedback/discussions/new) to help us improve.