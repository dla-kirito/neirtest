March 21, 2023 

Today we are making the [granular access token](https://docs.npmjs.com/about-access-tokens#about-granular-access-tokens) feature on npm generally available.

Granular access token, allows you to:

* Restrict token access to specific packages and/or scopes
* Grant tokens access to specific organizations for org and user management
* Set a token expiration date
* Limit token access based on IP address ranges
* Select between read and/or write access for the token

We recommend using granular access tokens with least privileges for automating your publishing and org management activities. You can allow your package to be published without 2FA using granular access tokens from your trusted CI/CD systems. Additionally, you can also [configure your package to require 2FA](https://docs.npmjs.com/requiring-2fa-for-package-publishing-and-settings-modification) when publishing from a local machine to defend against account hijacking.

Read more about creating a granular access token [here](https://docs.npmjs.com/creating-and-viewing-access-tokens#creating-granular-access-tokens-on-the-website).