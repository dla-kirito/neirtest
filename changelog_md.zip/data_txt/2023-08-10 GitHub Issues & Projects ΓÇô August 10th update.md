August 10, 2023 

Today’s Changelog brings you the brand new slice by, updates to issue forms, and a group menu across layouts!

## 🍕 Slice by[](#slice-by)

You can now slice by field values in your project views! Configuring a `Slice by` field allows you to quickly toggle through and review your project items broken down by a field, saving you additional filters and views to quickly understand the state and details of your project. While you can slice by your issue and project fields to customize your view, some helpful slice by views include:  
– Single select fields to view items broken up by status, priority, or team  
– `Labels` to group items by repository labels  
– `Assignees` to see who is working on what

![slice_by](https://i0.wp.com/user-images.githubusercontent.com/2180038/259850616-e8bed780-945e-475d-bb9c-4659b6bd2d34.jpg?ssl=1)

Select a `Slice by` field from the view configuration menu. This will pull the field values into the panel on the left, allowing you to click through the values in the list to adjust the items shown in the view.

<//user-images.githubusercontent.com/101840513/259834557-557ecbe6-faab-48e7-8c3d-4c107c55095b.mp4>

See it in action on the [GitHub public roadmap](https://github.com/orgs/github/projects/4247/views/7?sliceBy%5BcolumnId%5D=Labels&sliceBy%5Bvalue%5D=all), and check out the [documentation](https://docs.github.com/en/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/customizing-the-table-layout#slicing-by-field-values) for more details.

## 📋 Updates to issue forms[](#updates-to-issue-forms)

You can now configure custom issue forms to automatically add an issue to a project as well as set defaults for drop downs by adding a YAML form definition file to the `/.github/ISSUE_TEMPLATE` folder in your repository.

![issue form yaml syntax](https://i0.wp.com/user-images.githubusercontent.com/2180038/259850688-8ec0dc37-1178-4489-af74-de4cb0b0e07b.png?ssl=1)

For more comprehensive instructions on syntax for issue forms, check out the [documentation](https://docs.github.com/en/communities/using-templates-to-encourage-useful-issues-and-pull-requests/syntax-for-issue-forms).

We’re looking to improve the experience around issue forms and templates. If you have any feedback 👉 drop a comment in our [community discussion](https://github.com/orgs/community/discussions/63402)!

## Group menu for item and group actions[](#group-menu-for-item-and-group-actions)

We’ve added a group menu to quickly take action on items in a group or on the group itself. Click `...` from the group header on your tables, boards, or roadmaps to archive or delete all items in a group, edit the group details directly, hide the group from the view, or delete it from your project.

![group menu](https://i0.wp.com/user-images.githubusercontent.com/101840513/259855714-7d8e5230-a000-4597-9339-9b9fed32d54d.jpg?ssl=1)

## ✨ Bug fixes and improvements[](#bug-fixes-and-improvements)

* Fixed keyboard navigation and focus when navigating to `Make a copy` from the project `...` menu
* Fixed group header spacing on the roadmap layout
* Fixed a bug where using the `@next` filter qualifier for iteration fields was referencing the incorrect iteration
* Fixed a bug with the numerical `Field sum` decimal precision

See how to use GitHub for project planning with [GitHub Issues](http://github.com/features/issues), check out what’s on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/issues).

Questions or suggestions? Join the conversation in the [community discussion](https://github.com/orgs/community/discussions/63381).