June 5, 2018 

The 2.13.4, 2.12.12, 2.11.18 and 2.10.24 releases for GitHub Enterprise are now available for download from <https://enterprise.github.com/releases>.

View the full release notes:

* <https://enterprise.github.com/releases/2.13.4/notes>
* <https://enterprise.github.com/releases/2.12.12/notes>
* <https://enterprise.github.com/releases/2.11.18/notes>
* <https://enterprise.github.com/releases/2.10.24/notes>