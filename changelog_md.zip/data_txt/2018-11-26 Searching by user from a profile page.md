November 26, 2018 

When searching from a user profile page you now have the option to search by “this user”.

[Learn more about searching on GitHub](https://help.github.com/articles/about-searching-on-github/)