March 26, 2020 

GitHub Desktop 2.4 helps you get started working more quickly and helps keep you in your flow. It includes three primary features:

* Automated configuration of Git proxy environment variables
* Quickly create an issue for the repository you're in from GitHub Desktop
* GitHub Desktop Dark Theme is out of beta

[Learn more about GitHub Desktop](https://desktop.github.com)