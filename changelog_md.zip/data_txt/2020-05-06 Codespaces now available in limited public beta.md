May 6, 2020 

Now available in limited public beta, Codespaces allows for fully-featured dev environments directly inside of GitHub. With Codespaces, you have access to a containerized and customizable Visual Studio Code experience that can be configured to load your dotfiles, settings, and any extensions.

[Learn more about Codespaces and request early access](https://github.com/features/codespaces)