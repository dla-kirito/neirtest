June 18, 2020 

You can now set your repository to any available visibility option – public, private, or internal – from a single dialog in the repository's settings. Previously, you had to navigate separate sections, buttons, and dialog boxes for changing between public and private, and between private and internal.

[Learn more about managing repository visibility](https://docs.github.com/en/github/administering-a-repository/setting-repository-visibility)