August 22, 2022 

Today we are deprecating the theme picker we introduced in [2012](https://github.blog/2012-04-02-instantly-beautiful-project-pages/) for GitHub Pages.

While this experience allowed users to preview a theme in the user interface, we are doing this to increase the security of [github.com](https://github.com).

You can of course continue to use any [Jekyll theme](https://jekyllrb.com/docs/themes/) you want with Pages, and publish beautiful sites with a [small configuration change](https://docs.github.com/en/pages/setting-up-a-github-pages-site-with-jekyll/adding-a-theme-to-your-github-pages-site-using-jekyll).