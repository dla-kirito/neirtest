January 25, 2022 

You can now reference local reusable workflows more easily. With this release, reusable workflows that are in the same repository as the calling repository can be referenced with just the path and filename: {path}/{filename}.

For example:

```
jobs:
  call-workflow-in-local-repo:
    uses: ./.github/workflows/workflow-2.yml
```

When referenced this way, the called workflow will be from the same commit as the caller workflow.

[For questions, visit the GitHub Actions community](https://github.community/c/code-to-cloud/github-actions/41)

[To see what's next for Actions, visit our public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=actions)