September 13, 2022 

In order to streamline sponsoring maintainers, we're changing the custom amount settings for GitHub Sponsors. Starting October 3rd, 2022, all Sponsors profiles will have custom amounts enabled by default.

* On that date, if you haven't enabled custom amounts previously, we will set your minimum custom amount to either your lowest published monthly tier or your lowest published one-time tier, whichever is higher. If you wish to change the minimum, you can enable custom amounts on your Sponsors dashboard (if not already enabled), and then set it to your preferred minimum.
* If you set a minimum custom amount before October 3, 2022, it will remain unchanged.

![Custom sponsorship amount settings on the GitHub Sponsors dashboard for maintainers](https://i0.wp.com/user-images.githubusercontent.com/82317/189940509-2238781e-46a6-4ffa-b495-354c8c8a9b38.png?ssl=1)