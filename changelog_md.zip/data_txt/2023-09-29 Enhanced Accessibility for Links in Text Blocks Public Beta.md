September 29, 2023 

To improve accessibility for our users, we've introduced a new [accessibility setting](https://github.com/settings/accessibility) to underline links within text blocks. Links should be easily distinguishable from surrounding text, not just by color but by styling. You can now toggle an accessibility setting to either "show" or "hide" underlines for links in text blocks, ensuring clear visibility and differentiation. You can learn more about this functionality in the [documentation](https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-personal-account-on-github/managing-user-account-settings/managing-accessibility-settings#managing-the-appearance-of-links).

During this public beta phase, your feedback is invaluable. If you spot a link within a text block that isn’t underlined when the setting is enabled, [please let us know](https://gh.io/link%5Funderline%5Ffeedback).

Thank you for supporting our commitment to making GitHub more accessible for everyone!