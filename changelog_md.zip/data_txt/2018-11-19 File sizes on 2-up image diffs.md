November 19, 2018 

2-up image diffs will now also display file size alongside the width and height data. This is particularly useful when checking file size differences due to image optimization.

[Learn more about 2-up image diffs](https://help.github.com/articles/rendering-and-diffing-images/#2-up)