October 23, 2023 

New updates to the branches and commits pages are now in feature preview. These updates are focused on improved navigation, performance, and making these experiences more accessible.

# Branches[](#branches)

![Screenshot showing new branches page on GitHub Docs Repository](https://github.com/github/release-assets/assets/7575792/3b452dab-e7fe-41a8-a846-422ad8a40c63)

We added clarity to the list header explaining what each section of the branches page does. Stale branches are now hidden by default to speed up page load times.

![GIF walkthrough of branches page showing the new UI and clicking on various elements to show new functionality.](https://github.com/github/release-assets/assets/7575792/f162f7b1-fd54-43b0-bc2f-5296f2288aeb)

# Commits[](#commits)

![Screen shot showing new commits page on GitHub Docs Repository](https://github.com/github/release-assets/assets/7575792/844c7152-33f1-4323-b8b3-c87bbafc6a26)

You can now filter commits by a date range and collapse the list per day to find the commits that matter to you quickly.

![GIF showing the commits page filtering by date in a calendar and collapsing commits for a whole day](https://github.com/github/release-assets/assets/7575792/f4ff6a82-b7b1-4376-be4e-4059f86bb7bf)

[Click here](https://github.com/orgs/community/discussions/70668) if you have feedback and let us know in our community discussion.