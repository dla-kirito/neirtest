October 16, 2019 

GitHub Actions are triggered by webhook events. The original payload of the event is stored in a file that actions can read at workflow/event.json ([see the docs](https://help.github.com/en/articles/virtual-environments-for-github-actions#filesystems-on-github-hosted-machines)). We’ve made a slight change to the payload for push events in Actions. The following attributes have been removed from the commits section of push payloads for Actions:

* `added`
* `removed`
* `modified`

These diffs can instead be requested using the API <https://developer.github.com/v3/repos/commits/#get-a-single-commit>.