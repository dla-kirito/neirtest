March 23, 2021 

Security researchers provide a critical service to developers by identifying vulnerable software, but unfortunately, many developers don't know the people behind this work.

GitHub Security Advisories allow developers to provide researchers with credit on their reported vulnerabilities, and these already make their way into the Advisory Database. This change adds Advisory credits into the researcher's GitHub profile, and to profile hovercards when viewed in the context of a security advisory. 

Learn more about [GitHub's Advisory Database](https://docs.github.com/en/github/managing-security-vulnerabilities/browsing-security-vulnerabilities-in-the-github-advisory-database)

Learn more about disclosing vulnerabilities with [Security Advisories](https://docs.github.com/en/github/managing-security-vulnerabilities/managing-security-vulnerabilities-in-your-project)