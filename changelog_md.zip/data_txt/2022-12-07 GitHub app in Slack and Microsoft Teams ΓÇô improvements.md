December 7, 2022 

We have made bunch of improvements to our GitHub app in Slack and Microsoft Teams.

### Slack[](#slack)

#### 1\. Introduced comment capability within Pull request notification cards[](#1-introduced-comment-capability-within-pull-request-notification-cards)

We have now added support to add comments on your pull requests directly from the notification card in Slack.  
![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/206164039-531a2cd0-1fea-4c35-9ba4-cd2555aa7edf.png?w=1023&ssl=1)

#### 2\. Introduced threading for Pull request notifications[](#2-introduced-threading-for-pull-request-notifications)

Notifications for any Pull request will be grouped under a parent card as replies. The parent card always shows the latest status of the PR along with other meta-data like title, description, reviewers, labels and checks. Threading gives context, improve collaboration and reduces noise in the channel.  
![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/206163756-ded8b5d7-1162-45db-b803-9eb33f5727fb.png?w=1023&ssl=1)

#### 3\. Added support to turn on/off threading for Issues and Pull requests[](#3-added-support-to-turn-onoff-threading-for-issues-and-pull-requests)

If you do not want to use threading or need some flexibility, we are also rolling out an option to turn on/off threading for issues and pull requests.  
![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/206141860-c66f09f8-663e-4f32-aae9-3c62db44c9ac.png?w=1023&ssl=1)

For more information, please visit the GitHub app guidance for [Slack](https://github.com/integrations/slack/blob/main/README.md#threading)

### Microsoft Teams[](#microsoft-teams)

#### 1\. Improved the create issue functionality[](#1-improved-the-create-issue-functionality)

You can now create issues with just a click, right from the place where you interact with your team i.e. from your channels and personal app.  
![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/206142645-d59a9bb0-7bc4-43e4-98e1-eaea695efcfb.png?w=1023&ssl=1)

* The content of the chat is automatically added into the description along with the link to the MS Teams conversation.
* The last used repo in the channel will be automatically filled in. However, you can go ahead and change to the repo if needed.
* You can optionally fill in labels, assignees and milestones when you create an issue.
* Once the issue is created you will receive a confirmation card in the channel where you created the issue.

#### 2\. Enhanced the PR notification cards in Channel and Personal App[](#2-enhanced-the-pr-notification-cards-in-channel-and-personal-app)

We made few UI improvements to the Pull request notifications experience in MS Teams.

* Introduced PR comment capability in GitHub personal app.
* Made few updates to the look and feel of the Pull request notification card.

![image](https://i0.wp.com/user-images.githubusercontent.com/25578249/206143058-69c1c942-bbcc-406b-b1bd-a2586fe8bfc6.png?w=1023&ssl=1)

For more information, please visit the GitHub app guidance for [Microsoft Teams](https://github.com/integrations/microsoft-teams/blob/main/Readme.md#move-conversations-into-next-steps)