June 1, 2022 

Users can now add a comment when dismissing a code scanning alert.  
![Add a dismissal comment to a code scanning alert](https://i0.wp.com/user-images.githubusercontent.com/19343236/168257711-e427ce78-ef12-44c7-9f1c-9bc9ddc32c0d.png?ssl=1)

It is optional to provide a dismissal comment. Dismissal comments are recorded in the alert timeline. They can also be set via the [code scanning REST API](https://docs.github.com/en/rest/code-scanning) when updating an alert, and retrieved through the new `dismissed_comment` attribute.

This feature is now available to all users on GitHub.com and will be released in GHES 3.6.