April 30, 2018 

Users can now request a GitHub App be installed in repositories where they don’t have the permissions to perform the installation themselves. Organization owners and repository admins will be notified to review and approve or deny these requests.