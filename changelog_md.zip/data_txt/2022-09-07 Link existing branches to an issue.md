September 7, 2022 

In the Development section of an issue, you can now link existing branches (or pull requests) to that issue. Learn more about [manually linking branches to an issue](https://docs.github.com/en/issues/tracking-your-work-with-issues/linking-a-pull-request-to-an-issue#manually-linking-a-pull-request-or-branch-to-an-issue-using-the-issue-sidebar).

![An animated image showing how a branch can be linked in an issue. The linked branch is shown in the Development section.](https://i0.wp.com/user-images.githubusercontent.com/3369400/188875100-ca7ba34c-581e-40c9-9304-adf0f39408f0.gif?ssl=1)