March 28, 2023 

The new code scanning tool status page allows users to view the status of CodeQL and other code scanning tools.  
 The page shows all the tools that are enabled on the repository and provides information about their setup types, configurations, and any relevant failures or warnings. If a tool is not working as expected, this is a good place to start troubleshooting the issue.  
  
You can visit the new tool status page by using the button at the top of [the repository's Code Scanning page](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/managing-code-scanning-alerts-for-your-repository#viewing-the-alerts-for-a-repository).

![code-scanning-tool-status-page-access](https://i0.wp.com/user-images.githubusercontent.com/54394529/227717362-fd61b7c9-fcb8-4325-a9ff-d13e5049365d.png?w=600&ssl=1) 

### Statuses for the tool[](#statuses-for-the-tool)

The page indicates three possible statuses for the tool: all configurations are working, some need attention, and some are not working.  
  
Code scanning needs to have received at least one analysis for the default branch to provide a tool status. Only the status of the default branch is reported.  
  
The page shows the latest state of all analysis configurations for the tool. For instance, if you created two separate workflows to scan two distinct parts of the repository independently, the page displays the most recent state of the tool by combining the statuses of both.

### The page structure[](#the-page-structure)

For each tool, the page provides actionable information about misconfigurations and errors, the number of scanned files per language, the setup types and configurations, the list of rules the tool checks against, and detailed CSV reports.

![code-scanning-tool-status-page-detailed](https://i0.wp.com/user-images.githubusercontent.com/54394529/228172209-1ac9438c-a98e-4094-ab74-f58e594fb9a5.png?w=600&ssl=1) 

#### Error messages[](#error-messages)

To help you with debugging, the tool status page shows error messages gathered from multiple code scanning system components during tool setup and analysis execution. These include errors from CodeQL, code scanning workflows, SARIF upload limits, and the internal code scanning system.  
  
Third party code scanning tools are not yet able to deliver tool related errors to the page. In the future, these tools will be able to submit error messages to code scanning via SARIF uploads.

#### Scanned files[](#scanned-files)

A Scanned Files section shows [the number of analysed files per language compared to the number of files in the repository.](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-the-tool-status-page#how-codeql-defines-scanned-files)  
  
The section helps you determine whether code scanning tools are operating correctly on your repository and only shows information about languages supported and analysed by the tool while ignoring languages that are present in the repository but are not supported or being analysed by the tool.  
  
This section is not yet displayed for third party code scanning tools. In the future, third party tools will be able to submit error messages to code scanning via SARIF uploads.

### Delivery dates[](#delivery-dates)

This has shipped to GitHub.com and will be available in GitHub Enterprise Server 3.9.

[Learn more about code scanning](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-code-scanning) and [the tool status page.](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-the-tool-status-page)  
  
[Learn more about GitHub Advanced Security.](https://github.com/features/security)