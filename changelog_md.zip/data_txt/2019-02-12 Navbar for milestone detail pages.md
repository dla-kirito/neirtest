February 12, 2019 

We added a navbar to each milestone detail page. The navbar links to your repository’s directory of milestones, making it easier to return to the directory without multiple clicks back.

[Learn more about milestones on GitHub](https://help.github.com/articles/about-milestones/)