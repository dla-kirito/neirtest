January 31, 2022 

The dependency graph now supports detecting GitHub Actions workflow YAML files. These will be displayed within the dependency graph section in the Insights tab. Repositories that publish actions will also be able to see the number of repositories that depend on that action from the Used By control on the repository homepage.

[Learn more about the dependency graph](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-the-dependency-graph)