October 7, 2020 

GitHub Docs are now open source! You already use GitHub Docs to make the most of GitHub and now we want your help to make the docs even better. [Join us](https://github.com/github/docs) to engage, contribute, and discuss all things docs. To learn more, check out our [blog post](https://github.blog/2020-10-07-github-docs-are-now-open-source/).