February 13, 2019 

Issue and pull request comment permalinks can now be copied on mobile devices, via the comment action menu.