July 27, 2020 

GitHub Enterprise accounts on github.com now enjoy higher hourly API rate limits for both GitHub Apps and OAuth Apps.

OAuth Apps were increased to 15,000 API calls per hour from the prior limit of 5,000 API calls per hour. GitHub Apps previously had a hard maximum of 12,500 API calls per hour, which was also raised to 15,000 per hour.

Higher limits apply to API requests tied to a GitHub Enterprise subscription, such as fetching issues or pull requests on a repository in an organization managed by a company. To receive the higher limit, the requests must come from a GitHub App or an OAuth App. GitHub Apps must be installed on an organization under a GitHub Enterprise subscription. OAuth Apps authorized to access repositories on an enterprise organization receive the higher limit, as long as the user is also part of that organization.

There are some exceptions to this increase. Personal access tokens, or PATs, are excluded from higher API limits. Unauthenticated requests do not receive an increase. Apps installed in a personal account context are excluded, because they are not directly affiliated with an enterprise organization. Note that abuse rate limits or secondary rate limits are still in effect to protect GitHub services, so the 15,000 requests can’t all be used in one minute of the hour.

For more detailed information, see the [rate limit](https://docs.github.com/rest/overview/resources-in-the-rest-api#rate-limiting) section for OAuth Apps and [rate limits](https://docs.github.com/developers/apps/rate-limits-for-github-apps) specific to GitHub Apps.