October 13, 2023 

GitHub Advanced Security customers that have [validity checks](https://github.blog/changelog/2023-04-28-secret-scanning-now-supports-validation-checks-for-supported-partner-patterns/) enabled for secret scanning will see the validation status for the following Discord tokens:

* discord\_api\_token\_v2
* discord\_bot\_token

View our [supported secrets documentation](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/secret-scanning-patterns#supported-secrets) to keep up to date as we expand validation support.

* [Learn more about secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning)
* [Become a secret scanning partner](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/secret-scanning-partner-program)
* Got feedback? Open a discussion in [our code security community](https://github.com/orgs/community/discussions/categories/code-security)