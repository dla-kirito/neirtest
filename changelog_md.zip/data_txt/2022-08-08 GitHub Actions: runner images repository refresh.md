August 8, 2022 

The repository that houses the images installed on GitHub-hosted runners has been renamed from actions/virtual-environments to actions/runner-images. These images are maintained by GitHub and used by GitHub Actions.

If you have forked this repository you will not be affected by this change.

All `git clone`, `git fetch`, or `git push` operations targeting the previous location will continue to function as if made on the new location. However, to reduce confusion, you should update any existing local clones to point to the new repository URL.

For more information and updates you can visit the newly improved [runner images repository](https://github.com/actions/virtual-environments).