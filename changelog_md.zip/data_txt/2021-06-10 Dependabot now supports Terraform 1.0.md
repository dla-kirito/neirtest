June 10, 2021 

Dependabot version updates now supports Terraform <= 1.0\. We have also added support for lockfiles, providers, and private registries.

Thank you to [@jmahowald](https://github.com/jmahowald) and [@userhas404d](https://github.com/userhas404d) whose contributions were critical in making this happen.

[Learn more about Dependabot version updates](https://docs.github.com/en/code-security/supply-chain-security/keeping-your-dependencies-updated-automatically/about-dependabot-version-updates).

[To see what's next for Dependabot, visit the public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=label%3A%22security+%26+compliance%22).