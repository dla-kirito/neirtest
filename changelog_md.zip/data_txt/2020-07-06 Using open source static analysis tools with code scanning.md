July 6, 2020 

Code scanning users can now scan their code for vulnerabilities using the [GitHub Open Source Static Analysis Runner (OSSAR) action](https://github.com/github/ossar-action).

At GitHub Satellite, we announced [code scanning](https://github.blog/changelog/2020-05-06-github-advanced-security-code-scanning-now-available-in-limited-public-beta/), part of GitHub Advanced Security. Along with showing results from CodeQL, GitHub's code analysis engine, code scanning can display findings from any static analysis tool. The OSSAR action wraps several popular open source tools to integrate them with code scanning.

If you are not yet part of the code scanning beta you can [request access here](https://github.com/features/security/advanced-security/signup).