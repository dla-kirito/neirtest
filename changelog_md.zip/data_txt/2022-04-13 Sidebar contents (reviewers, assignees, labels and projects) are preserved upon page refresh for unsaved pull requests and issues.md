April 13, 2022 

When a new issue or pull request is created and not yet submitted, the assignees, reviewers, labels and projects will all be preserved upon page refresh.

![assignees are preserved for unsaved PRs and issues](https://i0.wp.com/user-images.githubusercontent.com/4021812/162995502-4f2d91a5-a175-4e21-9f54-16bc30c8b00b.gif?ssl=1)