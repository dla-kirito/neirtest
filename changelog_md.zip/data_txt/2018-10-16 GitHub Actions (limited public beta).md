October 16, 2018 

GitHub Actions allows you to connect and share containers to run your software development workflow. Easily build, package, release, update, and deploy your project in any language—on GitHub or any external system—without having to run code yourself.

Learn more about [Actions](https://github.com/features/actions/)