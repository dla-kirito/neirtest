January 7, 2022 

GitHub's display of specialized file formats is now faster and more reliable. This includes rendering of Jupyter Notebooks, GeoJSON, PDF, PSD, SOLID, SVG, and TopoJSON files.

Previously, GitHub's display of specialized file formats relied on server-side rendering. The user experience was often slow and not always reliable. With this change, rendering is now performed primarily in the browser using open-source libraries like [nbconvert](https://github.com/jupyter/nbconvert/), [psd.js](https://github.com/meltingice/psd.js), and [three.js](https://github.com/mrdoob/three.js/). The result is less waiting and faster presentation of these file types.

For more information about GitHub's specialized file rendering, visit [Working with non-code files](https://docs.github.com/en/repositories/working-with-files/using-files/working-with-non-code-files).