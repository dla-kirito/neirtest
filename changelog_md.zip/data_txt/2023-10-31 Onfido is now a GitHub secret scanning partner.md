October 31, 2023 

GitHub secret scanning protects users by searching repositories for known types of secrets such as tokens and private keys. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [Onfido](https://onfido.com/) to scan for their tokens to help secure our mutual users in public repositories. Onfido tokens allow developers to interact with Onfido's API in order to integrate secure and reliable identity verification solutions into their applications and services, helping to enhance user onboarding processes and protect against fraud. GitHub will forward any exposed tokens found in public repositories to Onfido, who will then notify the customer about the leaked token. [Read more information about Onfido API tokens](https://documentation.onfido.com/#api-token-rotation).

GitHub Advanced Security customers can also scan for and block Onfido tokens in their private repositories.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)