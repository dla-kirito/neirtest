October 17, 2023 

The redesigned GitHub navigation is now live for everyone! After a successful [beta phase](https://github.blog/2023-06-15-exploring-github-with-the-redesigned-navigation-now-in-public-beta/), which allowed users to test and provide feedback, we’re confident in providing a more intuitive, responsive, and accessible navigation experience to all users by default.

![Image of the new global navigation](https://github.com/primer/design/assets/3369400/3a319003-b6a5-47d0-ad35-01015f61a74e)

### Key Features & Improvements:[](#key-features--improvements)

* **Efficient Breadcrumbs**: Navigate with a clear understanding of your location on GitHub.
* **Streamlined Menus**: New menus facilitate quick access to top repositories, teams, and common workflows. Just click the menu icon on the upper-left to access the global menu, or your user profile for the user menu.
* **Built for Search**: Optimized navigation for new code search experiences, inclusive of a quick-access button for the command palette.
* **Enhanced Accessibility**: Navigate seamlessly using any device and assistive technology.
* **Direct Links**: Immediate access to a users entire collection of ‘issues’ and ‘pull requests’ across GitHub are availabel at the upper level of the navigation.
* **Mobile & Responsive Enhancements**: Improved experiences on various screen sizes and devices.
* **Bug and Accessibility Fixes**: Resolved issues to refine user interaction and accessibility.

### Your Feedback Matters:[](#your-feedback-matters)

Your insights during the beta were invaluable. Thank you for helping us enhance GitHub. Explore and enjoy the refreshed navigation experience!