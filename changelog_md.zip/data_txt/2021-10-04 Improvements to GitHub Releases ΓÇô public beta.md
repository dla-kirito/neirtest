October 4, 2021 

GitHub is where developers come to learn and celebrate what’s new in open source, and where maintainers share, collaborate and celebrate their community’s work. Starting today, available in public beta, are two improvements to the release process on GitHub:

* Maintainers can now **automatically generate release notes**, giving them a summary of all the pull requests for a given release.
* The **Releases UI gets a refresh** giving more clarity into what’s included in a given release, as well as recognition for the contributors in the community. We have also fixed a number of papercuts including no longer showing tags on the releases list view and making videos playable in releases. This won’t be turned on by default in the beta, and will need to be enabled through the Feature Preview.

Learn more about [auto-generated release notes](https://docs.github.com/en/repositories/releasing-projects-on-github/automatically-generated-release-notes), and how to opt-in into the Releases UI refresh [here](https://docs.github.com/en/get-started/using-github/exploring-early-access-releases-with-feature-preview).