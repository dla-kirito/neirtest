August 24, 2022 

GitHub Advanced Security customers using secret scanning can now specify a custom link that will show in the error message when push protection detects and blocks a potential secret. Admins can use the custom link to provide their developers with a point of reference on best practices with secrets.

Learn more about [protecting pushes with secret scanning.](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)

![Custom link displayed in a push protection error message](https://i0.wp.com/user-images.githubusercontent.com/81782111/186042467-171209d3-ab13-4a02-88d2-498aa15020b3.png?w=600&ssl=1)