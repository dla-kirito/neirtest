September 30, 2022 

Organization administrators are now able to prevent outside collaborators from requesting the installation of both GitHub and OAuth apps to their organization. The "Allow integration requests from outside collaborators" setting can be found under Organization Settings > Member Privileges > Integration installation requests. This setting is enabled by default, and disabling it prevents outside collaborators from making app installation requests, unless the app has already been approved for use within the organization.

![integration-installation-requests-setting](https://i0.wp.com/user-images.githubusercontent.com/8298818/191220637-8d7cf844-138b-48af-bf47-c2533d675724.png?ssl=1)

On the app integration page, organizations that do not permit installation requests will be disabled.

![disabled OAuth integration installation page](https://i0.wp.com/user-images.githubusercontent.com/6826778/190715889-b0784299-a01e-4117-a06b-5b36d5fa0e3c.png?ssl=1)

Learn more about outside collaborators permissions in our documentation, ["Setting permissions for adding outside collaborators"](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-organization-settings/setting-permissions-for-adding-outside-collaborators).