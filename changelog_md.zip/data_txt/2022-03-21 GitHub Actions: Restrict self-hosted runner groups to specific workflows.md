March 21, 2022 

You can now restrict self-hosted runner groups to only be accessible from certain workflows.

In addition to restricting which repositories can access specific enterprise and organization runner groups, administrators can further control access by selecting specific workflow files and versions. Combining this feature with [reusable workflow](https://github.blog/2021-11-29-github-actions-reusable-workflows-is-generally-available/) can help you create more secure standard workflows in your organization.

![Workflow access dialog](https://i0.wp.com/user-images.githubusercontent.com/185122/159282590-dc0d0347-2bca-42e2-92a2-5c857ef63c20.png?ssl=1)

[Learn more about restricting access to self-hosted runners](https://docs.github.com/en/enterprise-cloud@latest/actions/hosting-your-own-runners/managing-access-to-self-hosted-runners-using-groups#changing-what-workflows-can-access-a-runner-group)

[For questions, visit the GitHub Actions community](https://github.community/c/code-to-cloud/github-actions/41)

[To see what's next for Actions, visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions)