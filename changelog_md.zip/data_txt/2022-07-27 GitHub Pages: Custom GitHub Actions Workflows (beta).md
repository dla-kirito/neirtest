July 27, 2022 

You can now deploy to a GitHub Pages site directly from a repository using GitHub Actions, without needing to set up a [publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site). Using Actions to orchestrate Pages publishing provides many more options for choosing your authoring framework ([Next.js](https://nextjs.org/), [Hugo](https://gohugo.io/), [Gatsby](https://www.gatsbyjs.com/), [Jekyll](https://jekyllrb.com/), [NuxtJS](https://nuxtjs.org/) or other technologies, and the associated versions thereof) as well as giving you finer control over the publishing process, such as leveraging deployment gates.

We have written several starter workflows for the most common frameworks but also have a “Static“ option if you want to deploy the contents of your repository with no build step.

![source](https://i0.wp.com/user-images.githubusercontent.com/14911070/178842638-51b834d3-6c54-423e-95fa-822f734fa98a.png?ssl=1)

Resources:

* [Learn about Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages)
* [Learn how to configure a custom workflow](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
* [Browse our starter workflows](https://github.com/actions/starter-workflows/tree/main/pages)