March 14, 2023 

Commenting directly on a file in a pull request (not just a specific line) is now available in public beta! 🎉

With this capability you can now comment on deleted, binary (including images), and renamed files in a pull request. You can also comment generally about a changed code file without having to attach the comment to a specific line.

## How it works[](#how-it-works)

To comment on any file in a pull request, click the **Comment on this file** button in the header of the file (next to the Viewed checkbox):  
![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/224705215-db5850c9-2f6a-416f-9f01-5800aeb24aac.png?w=919&ssl=1)

Comments on files appear in the Files Changed and Conversation tabs and can be replied to and resolved like regular review comments.  
![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/224706418-e60baddc-6edc-41bd-af58-38d9b0aa1b08.png?w=906&ssl=1)

## Tell us what you think[](#tell-us-what-you-think)

This feature is currently in public beta, with GitHub Mobile and API support coming soon.

[Join the discussion](https://gh.io/pr-file-comments-feedback) and let us know what you think!