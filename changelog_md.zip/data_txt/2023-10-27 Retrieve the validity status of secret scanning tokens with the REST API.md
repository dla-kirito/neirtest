October 27, 2023 

GitHub Advanced Security users can now use the REST API to retrieve the validity status of a secret scanning token and retrieve all tokens of a particular validity status. The API will return the status of the token as of the last validity check. Valid statuses are `active`, `inactive`, or `unknown`. [Validity checks](https://docs.github.com/en/enterprise-cloud@latest/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-security-and-analysis-settings-for-your-repository#allowing-validity-checks-for-partner-patterns-in-a-repository) must be enabled for the enterprise, organization, or repository.

* [Learn more about secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning)
* [View the REST API documentation](https://docs.github.com/en/enterprise-cloud@latest/rest/secret-scanning/secret-scanning?apiVersion=2022-11-28#about-secret-scanning)