August 6, 2018 

As part of our ongoing work to create a GraphQL API for Checks, you can now run mutations for creating or updating check suites and check runs.

[Learn more](https://developer.github.com/changes/2018-08-06-checks-gql-mutations-and-support-for-columns-in-annotations/)