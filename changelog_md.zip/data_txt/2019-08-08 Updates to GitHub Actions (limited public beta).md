August 8, 2019 

GitHub Actions now supports built-in CI/CD. Build and test your code in parallel with hosted runners for Linux, macOS, and Windows. And new live logs display your workflow in realtime. You can write Actions in JavaScript or create container Actions, so they work on every type of runner.

[Learn more and sign up for the beta](https://github.com/features/actions)