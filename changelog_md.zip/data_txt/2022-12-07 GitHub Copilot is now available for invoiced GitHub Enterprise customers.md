December 7, 2022 

Starting today, GitHub Copilot is officially available to invoiced GitHub Enterprise customers with our new Copilot for Business offering which joins Copilot for Individuals.  
This new add-on means enterprise users can now leverage GitHub Copilot’s powerful AI to write code and even entire functions with a simple editor extension.  
Copilot for Business will also provide additional capabilities including license management, centralized policy controls, and industry-leading privacy. Each license will cost $19 USD/month and will be billed directly to existing Enterprise accounts.

[Learn more in the GitHub’s blog.](https://github.blog/2022-12-07-github-copilot-is-generally-available-for-businesses)