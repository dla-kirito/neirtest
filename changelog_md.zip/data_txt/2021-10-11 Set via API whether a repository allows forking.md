October 11, 2021 

You can now set whether a repository allows forking when creating or updating it using either the REST or GraphQL API.

Previously, APIs for creating and updating repositories didn't consider the fields `allow_forking` (REST) or `forkingAllowed` (GraphQL). Now, this field can be set before invoking the API to configure whether a repository allows forking.

For reference, see documentation for the [REST API](https://docs.github.com/en/rest/reference/repos) and [GraphQL API](https://docs.github.com/en/graphql/reference/objects#repository).