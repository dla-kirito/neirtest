July 20, 2023 

Today's Changelog includes updates to project templates, a pinned item side panel, and pull request support in tasklists!

## 🎨 Project template updates[](#🎨-project-template-updates)

Since we announced the [public beta of project templates for organizations](https://github.blog/changelog/2023-05-25-github-issues-projects-may-25th-update/#%F0%9F%8E%A8-project-templates-for-organizations), we've made improvements to what is included in a template. Any configured workflows (other than the `Auto-add to project` workflow), project insights, and custom fields for draft items are now included when you use a project template or make a copy of a project.

<//user-images.githubusercontent.com/101840513/254975664-61a0616d-4255-4357-8e47-51129b469ecd.mp4>

Select a template when creating a new project to see a preview of what is included.

![template dialog](https://i0.wp.com/user-images.githubusercontent.com/94867353/255216207-ea3f9e0d-6372-4274-972a-23aa2bd0ddb6.png?ssl=1)

As we continue to build out more functionality for project templates we would love your [feedback](https://github.com/orgs/community/discussions/54576) and to hear more about your experiences and requests. Check out the [documentation](https://docs.github.com/en/issues/planning-and-tracking-with-projects/managing-your-project/managing-project-templates-in-your-organization) for more details.

## 📌 Pinned item side panel[](#📌-pinned-item-side-panel)

You can now pin the item side panel in your project by selecting the pin icon in the top right corner. This allows for triage mode where you can interact with the project view while an item remains open in the side panel. 

![image](https://i0.wp.com/user-images.githubusercontent.com/94867353/255216420-c50d8fe7-3bca-47d1-af8b-64f287f826eb.png?ssl=1)

## 🏗 Tasklists: pull request support + bug fixes and improvements[](#🏗-tasklists-pull-request-support--bug-fixes-and-improvements)

Tasklists now support pull requests as items and you can create tasklists inside of pull requests! If you have already been putting tasklists into pull requests only to have them fail on you, failure no more. ✨ 

<//user-images.githubusercontent.com/101840513/254978703-dd6a9a4f-29fe-4414-bed9-c20f741d1b61.mp4>

We've also made the following improvements to tasklists:

* You can now drag and drop issues between groups when grouped by `Tracked by`
* Text in issue hovercards for issues with tasklists now correctly renders issue descriptions
* We improved the rendering of tasklists in email notifications
* Tasklists no longer cause legacy task lists to be "off by 1"
* Clicking Esc after selecting a single-line metadata menu now maintains the focus
* Long URLs no longer extend past the borders of tasklists

## 🤸 Reorder fields in settings[](#🤸-reorder-fields-in-settings)

You can now reorder your custom fields in the project settings by dragging and dropping them in the list to update the order that they appear in the item side panel and on the issue page. Once you've rearranged your fields, open an issue in the side panel to see your changes!

## ✨ Bug fixes and improvements[](#sparkles-bug-fixes-and-improvements)

* Using Delete or pasting an empty value now clears the cell on the table layout
* You can now undo drag and drop actions and archiving of an item using Command/Ctrl \+ Z
* Fixed a bug where switching between views autoscrolled you to the right

See how to use GitHub for project planning with [GitHub Issues](http://github.com/features/issues), check out what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/issues).