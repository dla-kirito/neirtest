November 13, 2019 

Users who have been [selected for the beta](https://github.com/features/code-search-exact-match/signup) are now able to search [select repositories](https://help.github.com/en/github/searching-for-information-on-github/searching-code-for-exact-matches#supported-repositories) by pressing `f` on the repository page and entering their desired query. By default, it will return results which exactly match the given query (including word boundaries). Users are then able to further refine the results by requiring them to match the case of the query and/or match the whole word.

[Learn more about code search exact match on GitHub](https://help.github.com/en/github/searching-for-information-on-github/searching-code-for-exact-matches)