March 18, 2019 

File headers now stick to the top of the page when viewing a pull request diff.

[Learn more about pull requests](https://help.github.com/articles/about-pull-requests/)