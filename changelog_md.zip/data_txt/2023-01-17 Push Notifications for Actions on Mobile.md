January 17, 2023 

Introducing new push notifications for Actions on Mobile!

Get notified when your workflow runs have succeeded or failed on the go. You can also opt-in to receive notifications for failed workflows only. Head over to the in-app settings, where you can enable these new push types and prioritize what matters to you.

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/orgs/community/discussions/categories/mobile) to help us improve.