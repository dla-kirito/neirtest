July 26, 2022 

You can now link your GitHub and Twitter accounts with your npm account using an official OAuth integration with these services. Prior to this, GitHub and Twitter account linking used a plain text field which was not verified or validated.

The new experience creates a verified link, making it possible for developers to audit identities and trust that an account is who they claim they are. Verified linking also significantly improves our ability to recover your npm account in case you are not able to login into anymore.

Legacy data will no longer be shown on public npm profiles, and the data can no longer be set via the npm CLI. Legacy data will still be retained in your private profile until a verified link has been made and can be used for account recovery purposes.

Learn more about GitHub and Twitter account linking from our documentation page: “[managing user account profile settings from the web](https://docs.npmjs.com/managing-your-profile-settings#managing-user-account-profile-settings-from-the-web)“