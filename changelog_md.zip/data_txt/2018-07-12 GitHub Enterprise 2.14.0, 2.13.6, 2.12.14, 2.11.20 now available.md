July 12, 2018 

For the first time, your team can connect to the power of the open source community—and find lots of ways to get more work done—with our latest Enterprise 2.14 release. 

The 2.14.0, 2.13.6, 2.12.14, and 2.11.20 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

* [See Enterprise 2.14.0 release notes](https://enterprise.github.com/releases/2.14.0/notes)
* [See Enterprise 2.13.6 release notes](https://enterprise.github.com/releases/2.13.6/notes)
* [See Enterprise 2.12.14 release notes](https://enterprise.github.com/releases/2.12.14/notes)
* [See Enterprise 2.11.20 release notes](https://enterprise.github.com/releases/2.11.20/notes)