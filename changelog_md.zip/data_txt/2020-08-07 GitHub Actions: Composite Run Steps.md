August 7, 2020 

You can now create reusable actions using shell scripts and even mix multiple shell languages in the same action. You probably have a lot of shell script to automate many tasks, now you can easily turn them into an action and reuse them for different workflows. Sometimes it’s easier to just write a shell script than JavaScript or Docker. Now you don’t have to worry about wrapping your scripts in Docker containers.

Here’s an example of how you can use composite run steps actions:

![Composite Run Step Example](https://i0.wp.com/user-images.githubusercontent.com/8660827/89449714-7bdd0480-d727-11ea-9863-7486fe666fd5.png?ssl=1)

`workflow.yml`:

```yaml
jobs:
  build:
    runs-on: windows-latest
    steps:
    - uses: actions/checkout@v2
    - uses: octocat/say-hello@v1
      with: 
        name: OctoCat
```

`octocat/say-hello/action.yml`:

```yaml
inputs:
  name: 
    description: 'Your name'
    default: 'No name provided'
runs:
  using: "composite"
  steps: 
    - run: echo Hello ${{ inputs.name }}.
      shell: bash
    - run: echo "Nice to meet you!"
      shell: pwsh
```

Learn more about [composite run steps](https://docs.github.com/en/actions/creating-actions/about-actions#composite-run-steps-actions) and visit the [GitHub Actions community forum](https://github.community/c/github-actions) for questions.