May 13, 2021 

Video upload is now supported everywhere you can author Markdown in GitHub, including from the mobile app. Share demos, show reproduction steps, and more in issue, pull request, and discussion comments as well as on repository Markdown files such as READMEs.

[Learn more about uploading videos](https://docs.github.com/en/github/managing-your-work-on-github/file-attachments-on-issues-and-pull-requests) and check out the [blog post](https://github.blog/2021-05-13-video-uploads-available-github/) for more details.