September 23, 2021 

The [GitHub Advisory Database](https://github.com/advisories/) now includes curated Rust advisories. This brings the Advisory Database to eight supported ecosystems, including: Composer (PHP), Go, Maven, npm, NuGet, pip, and RubyGems.

Support for Rust in the dependency graph and Dependabot alerts will be available in the future. 

* [Learn more about the GitHub Advisory Database](https://docs.github.com/en/code-security/supply-chain-security/managing-vulnerabilities-in-your-projects-dependencies/browsing-security-vulnerabilities-in-the-github-advisory-database#about-the-github-advisory-database)
* [Learn more about GitHub security advisories](https://docs.github.com/en/code-security/security-advisories/about-github-security-advisories)