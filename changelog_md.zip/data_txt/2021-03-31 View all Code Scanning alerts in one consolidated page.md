March 31, 2021 

Code Scanning alerts from all enabled tools are now shown in one consolidated list, so that you can easily prioritise across all alerts. You can view alerts from a specific tool by using the Tool filter, and the Rule and Tag filters will dynamically update based on your Tool selection. 

![Screenshot](https://i0.wp.com/user-images.githubusercontent.com/19343236/112630570-abaf5880-8e2d-11eb-8138-291df6ca9cc0.png?ssl=1)