November 10, 2021 

You can now specify input types for manually triggered workflows allowing you to provide a better experience to users of your workflow. In addition to the default `string` type, we now support `choice`, `boolean`, and `environment`.

```
name: Mixed inputs

on:
  workflow_dispatch:
    inputs:
      name:
        type: choice
        description: Who to greet
        options: 
        - monalisa
        - cschleiden
      message:
        required: true
      use-emoji:
        type: boolean
        description: Include 🎉🤣 emojis
      environment:
        type: environment

jobs:
  greet:
    runs-on: ubuntu-latest

    steps:
    - name: Send greeting
      run: echo "${{ github.event.inputs.message }} ${{ fromJSON('["", "🥳"]')[github.event.inputs.use-emoji == 'true'] }} ${{ github.event.inputs.name }}"
```

Learn more about [workflow inputs](https://docs.github.com/en/actions/learn-github-actions/workflow-syntax-for-github-actions#onworkflow%5Fdispatchinputs).  
For questions, visit the [GitHub Actions community.](https://github.community/c/code-to-cloud/github-actions/41)  
To see what's next for Actions, visit our [public roadmap.](https://github.com/github/roadmap/projects/1)