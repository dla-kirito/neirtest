October 11, 2022 

![an image showing a shipped project- bring projects to github mobile in mobile interface with text- projects on the go](https://i0.wp.com/user-images.githubusercontent.com/7498102/194122511-b4023f60-6088-43f7-a55a-fe1b6bd3db72.png?w=1200&ssl=1)

Now more than ever flexibility is not only needed for how we work, but where we work. Stay connected and up to date on your work with GitHub Projects on GitHub Mobile, now in public beta. This marks the first milestone to bring GitHub Projects to your hands, so that you can track issues and projects from anywhere at any time. We would love for you to try it out on [iOS TestFlight](https://testflight.apple.com/join/NLskzwi5) or [Google Play (Beta)](https://play.google.com/apps/testing/com.github.android) and [give us your early feedback](https://github.com/community/community/discussions/35791).

Let’s take a look at what you can do. 

### Access GitHub Projects[](#access-github-projects)

With GitHub Projects on GitHub Mobile you can quickly access the projects you need through a repository, organization, or your own user profile.

![an image of quick navigation to access projects on mobile](https://github.blog/wp-content/uploads/2022/10/projectsmobile1-1.png?resize=315%2C490)

### Switch Views[](#switch-views)

You can view items as they’ve been configured and grouped and easily switch views on your projects to find what you need. Just tap on the title bar on top to pick a view from the pull-down menu. Project tables are rendered in a list layout for a simplified experience that still conveys all the necessary information you need for planning and tracking on the go. With collapsible buckets you can hide and reveal information as you wish for a better overview when you plan for a feature or track a sprint.

![an image showing switching views in projects on mobile](https://i0.wp.com/user-images.githubusercontent.com/102542428/194192690-b02784dc-05b9-4424-86f2-d7b6e9530f4c.png?ssl=1)

### Custom fields and quick actions[](#custom-fields-and-quick-actions)

All your custom fields, such as status, category, priority, and iteration, are rendered as glanceable metadata pills in the list. Long-press on a project item to quickly edit these fields, delete the item, or preview its content so you can keep everything up to date and organized. Want to leave a comment on a specific issue? Simply tap on the preview and write a message in the issue detail view.

![an image showing custom fields and quick actions to edit](https://i0.wp.com/user-images.githubusercontent.com/102542428/194192783-91835df9-97ea-4b05-8de0-9662f5795110.png?ssl=1)

### Tell us what you think[](#tell-us-what-you-think)

GitHub Projects on GitHub Mobile is available today from [Google Play (Beta)](https://play.google.com/apps/testing/com.github.android) or [iOS TestFlight](https://testflight.apple.com/join/NLskzwi5).

There’s a lot more to come, and we’re excited to keep you updated as we make GitHub Projects on Mobile even better. In the meantime, we want to hear from you. Leave us your thoughts in [GitHub Mobile Discussions](https://github.com/community/community/discussions/35791), by tapping Share Feedback in your app profile, or reviewing our app in the Play Store or iOS App store.