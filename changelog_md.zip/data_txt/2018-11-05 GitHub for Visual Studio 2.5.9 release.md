November 5, 2018 

The release of GitHub for Visual Studio 2.5.9 introduces comment drafts.

[View the full release notes](https://visualstudio.github.com/release-notes.html)