February 12, 2020 

GitHub CLI, now in beta, is a command line tool that enables you to work more seamlessly with your GitHub repositories right from your command line.

You can:

* Create pull requests fully within your terminal or preview them on the web before submitting
* Filter lists of a repository’s pull requests and issues to give you the information you need
* View a snapshot of a repository’s pull requests and issues that are most relevant to you
* Easily checkout pull request branches locally with one command
* Quickly view issues and pull requests in the browser

We plan to add much more functionality and we’re eager to hear your feedback. 

[Learn more](https://cli.github.com) and check out the [manual](https://cli.github.com/manual) for more things you can do with GitHub CLI.