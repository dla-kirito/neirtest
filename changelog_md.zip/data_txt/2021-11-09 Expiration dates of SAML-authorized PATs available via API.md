November 9, 2021 

GitHub recently introduced the ability to [set an expiration date](https://github.blog/changelog/2021-07-26-expiration-options-for-personal-access-tokens/) when creating or regenerating a personal access token (PAT). For a PAT that is authorized to access an organization protected by SAML single sign-on (SSO), the expiration date of that PAT is now available via [the GET /orgs/{org}/credential-authorizations API](https://docs.github.com/en/rest/reference/orgs#list-saml-sso-authorizations-for-an-organization).

Organization administrators can use the following `gh` command to see the expiration dates of all PATs that are authorized to access their org by authenticating with a PAT that has the `read:org` scope:

```shell
gh api --paginate /orgs/:org/credential-authorizations --jq='.[] | [.authorized_credential_expires_at]'
```

Learn more about [authorizing a personal access token for use with SAML single sign-on](https://docs.github.com/en/authentication/authenticating-with-saml-single-sign-on/authorizing-a-personal-access-token-for-use-with-saml-single-sign-on).