January 25, 2022 

Get insights on your Discussions community with the new dashboard called `Community` in the `Insights` tab. This dashboard gives you a quick way to monitor the following:

* Number of Discussions, Issues, and Pull Requests open over time
* Page views of Discussions over time, segmented by logged in vs anonymous users
* Daily Discussions contributors over time
* New Discussions contributors over time

![image](https://i0.wp.com/user-images.githubusercontent.com/8809849/150855182-d76e587d-802f-401e-9b60-6a013ca7d88e.png?ssl=1)

For more information, see [GitHub Discussions documentation](https://docs.github.com/en/discussions/managing-discussions-for-your-community/viewing-insights-for-your-discussions).

For questions or feedback, visit [GitHub Discussions feedback](https://github.com/github/feedback/discussions/categories/discussions-feedback).