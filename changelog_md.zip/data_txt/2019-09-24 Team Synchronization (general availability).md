September 24, 2019 

Team Synchronization is now generally available for GitHub Enterprise Cloud organizations. With team synchronization, Enterprise Cloud organizations can synchronize Azure Active Directory (Azure AD) group membership to GitHub teams. We will make this functionality available for [enterprise account SAML integrations](https://help.github.com/en/articles/enforcing-security-settings-in-your-enterprise-account#enabling-saml-single-sign-on-for-organizations-in-your-enterprise-account) and extend support to additional identity providers in the near future.

[Learn more about team synchronization across GitHub and Azure AD](https://help.github.com/articles/synchronizing-teams-between-your-identity-provider-and-github)