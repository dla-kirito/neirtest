May 2, 2023 

In [July 2022](https://github.blog/changelog/2022-07-26-a-new-npm-audit-signatures-command-to-verify-npm-package-integrity/) the public npm registry migrated away from the existing [PGP signatures](https://docs.npmjs.com/about-pgp-signatures-for-packages-in-the-public-registry) to a new [ECDSA signatures](https://docs.npmjs.com/about-registry-signatures) for signature verification.

As of **May 2nd 2023**, npm packages are no longer signed with PGP based registry signatures. The [public key hosted on Keybase](https://keybase.io/npmregistry) will expire.

Read more [about registry signatures](https://docs.npmjs.com/about-registry-signatures).