December 14, 2022 

The GitHub Enterprise Cloud [Dormant Users report](https://github.blog/changelog/2022-03-04-dormant-user-reports-for-github-enterprise-cloud-beta/) is now generally available. This report shows enterprise members who have not been active in the last 90 days.

To learn more, read about [managing dormant users](https://docs.github.com/en/enterprise-cloud@latest/admin/user-management/managing-users-in-your-enterprise/managing-dormant-users).