May 3, 2022 

GitHub Actions simplifies using secrets with reusable workflows with the `secrets: inherit` keyword.

Previously when passing secrets to a reusable workflow, you had to pass each secret as a separate argument. Now you can simply pass the `secrets: inherit` to the reusable workflow and the secrets will be inherited from the calling workflow.

[Learn more about reusable workflows in GitHub Actions](https://docs.github.com/en/actions/using-workflows/reusing-workflows#using-inputs-and-secrets-in-a-reusable-workflow)