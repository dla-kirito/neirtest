January 4, 2023 

As of last month, GitHub Advanced Security customers can enable push protection for push protection for any custom pattern defined at the repository or organization level. Now, customers can also protect patterns that they've [defined at the enterprise level](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/defining-custom-patterns-for-secret-scanning#defining-a-custom-pattern-for-an-enterprise-account).

* [Read our blog post to learn how you can push protect your custom patterns](https://github.blog/2022-12-15-github-advanced-security-customers-can-now-push-protect-their-custom-patterns)
* [Learn how to secure your repositories with secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning)