October 24, 2019 

GitHub Actions is changing how we evaluate some events in order to make sure we always run workflows from known refs in your repository. Going forward the following events will use the workflow from the repository’s default branch instead of the SHA of the event.

* `status`
* `check_run`
* `check_suite`
* `page_build`

We’ve removed support for the `commit_comment` event.

If your workflow uses the `actions/checkout` action you will now get the code from the default branch instead of the SHA in the event. Variables like `GITHUB_REF` and `GITHUB_SHA` will now have the default ref and SHA. This will cause your workflow to behave differently and potentially break if you rely on the specific version of the code at that SHA. The SHA for the event will still be included in the event payload if you need to access it.