March 11, 2020 

Starting today, we will assign CVE IDs to security vulnerabilities affecting GitHub Enterprise Server. We will continue to document security fixes in the release notes as they are today, and now we will also mention if a CVE has been assigned to the issue.

As a CVE Numbering Authority for our products, GitHub can issue CVEs for security vulnerabilities affecting GitHub Enterprise Server. By doing so, we will give administrators a consistent way to be aware of and identify the security risks of outdated versions.

[Learn more about CVE Identifiers](https://cve.mitre.org/about/) and [stay up to date with the latest GitHub Enterprise Server releases](https://enterprise.github.com/releases)