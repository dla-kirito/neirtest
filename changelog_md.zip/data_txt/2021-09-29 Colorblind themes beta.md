September 29, 2021 

Light and dark colorblind accessible themes are now available to all github.com users in a public beta. These themes swap colors such as red and green for orange and blue to make GitHub more inclusive for colorblind users. Navigate to the “Appearance” page in your [profile settings](https://github.com/settings/appearance) to update your theme preferences.

[Share feedback](https://github.community/c/github-help/dark-mode-beta/65)

![colorblind theme preview](https://i0.wp.com/user-images.githubusercontent.com/33528647/135293806-0bc1186a-1f25-4bf6-afcf-5bccbc387609.gif?ssl=1)