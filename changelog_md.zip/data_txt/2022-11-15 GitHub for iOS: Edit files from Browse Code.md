November 15, 2022 

![Banner announcing edit files in pull requests feature for GitHub for iOS](https://i0.wp.com/user-images.githubusercontent.com/59900904/201210777-24133364-ec61-421d-8626-d537e1966762.png?ssl=1)

Introducing file editing from repositories on [GitHub for iOS](https://apps.apple.com/us/app/github/id1477376905)! Commit changes to code within your repo, create new branches and put up a new pull request to land those quick changes on-the-go!

<https://user-images.githubusercontent.com/1051453/201196269-ece4b68d-a789-4168-abd8-1cd2cab65c8d.mp4>

File editing for pull requests and Browse Code on GitHub for Android is coming soon.

* [Learn more about GitHub for mobile](https://github.com/mobile)
* [Download GitHub for iOS today](https://apps.apple.com/app/github/id1477376905?ls=1)
* [Send us your feedback](https://github.com/orgs/community/discussions/categories/mobile) on this feature and other GitHub Mobile features by joining in the conversation on our community discussions.