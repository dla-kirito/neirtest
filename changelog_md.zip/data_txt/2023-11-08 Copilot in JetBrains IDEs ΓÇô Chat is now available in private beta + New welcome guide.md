November 8, 2023 

## Copilot Chat in JetBrains IDEs is now available in Private Beta[](#copilot-chat-in-jetbrains-ides-is-now-available-in-private-beta)

We are happy to announce that a private beta of GitHub Copilot Chat is now available for users of JetBrains IDEs, including IntelliJ, PyCharm, WebStorm, Android Studio, and more.  
GitHub Copilot Chat is a powerful AI-assistant capable of helping every developer build at the speed of their minds in the natural language of their choice.

This private beta is available to Copilot Business customers and Copilot Individual users.

To get access to the private beta, [sign up for this waitlist](https://github.com/github-copilot/chat%5Fjetbrains%5Fwaitlist%5Fsignup/join).

GitHub Enterprise Cloud (GHEC) administrators interested in participating in the private beta should reach out to your GitHub account manager or [contact our sales team](https://github.com/enterprise/contact) to make the feature available for your enterprise.

We’d love your feedback on this new release. Please [use this link to share your feedback](https://gh.io/copilot-chat-jb-feedback) or ideas on how to improve the product.

![Copilot Chat in IntelliJ](https://i0.wp.com/user-images.githubusercontent.com/2180038/281494110-d327cf41-ae03-4c84-9931-21d1de36131a.png?ssl=1)

## A new Copilot welcome guide is available for JetBrains IDEs[](#a-new-copilot-welcome-guide-is-available-for-jetbrains-ides)

We recently introduced a new welcome guide in our Copilot for JetBrains IDEs extension. Now you will be guided through the various features of GitHub Copilot and how to make the most of it!

![Copilot welcome guide in IntelliJ](https://i0.wp.com/user-images.githubusercontent.com/2180038/281494373-0f4202c3-0712-4c1c-9147-02fb893bf4fa.png?w=347&ssl=1)

The welcome guide will activate when you install the GitHub Copilot plugin.