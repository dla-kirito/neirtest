May 7, 2018 

GitHub now detects repositories that host mobile apps. For repositories that don’t have CI configured, you’ll see a recommendation for mobile CI providers directly on the pull request page.