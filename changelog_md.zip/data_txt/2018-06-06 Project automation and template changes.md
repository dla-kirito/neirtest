June 6, 2018 

One of the most requested features for GitHub Projects has been to provide separate triggers for issues and pull requests. Today, we have shipped a change to manage issue and pull request automation rules separately within your project boards.

We’ve also added a new template for `Bug Triage` to manage this process easily with your teams and contributors.  
Lastly, whenever a pull request is added to your project, it will automatically move into the `In progress` column to more accurately reflect ongoing work.

Take a look at the [documentation](https://help.github.com/articles/configuring-automation-for-project-boards/) for more information.