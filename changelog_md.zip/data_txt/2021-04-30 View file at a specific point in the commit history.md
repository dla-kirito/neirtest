April 30, 2021 

When viewing the commit history of a single file, users can now click to view that file at the selected point in history.

![view-history](https://i0.wp.com/user-images.githubusercontent.com/16675781/116747128-c01edc00-a9fd-11eb-9009-008305786885.gif?ssl=1)