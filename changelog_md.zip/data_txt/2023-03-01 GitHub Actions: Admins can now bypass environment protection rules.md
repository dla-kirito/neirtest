March 1, 2023 

Starting today, we are enabling administrators to bypass all [protection rules](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#environment-protection-rules) on a given environment (break glass) and force the pending jobs referencing the environment to proceed.

![break glass screenshot](https://i0.wp.com/user-images.githubusercontent.com/14911070/221709424-5701c1b6-6495-4bff-9c69-fcea83a26c4a.png?ssl=1)

For more information, visit [Using environments for deployment](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment).  