May 31, 2022 

![image](https://i0.wp.com/user-images.githubusercontent.com/35036892/171257875-e40c460d-32df-4315-8ef1-d29068dbdb25.png?ssl=1)

You can now [download the latest version of GitHub Enterprise Server](https://enterprise.github.com/releases/). This new release introduces GitHub Container registry and continues the strong emphasis on security. Your teams will be able to take advantage of the full complement of Dependabot capabilities and use GitHub Advanced Security with even greater language coverage and better protection for your secrets. You can read a detailed summary of new features for this release in the [GitHub blog](https://github.blog/2022-05-31-github-enterprise-server-3-5-is-now-generally-available/) or you can take a look at all the changes in the [release notes](https://docs.github.com/en/enterprise-server@3.5/admin/release-notes). You can check out a few of these highlights:

* Container Registry, containers supporting OCI, granular permissions and anonymous downloads [#118](https://github.com/github/roadmap/issues/118)
* Actions self-hosted runner group restrictions [#255](https://github.com/github/roadmap/issues/255)
* Actions re-usable workflows are now generally available! [#256](https://github.com/github/roadmap/issues/256)
* CodeQL detects more security issues and supports new language versions [#460](https://github.com/github/roadmap/issues/460) [Read more](https://github.blog/changelog/2022-02-25-code-scanning-detects-more-security-issues-supports-new-language-versions/)

New and of particular interest to administrators:

* IP exception list for post-maintenance validation [#448](https://github.com/github/roadmap/issues/448)
* 41 GitHub Enterprise Server Metrics for insight into platform usage [#497](https://github.com/github/roadmap/issues/497) [Read more](https://docs.github.com/en/enterprise-server@3.5/admin/monitoring-activity-in-your-enterprise/analyzing-how-your-team-works-with-server-statistics/about-server-statistics#server-statistics-data-collected)
* Audit Log now includes git events [#322](https://github.com/github/roadmap/issues/322)

To learn more about all the new features in GitHub Enterprise Server 3.5, read the [release notes](https://docs.github.com/en/enterprise-server@3.5/admin/release-notes) or [download it today](https://enterprise.github.com/releases/3.5.0/download). Are you using the latest GitHub Enterprise Server version? Use the [Upgrade Assistant](https://support.github.com/enterprise/server-upgrade) to find the upgrade path from your current version of GitHub Enterprise Server to your desired version.