August 12, 2021 

We are now indicating the number of files being uploaded in comments on GitHub.