April 6, 2021 

GitHub Sponsors now supports custom amounts and one-time payments.

![sponsors-otp-social-2](https://i0.wp.com/user-images.githubusercontent.com/1016190/113763019-0e2a1380-96ce-11eb-84ac-4a7a22cdce55.gif?ssl=1)

[Read more about how you can invest in open source](https://docs.github.com/en/github/supporting-the-open-source-community-with-github-sponsors/sponsoring-an-open-source-contributor).