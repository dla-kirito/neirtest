February 14, 2022 

You can now upload images to Wiki pages. Drag and drop, select or paste the file.