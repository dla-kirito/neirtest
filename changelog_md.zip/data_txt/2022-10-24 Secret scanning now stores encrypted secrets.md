October 24, 2022 

GitHub now stores detected secrets using symmetric encryption. Storing the encrypted secret allows secret scanning to provide the best possible user experience. 

Previously, we only stored the locations of the exposed secret and a hash of it. Each time we presented the secret in our user experience or API we therefore had to re-derive it from its location and hash. This meant that we could not always display a preview of a detected secret in the UI or API, preventing the user from ensuring proper revocation and remediation. Below are a few examples of when we could not previously show users the secret preview: 

1. If a contributor leaked a secret and then rewrote their Git history
2. If the secret was found in a file larger than a certain size, for practical performance reasons
3. If the secret was detected in a file with certain text encoding that was incompatible for previewing in GitHub UI

Now, GitHub stores detected secrets separately from source code using symmetric encryption. By storing this information we can more reliably retrieve and display detected secrets with a consistent user experience even if they've been removed from version history. As a result, as a user, you'll no longer be left wondering what a previously detected secret was and whether its previous exposure represents a long-term threat.

With our users’ security always top of mind, we’re confident that the change to our secrets storage will allow our users to take the proper remediation and revocation steps they need to secure their software.

* Learn more about [secret scanning for GitHub Advanced Security](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning#about-secret-scanning-for-advanced-security)