July 12, 2018 

Python users can now access the dependency graph and receive security alerts whenever their repositories depend on packages with known security vulnerabilities.

To configure the kind or frequency of notifications you receive, [visit your profile’s notification settings page](https://github.com/settings/notifications) and select your preferred option.

Read the [documentation](https://help.github.com/articles/about-security-alerts-for-vulnerable-dependencies/) to learn more.