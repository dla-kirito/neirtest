August 24, 2021 

GitHub Secret Scanning scans repositories for known types of secrets, to prevent fraudulent use of secrets that were committed accidentally. This protects users from fraud and data leaks.

[PlanetScale](https://planetscale.com/) is a MySQL compatible, serverless database platform built for developers with horizontal scaling, unlimited connections and an elegant GitHub-style workflow. We partnered with PlanetScale to help keep our customers secure by scanning for their developer tokens.

We continue to welcome new partners for public repo secret scanning. In addition, GitHub Advanced Security customers can also scan their private repositories for leaked secrets.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)