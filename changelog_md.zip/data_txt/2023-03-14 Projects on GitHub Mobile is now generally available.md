March 14, 2023 

![Projects on GitHub Mobile](https://i0.wp.com/user-images.githubusercontent.com/17592342/223131985-d0450fa8-3072-453d-ae9d-57c8dac6e6b6.png?ssl=1)

Projects on GitHub Mobile are now available for iOS and Android! Find the projects you're working on through a repository, organization, or from your user profile. You can also easily change views in a project to browse your issues and pull requests grouped and organized just as you like.

Custom fields and metadata, such as status, category, priority, and iteration, are displayed as an easy-to-read list within a project item. Simply tap on the list to edit the fields, or long-press on a project item for further actions like closing it or previewing its content.

Update your GitHub Mobile apps today from the Android Google Play or iOS App Store.

---

[Read more about GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/orgs/community/discussions/categories/mobile) to help us improve.