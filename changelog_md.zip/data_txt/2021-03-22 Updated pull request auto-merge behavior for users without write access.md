March 22, 2021 

To prevent unexpected changes from potentially slipping in after auto-merge is enabled on a pull request, auto-merge is now disabled automatically when new changes are pushed by a user without write access to the repository.

Note: users without write access can still update their pull requests to bring in changes from the base branch without having auto-merge disabled, but auto-merge will be disabled if the update results in merge conflicts that have to be resolved. This is to prevent merge-conflicts being deliberately used as a way to introduce code that hasn't been fully reviewed by the people with write access to the project.

Learn more about [automatically merging pull requests](https://docs.github.com/github/collaborating-with-issues-and-pull-requests/automatically-merging-a-pull-request) when all merge requirements have been met.