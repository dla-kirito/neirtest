March 28, 2023 

The dependency graph shows a summary of the manifest and lock files stored in a repository. The repository view has an updated user experience that includes:

* Search by package name from a paginated list of all dependencies
* Dependency licenses
* Dependabot alerts for dependencies, sorted by severity, and linking to the Dependabot alerts and the Dependabot updates pull request where applicable (only visible for users with priveleges to view the repository's Dependabot alerts)

![Screenshot of dependency graph UX, using the high contrast theme](https://i0.wp.com/user-images.githubusercontent.com/3474250/228082901-0e685d77-f722-4f69-98d4-8a95a7bda822.png?ssl=1)

Access a repository's dependency graph from Insights > Dependency graph.

* [Learn more about the dependency graph](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-the-dependency-graph)