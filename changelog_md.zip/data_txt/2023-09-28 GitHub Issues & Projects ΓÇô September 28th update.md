September 28, 2023 

Today's changelog brings you improvements to project templates (public beta), including new templates pages and the ability to create a template with a single click!

## 🏠 Find projects templates from your organization's Projects page[](#🏠-find-projects-templates-from-your-organizations-projects-page)

You'll now find all project templates in the "Templates" section of your organization's Projects page. This allows you to quickly find, filter, and open all available templates right alongside your projects.

You can also create templates using `New template`, in addition to converting an existing project into a template by toggling `Make template` on the project's settings page.

Create, set up, and reuse templates to make getting started with new projects a breeze!

![organization templates page](https://i0.wp.com/user-images.githubusercontent.com/101840513/271125639-e2553400-153f-4836-9a48-0c45efa89363.jpg?ssl=1)

## 🔗 Link project templates to teams and repositories[](#🔗-link-project-templates-to-teams-and-repositories)

In order to find templates that are relevant to you and your teams, you can now link project templates and create them directly from your team and repository "Projects" pages. This allows you to link relevant templates for quick and easy access the same way that you can link or create projects from these locations.

<//user-images.githubusercontent.com/101840513/271126132-ff8ee146-0396-4bc1-8fd6-27b9dfb205eb.mp4>

## ✍️ Tell us what you think![](#✍️-tell-us-what-you-think)

We’ve got more improvements planned for project templates but we want to hear from you, so be sure to drop a note in the [discussion](https://github.com/orgs/community/discussions/54576) and let us know how we can improve! Check out the [documentation](https://docs.github.com/en/issues/planning-and-tracking-with-projects/managing-your-project/managing-project-templates-in-your-organization) for more details.

## ✨ Bug fixes and improvements[](#sparkles-bug-fixes-and-improvements)

* Improved the project collaborators suggestions to differentiate between teams and users
* Fixed a bug where you could not download an empty project view with `Export view data`
* Fixed a border contrast issue in the Workflows page

See how to use GitHub for project planning with [GitHub Issues](http://github.com/features/issues), check out what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/issues).

Questions or suggestions? Join the conversation in the [community discussion](https://github.com/orgs/community/discussions/63381).