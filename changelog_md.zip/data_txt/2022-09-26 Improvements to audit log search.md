September 26, 2022 

We've made some improvements to audit log search to make it easier to discover events. Since audit log events are found through key:value pairs, we now show you a list of possible options to choose from.  
![key-value pair dropdown menu available in audit log search](https://i0.wp.com/user-images.githubusercontent.com/4021812/191095010-58a68e64-bf75-442d-a1d3-21c627ef5662.png?w=389&ssl=1)

We've also linked to our documentation in the filter dropdown so that you can more easily discover all the possible options for audit log queries. 

![view advanced search syntax added to audit log filter](https://github.blog/wp-content/uploads/2022/09/image.png?fit=1024%2C1024)

To learn more about how to query the audit log, check out our documentation, ["About search for the enterprise audit log"](https://docs.github.com/en/enterprise-server@3.3/admin/monitoring-activity-in-your-enterprise/reviewing-audit-logs-for-your-enterprise/searching-the-audit-log-for-your-enterprise#about-search-for-the-enterprise-audit-log).