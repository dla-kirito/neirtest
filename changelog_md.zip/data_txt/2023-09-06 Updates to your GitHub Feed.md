September 6, 2023 

_September 12, 2023 update:_

_When we launched the latest version of your feed on September 6, 2023, we made changes to the underlying technology of the feed in order to improve overall platform performance. As a result, we removed the functionality for “push events for repositories a user is subscribed to”. We don’t take these changes lightly, but as our community continues to grow tremendously, we have to prioritize our availability, user experience and performance._ 

_Thanks to feedback from the community, we have fixed the following bugs from the initial September 6th release:_

* _We were showing releases for organizations that you follow, instead of only showing them for repositories that you watch or star. This is now fixed._
* _We have also addressed a problem where ‘Followed You’ cards were sometimes appearing out of chronological order._
* _We do not plan to re-include “push events for repositories a user is subscribed to” for the reasons listed above, but we will continue to address feedback as it aligns with our platform goals._

---

Your homepage feed will now have a singular, consolidated feed that aggregates content from your starred repositories and followed users. As part of this update:

* The content from the “Following” feed has been combined with the “For you” Feed, so you’ll have one singular location to discover content.
* For those looking to customize, we’ve enhanced the filtering controls, enabling you to tailor your feed to display only the event types that matter most to you. Including:  
   * Announcements (special discussion posts from repositories)  
   * Releases (new releases from repositories)  
   * Sponsors (relevant projects or people that are being sponsored)  
   * Stars (repositories being starred by people)  
   * Repositories (repositories that are created or forked by people)  
   * Repository activity (issues and pull requests from repositories)  
   * Follows (who people are following)  
   * Recommendations (repositories and people you may like)
* We’ve given the entire interface a fresh and visually appealing makeover ✨

![image](https://i0.wp.com/user-images.githubusercontent.com/2180038/265774947-93324fef-d6e9-41ae-ba63-a6fc8870f483.png?ssl=1)

## What this means for you[](#what-this-means-for-you)

If you’re an existing “Following” feed user, your feed content should be familiar to what you’ve been seeing on your “Following” tab. And now, with our new filtering control, you can fine-tune your content preferences to further curate your feed.

If you’re an existing “For you” feed user, we’ve also defaulted your filtering to showcase what you currently see on your “For you” tab. The new filtering control allows you to further customize your feed by including or excluding specific content types.

New users, we’ve got you covered with default settings that ensure you’re seeing the most relevant content. Dive in, personalize, and make the feed your own!