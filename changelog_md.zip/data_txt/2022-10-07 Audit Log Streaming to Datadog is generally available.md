October 7, 2022 

GitHub Enterprise Cloud customers can now stream their audit log to a Datadog endpoint. Enterprise owners need to be able to use the right tools for their job, whether that be short-term investigation or longer-term threat analysis and prevention. With audit log streaming to Datadog, customers can be assured that:

* no audit log event will be lost,
* they may satisfy longer-term data retention goals, and
* they can analyze GitHub's audit log data using Datadog products.

For GitHub Enterprise Server customers, this feature is planned to come to GHES 3.8.

For additional information, read our documentation about [setting up streaming to Datadog](https://docs.github.com/en/enterprise-cloud@latest//admin/monitoring-activity-in-your-enterprise/reviewing-audit-logs-for-your-enterprise/streaming-the-audit-log-for-your-enterprise#setting-up-streaming-to-datadog).  
“