August 19, 2021 

For Wikis, we now automatically generate a table of contents based on the headings.