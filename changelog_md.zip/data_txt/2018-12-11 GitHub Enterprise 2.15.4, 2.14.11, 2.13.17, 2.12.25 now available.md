December 11, 2018 

The 2.15.4, 2.14.11, 2.13.17, and 2.12.25 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

View the full release notes:

* [See Enterprise 2.15.4 release notes](https://enterprise.github.com/releases/2.15.4/notes)
* [See Enterprise 2.14.11 release notes](https://enterprise.github.com/releases/2.14.11/notes)
* [See Enterprise 2.13.17 release notes](https://enterprise.github.com/releases/2.13.17/notes)
* [See Enterprise 2.12.25 release notes](https://enterprise.github.com/releases/2.12.25/notes)