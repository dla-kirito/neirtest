August 22, 2023 

In addition to scanning push and pull requests, code scanning default setup now also analyzes repositories on a weekly schedule. This ensures that a scan with the most recent version of CodeQL is run regularly on your code, better protecting both active and inactive repositories. This allows users to always benefit from CodeQL engine and query improvements which are continuously released, and which could uncover new potential vulnerabilities.

When setting up code scanning, the fixed time for the weekly scan is randomly chosen. The scan will take place at the same time every week, and the schedule is displayed after the setup is completed, so you can easily see when the next scheduled analysis will occur. The scheduled analysis will be automatically disabled if a repository has seen no activity for 6 months. Opening a PR or pushing to the repo will re-enable the scheduled analysis.

![Screenshot that shows the weekly scheduled scan](https://i0.wp.com/user-images.githubusercontent.com/19343236/261064513-a65f6fb2-1899-480a-958a-6c4b9024ce94.png)

This has shipped to GitHub.com and will be released with GitHub Enterprise Server 3.11.