February 6, 2023 

Student community leaders can now apply to [GitHub Campus Experts](https://education.github.com/experts) on [GitHub Global Campus](https://education.github.com/) .

As a result of these changes, we updated the URLs. The form hosted on `https://apply.githubcampus.expert/` will no longer be available in favor of `https://education.github.com/campus_experts`.

To learn more, read our documentation on [how to apply to the GitHub Campus Experts program](https://docs.github.com/en/education/explore-the-benefits-of-teaching-and-learning-with-github-education/use-github-at-your-educational-institution/about-campus-experts).