September 23, 2021 

npm access tokens will now follow the established format of [GitHub authentication tokens](https://github.blog/2021-04-05-behind-githubs-new-authentication-token-formats/) as part of our work to create a more secure supply chain.

Previously, the npm access tokens were created as a UUID pattern of 36 characters, which has limitations such as inaccurate detection of compromised npm tokens in packages and GitHub repositories.

## Identifiable prefix and higher entropy pattern[](#identifiable-prefix-and-higher-entropy-pattern)

With the new pattern, access tokens now start with an identifiable prefix: `npm` so it is easier to be indexed by features like [secret scanning](https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning) and npm’s internal secret scanners. Moreover, the delimiter following after is no longer a `-` but an underscore `_` meaning a full token can be selected when double clicked.

The last six characters of the tokens consist of CRC32 checksum, which is encoded in Base62 to further eliminate false positives when scanning for leaked tokens.

We strongly encourage you to make the move towards the new format by resetting your existing access tokens to help mitigate any risk to compromised tokens as well as make our secret scanning detection more precise. You can reset your personal access tokens by clicking on `Access tokens` under your `Profile`, deleting all of your old tokens and creating new ones. 