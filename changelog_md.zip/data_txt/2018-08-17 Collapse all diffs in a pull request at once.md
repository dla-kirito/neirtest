August 17, 2018 

When a pull request contains a lot of changed files, code reviewers can find it hard to isolate the changes that are relevant to them. Now you can collapse (or expand) the contents of _all_ diffs in a pull request by holding down the `alt` key and clicking on the inverted caret icon in any file header.

You can then go one step further by using the “Jump to file or symbol” dropdown to jump to the file that you’re interested in and automatically expand it. Happy code reviewing!

[Learn more about code review](https://github.com/features/code-review/).