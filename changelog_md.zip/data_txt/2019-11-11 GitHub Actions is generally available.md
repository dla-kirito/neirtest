November 11, 2019 

Starting today, GitHub Actions is generally available. GitHub Actions are free for all public repositories, and every plan gets included storage and runner minutes for private repositories.

[Learn more about GitHub Actions pricing](https://help.github.com/en/github/setting-up-and-managing-billing-and-payments-on-github/about-billing-for-github-actions)