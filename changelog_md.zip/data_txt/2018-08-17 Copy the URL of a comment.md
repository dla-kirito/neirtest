August 17, 2018 

Previously, in order to grab a permalink to a comment within an issue or pull request, you’d need to copy the URL from a comment’s timestamp. Now you can click **Copy URL** within the comment’s options menu to quickly copy the URL to your clipboard.