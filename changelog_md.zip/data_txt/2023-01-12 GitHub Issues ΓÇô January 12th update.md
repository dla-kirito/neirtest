January 12, 2023 

Today’s Changelog brings you the addition of project events to Issue and Pull Request timelines, Issue forms for private repositories, and more!

## 👀 Project events in item timelines (Public Beta)[](#👀-project-events-in-item-timelines-public-beta)

Actions related to adding and deleting Issues or Pull Requests from a project or changing the status of an Issue or Pull Request inside a project are now included as part of the items timeline alongside existing events.  
![image](https://i0.wp.com/user-images.githubusercontent.com/7584089/211565457-62a713e9-591b-404e-8099-b94e6ca919da.png?w=966&ssl=1)

## 📝 Issue forms for private repositories (Public Beta)[](#📝-issue-forms-for-private-repositories-public-beta)

[Previously](https://github.blog/changelog/2021-06-23-issues-forms-beta-for-public-repositories/) we released Issue forms for public repositories, helping maintainers provide more context on the information useful to them.

Today we are releasing Issue forms for private repositories. Issue forms for private repositories use the same [YAML syntax](https://docs.github.com/en/communities/using-templates-to-encourage-useful-issues-and-pull-requests/syntax-for-issue-forms) as public repositories but do not support required fields, helping to keep your issue creation process streamlined.  
![image](https://i0.wp.com/user-images.githubusercontent.com/7584089/211566132-d2fcd4b9-1577-4073-9db6-12b48a637762.png?w=957&ssl=1)

## ✨ Bug fixes and improvements[](#✨-bug-fixes-and-improvements)

* Added a note that closing a project will disable all associated workflows
* Added a tooltip text over the unsaved view indicator
* Accessibility improvements in the project settings pages

See how to use GitHub for project planning with [GitHub Issues](http://github.com/features/issues), check out what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/issues).