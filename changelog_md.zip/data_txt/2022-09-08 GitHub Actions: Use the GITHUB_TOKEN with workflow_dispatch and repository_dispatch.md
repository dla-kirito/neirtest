September 8, 2022 

Customers will now be able to use the `GITHUB_TOKEN` with `workflow_dispatch` and `repository_dispatch` events to trigger workflows. Prior to this change, events triggered by `GITHUB_TOKEN` would not create a new workflow run. This was done to prevent the accidental trigger of endless workflows. This update makes an exception for `workflow_dispatch` and `repository_dispatch` events since they are explicit calls made by the customer and not likely to end up in a loop.

```yaml
name: Create Workflow Dispatch

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Trigger Workflow
        uses: actions/github-script@v6
        with:
          script: |
            github.rest.actions.createWorkflowDispatch({
              owner: context.repo.owner,
              repo: context.repo.repo,
              workflow_id: 'test.yml',
              ref: 'main',
            })
```

For more details see  
[Triggering a workflow from a workflow](https://docs.github.com/en/actions/using-workflows/triggering-a-workflow#triggering-a-workflow-from-a-workflow).

For questions, [visit the GitHub Actions community](https://github.com/orgs/community/discussions/categories/actions-and-packages).

To see what’s next for Actions, [visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions).