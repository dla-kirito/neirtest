July 17, 2020 

Previously, when branches were deleted on GitHub, any links that contained the old branch name broke across StackOverflow, email, Slack and other integrations.

~~Links to deleted branches now redirect to the default branch. So, for example, the link `https://github.com/dependabot/dependabot-core/blob/master/README.md` will now redirect to an equivalent link on the default branch: `https://github.com/dependabot/dependabot-core/blob/main/README.md`. This change only affects view links; other types of links (like edit links and blame links) don’t redirect.~~

This change is the first of many changes GitHub is making to support projects and maintainers that want to rename their default branch. To learn more about the changes we’re making, see [github/renaming](https://github.com/github/renaming/).

**Update (February 7, 2023):**

This behavior conflicted with other GitHub URL patterns, so we removed it. GitHub does redirect renamed branches, but not deleted branches. For more information, see [Renaming a branch](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-branches-in-your-repository/renaming-a-branch).