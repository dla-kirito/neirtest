May 25, 2023 

Today's Changelog brings you project templates, support for tasklists on mobile, and bulk edit support on boards!

### 🎨 Project templates for organizations[](#🎨-project-templates-for-organizations)

Project templates for organizations are now in **public beta**! Building upon the recently released ability to [copy an existing project](https://docs.github.com/en/issues/planning-and-tracking-with-projects/creating-projects/copying-an-existing-project) you can now create, save and reuse projects with templates, helping you save time and create a consistent approach to managing your projects. 

<https://github.blog/wp-content/uploads/2023/05/240716365-d61ced69-7dfb-4c99-80f3-c177a1f21709.mp4>

To get started with project templates: 

* Project `admins` will see a new option `Make template` on the settings page that will set the project as a template.
* If you want to keep your current project, but think it will make a great template, `admins` and `write` access users will see the option to `Copy as template`, which will create a new version without your issues and pull requests as a template.
* To see all templates, simply search for `is:template` on the projects page.
* When creating a new project, you will see available templates in the sidebar.

![image shows a number of project template options when starting a new project](https://i0.wp.com/user-images.githubusercontent.com/2180038/239328106-ecfdafdc-11b5-436d-a163-07b7d9326f3f.png?ssl=1)

As we continue to build out more functionality for project templates we would love your [feedback](https://github.com/orgs/community/discussions/54576) and to hear more about your experiences and requests. Check out the [docs](https://docs.github.com/en/issues/planning-and-tracking-with-projects/managing-your-project/managing-project-templates-in-your-organization) for more details.

### 📱 Tasklists on Mobile[](#📱-tasklists-on-mobile)

![mobile-tasklist](https://i0.wp.com/user-images.githubusercontent.com/2180038/239336700-85197b07-6c74-48a6-9073-f36e640cd8db.png?ssl=1)

Tasklists now render on mobile! View progress on your initiatives, epics, umbrella issues (or whatever your team calls them) on the go! 

Tasklists are currently in **private beta**, and you can sign your organization up on the [waitlist](https://github.com/features/issues/signup).

### 💪 ⌨️ Bulk updates and keyboard navigation on boards[](#💪-⌨️-bulk-updates-and-keyboard-navigation-on-boards)

<https://github-production-user-asset-6210df.s3.amazonaws.com/101840513/240714001-d98c9a85-992f-4cea-9184-b585bf6e38de.mp4>

Kanban enthusiasts rejoice! We've added the ability for users to bulk update cards on their boards with either mouse drag and drop or keyboard navigation. To select more than one card, simply hold `Ctrl/Command` and click on the cards you wish to move. For keyboard warriors, tab to the card you wish to drag, hold `shift` and navigate to other cards you wish to update, and press `enter` to select and move the selected cards.

For more detailed information, find a full list of keyboard shortcuts in the [docs](https://docs.github.com/en/get-started/using-github/keyboard-shortcuts#projects).

### 👁️ Persistent collapsed groups on tables and roadmaps[](#👁️-persistent-collapsed-groups-on-tables-and-roadmaps)

When you collapse a group in the table or roadmap layout, the group will remain collapsed when you return to the view. This is only the case for your view and will not be applied for anyone else. 

### 🎨 Updates to single-select color options[](#🎨-updates-to-single-select-color-options)

If other values in this field already have a color, a color will be auto-assigned to any new values added to the field.

### 📋 Copying values in tables[](#📋-copying-values-in-tables)

You can now select and copy a range of cells. Use `Ctrl/Command` \+ `a` keyboard command once to select a row and twice to select all cells, and `Ctrl/Command` \+ `c` to copy values. You can then paste values in other text editors using `Ctrl/Command` \+ `v`. 

### ✨ Bug fixes & improvements[](#✨-bug-fixes--improvements)

Tasklists bug fixes and improvements:

* Updated the iconography for "saving" tasklists
* Set a limit of 512 characters for draft tasks
* Fixed a bug where users were seeing a red error banner with the message "An error occured while loading your tasklist."

Other changes include:

* Updated the Auto-archive workflow confirmation dialog to show number of items archived
* Fixed inconsistent text highlighting in code search filter input
* Added the ability to exit the `label` dialog without using a mouse

See how to use GitHub for project planning with [GitHub Issues](https://github.com/features/issues), check out what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/en/issues).