August 1, 2022 

It's now easier to debug CodeQL analysis problems in code scanning: click **Re-run jobs** from the GitHub Actions workflow run page, check the **Enable debug logging** box, and hit the **Re-run jobs** button.

![Re-run all jobs](https://i0.wp.com/user-images.githubusercontent.com/14129055/179047426-c35ed6f8-5842-4b33-a736-45ec4b895c1f.png?ssl=1)

The data will be uploaded as an Actions artifact named `debug-artifacts`, attached to the workflow run. Such artifacts contain CodeQL logs, CodeQL databases, and the SARIF files that were produced.

![Actions artifacts](https://i0.wp.com/user-images.githubusercontent.com/14129055/179047435-808313b5-8365-4e5d-a7aa-b90e69761b4f.png?ssl=1)

These artifacts will help you when you're debugging problems with [CodeQL code scanning](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-code-scanning-with-codeql). When contacting GitHub support, you might be asked for this data.

As part of the analysis, CodeQL _extracts_ your source code into a relational database format. The debug artifacts include more detailed information about CodeQL extraction errors and warnings that occurred during database creation. If you want to permanently enable debug logging for the CodeQL analysis, or would like more information about troubleshooting CodeQL, please follow [these instructions](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/troubleshooting-the-codeql-workflow).

This feature is now available to all users on GitHub.com and will also be available in GitHub Enterprise Server 3.7.