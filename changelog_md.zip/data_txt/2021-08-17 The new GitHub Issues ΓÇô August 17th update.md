August 17, 2021 

Over the past month, we’ve continued to improve the GitHub Issues beta as we work hand-in-hand with our beta users to make GitHub the place that developers can plan, manage and track their work. Here are some of the recent ships:

### 🗂 Improved filtering[](#🗂-improved-filtering)

Three new filtering options are now available:

* Find items that don’t match a query with `-`. For example `-status:done`
* Find items that have null values with `no`. For example `no:status`
* Find items based on state with `is`. For example `is:open` or `is:issue`

All of these new filtering options have type-ahead support in the filter bar and can be found in the command palette with `cmd+k` (on MacOS) or `ctrl+k` (on Windows/Linux).

![all filters demo](https://i0.wp.com/user-images.githubusercontent.com/7584089/129560162-420bbf26-d867-4198-ae62-0bd23dbfe9bf.gif?ssl=1)

### 📝 Draft to Issue conversion[](#📝-draft-to-issue-conversion)

You can now convert any draft issue in a project to an issue. Simply use the item menu or edit the assignee, labels, milestone or repository fields.

![Convert to issue demo](https://i0.wp.com/user-images.githubusercontent.com/7584089/129560184-60fa9333-c93e-44fe-ade6-9660dc44e75d.gif?ssl=1)

### ✨ Bug fixes & improvements[](#✨-bug-fixes--improvements)

* Filtering is now possible over hidden fields.
* The scroll position is reset correctly when changing views.
* Hitting ‘enter’ on a cell keeps you in the same field and moves you to the row below.
* Fixed an issue with filtering against fields which contained emojis.
* Updates to dark mode colors.
* Adding a new item via ‘tab’ now focuses you on the second column in the table layout.
* The command palette now allows filtering across all fields.
* Fixed a bug where deleting a field being used for a sort or group by broke the view.
* Improved drag and drop to empty columns in the board layout.
* Draft issues are now included under the `is:issue` filter.

Learn about the Issues beta on the [GitHub Issues](http://github.com/features/issues) page or in the [FAQ](http://github.com/features/issues#faq).