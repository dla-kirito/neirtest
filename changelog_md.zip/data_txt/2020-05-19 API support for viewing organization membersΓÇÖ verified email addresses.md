May 19, 2020 

Administrators of organizations on the Enterprise Cloud plan that have agreed to the [Corporate Terms of Service](https://help.github.com/en/articles/github-corporate-terms-of-service) can now see members’ verified email addresses in their organization’s verified domain(s) via the GraphQL API.

For more information, see the `organizationVerifiedDomainEmails` field in the [GraphQL API documentation](https://developer.github.com/v4/object/user/#fields) and [verifying your organization's domain documentation](https://help.github.com/en/github/setting-up-and-managing-organizations-and-teams/verifying-your-organizations-domain).