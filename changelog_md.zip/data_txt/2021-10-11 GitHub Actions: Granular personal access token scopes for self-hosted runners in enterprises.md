October 11, 2021 

Managing self-hosted runners within an enterprise no longer requires personal access tokens with the `admin:enterprise` scope. Tighten down the permissions on your token by using the `manage_runners:enterprise` scope instead. A token with this scope can be used to authenticate to use [many endpoints](https://docs.github.com/en/rest/reference/enterprise-admin#list-self-hosted-runner-groups-for-an-enterprise) to manage your enterprise's self-hosted runners.

Learn more about [self-hosted runners](https://docs.github.com/en/actions/hosting-your-own-runners/about-self-hosted-runners) for your Actions workflows.