October 11, 2023 

Requiring Actions workflows with Repository Rules is now generally available on GitHub.com!  
![Screenshot showing the add required workflow modal overtop the enabled rule inside a ruleset](https://i0.wp.com/user-images.githubusercontent.com/253558/274029255-fac8ca42-790c-43a3-a5f5-a8fc7dde8df5.png)

Through [Repository Rules](https://docs.github.com/en/enterprise-cloud@latest/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets), GitHub Enterprise Cloud customers can now set up organization-wide rules to enforce their CI/CD workflows, ensuring workflows pass before pull requests can be merged into target repositories. Additional settings allow for fine-tuning how the workflow file can be selected — either from a specific branch, tag, or SHA — and provide maximum control over the version expected to run.

Applying a newly created workflow policy across an organization can feel risky. To ensure confidence when enabling a workflow rule across targeted repositories, workflow rules can be put into “evaluate” mode which will validate the rule is working correctly. And don’t worry, organization administrators can even allow select roles to “break the glass” and bypass a rule when necessary.

[Learn more about this release](https://github.blog/2023-10-11-enforcing-code-reliability-by-requiring-workflows-with-github-repository-rules) and how requiring workflows with Repository Rules can protect your repositories.

To share feedback or ask questions, join our [Community Discussion](https://github.com/orgs/community/discussions/69595)!