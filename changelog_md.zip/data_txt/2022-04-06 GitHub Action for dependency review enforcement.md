April 6, 2022 

A new GitHub Action enforces dependency reviews on PRs by scanning for dependencies and warning you about any associated security vulnerabilities. This is supported by a new API endpoint that diffs the dependencies between any two revisions.

The dependency review action is available for use in public repositories. The action is also available in private repositories owned by organizations that use GitHub Enterprise Cloud and have a license for GitHub Advanced Security.

Learn more about [dependency review enforcement](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-dependency-review#dependency-review-enforcement).