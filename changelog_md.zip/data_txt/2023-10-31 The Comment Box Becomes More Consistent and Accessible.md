October 31, 2023 

We are excited to announce a significant update to the comment box used in GitHub issues, discussions, and pull requests, aiming to refine and enhance how you interact and collaborate. This release is a testament to our ongoing efforts to provide an exceptional user experience, making GitHub more intuitive, consistent, and accessible across the platform.

![A screenshot of the new comment box](//github.com/github/release-assets/assets/3369400/c4972040-6dd5-492d-916b-314cfec2a920)

The updated comment box is designed to integrate seamlessly with the existing GitHub environment, ensuring a familiar yet improved experience for all users. Highlights and improvements include:

* **Enhanced User Experience:** The newly revamped comment box brings an elevated experience to a wider range of users across various devices. With this update, we've enhanced the responsiveness and streamlined the markup to better accommodate keyboard and screen reader users. This ensures a uniform and smooth user experience across issues, discussions, and pull requests, promoting seamless communication and collaboration.
* **Consistency and Familiarity:** Our design philosophy for the new comment box was clear: keep it familiar, make it better. We’ve developed the updated version to closely resemble the original while enhancing it with improved accessibility, consistency, and ease of use across various screen sizes. The transition for you will be smooth, with no disruptions to your workflow.
* **Commitment to Accessibility:** This update contributes to our continuous journey to make GitHub more accessible to everyone. The comment box now aligns more closely with our accessibility commitment, enhancing the experience in features such as issues, pull requests, and discussions. Check out our [Accessibility Commitment](https://accessibility.github.com) to learn more about how we are making GitHub more inclusive.

We are excited for you to experience the new comment box and we welcome [feedback](https://github.com/orgs/community/discussions/73066) to continue improving GitHub for everyone.