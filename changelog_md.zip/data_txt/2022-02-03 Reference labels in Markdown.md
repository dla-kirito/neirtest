February 3, 2022 

When a URL in Markdown references a label, the label is now automatically rendered.

![Shows the process of pasting the url of a label into an editor that renders the label when switching to the Preview tab](https://i0.wp.com/user-images.githubusercontent.com/3369400/152137974-9b60f931-d406-49ca-a273-ab62154300b9.gif?ssl=1)