November 14, 2019 

Keep your projects moving and merge pull requests faster with scheduled reminders.

Send Slack notifications for pending code reviews to the channel of your choice and avoid missing important reviews. This feature enables teams to focus on the most important code reviews requiring their attention and ensure pull requests do not become stale.

Once you [sign up for the beta](https://github.com/features/reminders/signup), scheduled reminders are available for all users who are members of the organization.

[Learn more about scheduled reminders on GitHub](https://help.github.com/en/github/setting-up-and-managing-organizations-and-teams/managing-scheduled-reminders-for-pull-requests)