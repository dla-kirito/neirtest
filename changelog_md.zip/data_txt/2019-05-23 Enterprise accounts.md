May 23, 2019 

We’ve introducing the enterprise account to help GitHub Enterprise customers manage multiple GitHub organizations. The enterprise account can centrally manage policy and billing subscription from a seamless interface.

[Learn more about the enterprise account](https://help.github.com/articles/about-enterprise-accounts)