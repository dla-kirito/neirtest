April 8, 2021 

When configuring a custom domain for your GitHub Pages site, we will now automatically request a certificate for both the Apex and `www` subdomain of that custom domain if DNS is configured appropriately. As part of this, we've also moved the GitHub Pages settings to their own dedicated tab and refreshed the setup flow to help you get everything set up with ease.

![Screenshot of new settings page](https://i0.wp.com/user-images.githubusercontent.com/13207348/114063794-fa65e500-9866-11eb-9f14-c37b7b8d37d3.png?ssl=1)

If you don't want to use both domains with GitHub Pages, we'll continue requesting a certificate for only the specific domain you configure. Custom domains that use a subdomain other than `www` are not affected by this change.

[Learn more about custom domains in GitHub Pages](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site).