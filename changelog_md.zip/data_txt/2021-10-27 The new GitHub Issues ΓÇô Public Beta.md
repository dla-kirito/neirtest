October 27, 2021 

Since we introduced the new GitHub Issues earlier this year in a private beta, we've been working hard to expand access to all developers in order to make GitHub the best place to plan, track, and manage your work. Today, we are really excited to announce that we're moving into a public beta, and now everyone on GitHub.com has access to the new project tables and boards. 🎉 

We've used the past few months to work with our private beta users and continue to [build up the capabilities](https://github.blog/changelog/label/issues/) of project planning on GitHub with the ability to [convert a draft issue to an issue](https://github.blog/changelog/2021-08-17-the-new-github-issues-08-17-update/), [do bulk actions in tables and boards](https://github.blog/changelog/2021-09-03-the-new-github-issues-09-03-update/), [automate repetitive actions](https://github.blog/changelog/2021-09-29-the-new-github-issues-09-29-update/), [set your team's tempo with iterations](https://github.blog/changelog/2021-10-14-the-new-github-issues-10-14-update/), and so much more. Along with the new Issues being available for everyone, we're shipping these new capabilities to you today:

### 📬 Live updates[](#📬--live-updates)

Collaborate with your team in real-time! Now projects will update as you work so you never miss a thing.

This feature is rolling out gradually, and may take a few weeks to get enabled for your projects. 

![live-updates](https://i0.wp.com/user-images.githubusercontent.com/7584089/138683196-ee482d8b-6b5c-4f51-928c-28dfb9b140d3.gif?ssl=1)

### 🌐 Public Projects[](#🌐-public-projects)

Public projects let you share what you are working on with the world. Whether this is your team's roadmap, a list of items where you're seeking feedback, or the current work you have in progress – public projects help you work with your community. 

* Project admins can now toggle between public and private visibility in a project's settings screen.
* Quickly see if a project is public or private via the lock or globe icon next to the project name.
* Public projects will only show public items, any issues or PRs added from private repositories will be redacted. This includes any metadata added to them in the project view.

![public-projects-setup](https://i0.wp.com/user-images.githubusercontent.com/7584089/138859732-dbf623be-c1dc-4bc8-84ff-480e418df581.gif?ssl=1)

### 📊 Insights[](#📊-insights)

Our new burn up chart is designed to help teams visualize progress towards completion, understand development flow, and provide early warning of potential bottlenecks.

This capability has been released as a limited alpha. More organizations will be added in the future.

![Insights-alpha](https://i0.wp.com/user-images.githubusercontent.com/940508/137547741-d03fbb0e-4690-4d38-8735-5a32accf2eff.gif?ssl=1)

### ✨ Bug fixes & improvements[](#✨-bug-fixes--improvements)

We have a whole bunch of improvements for you, including: 

* GitHub Apps support, available as part of the organization projects permissions scope.
* Projects can now be created under user accounts in addition to organization accounts – head to the projects tab on your profile page to get started.
* Increased the number of views a project can have to 42 📈
* Bug fix: removed unnecessary blank rows at the bottom of the table layout.
* Bug fix: select all (`meta+a`) works when you are in the `No Status` column of the board.
* Resolved scrolling problems in Safari, especially in `group by`.
* Added the ability to apply`sort` and `group by` in the view menu. _(Previously you could only clear these in the view menu – which was very confusing!)_
* Archive all cards in a column via a new option in the column header menu.
* Improved how `,` is handled in the filter bar which now correctly triggers a new `OR` search.
* Custom fields are now clickable in the board layout to quickly apply a filter. _(This was a major request!)_
* Row highlights are easier to dismiss with the `esc` key.
* Draft issues are included as issues when filtering for `is:issue`.
* Hide a grouped column in the table layout.
* Closed issues are now purple 💜.

Thank you so much to everyone who has helped us with feedback during the private beta 🙏 

See how to use GitHub for project planning on the [GitHub Issues](http://github.com/features/issues) page, see what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/en/issues).