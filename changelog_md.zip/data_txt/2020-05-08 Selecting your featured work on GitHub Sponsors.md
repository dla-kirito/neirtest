May 8, 2020 

As a sponsored developer or organization, you can now select the public repositories to showcase on your GitHub Sponsors profile.

Previously, your [pinned repositories](https://help.github.com/en/github/setting-up-and-managing-your-github-profile/pinning-items-to-your-profile) were displayed on your sponsorship profile. Now, with this change, you can customize which repositories are displayed.

[Learn more](https://help.github.com/en/github/supporting-the-open-source-community-with-github-sponsors/setting-up-github-sponsors-for-your-user-account#completing-your-sponsored-developer-profile)