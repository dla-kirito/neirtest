May 25, 2023 

GitHub secret scanning protects users by searching repositories for known types of tokens. By identifying and flagging these tokens, our scans help prevent data leaks and fraud.

We have partnered with [Canadian Digital Service (CDS)](https://digital.canada.ca/) to scan for their tokens and help secure our mutual users on public repositories. Canadian Digital Service tokens allow users to send email and text messages using the Government of Canada’s Notify [service](https://notification.canada.ca/). GitHub will forward access tokens found in public repositories to CDS, which will then revoke the token and contact the impacted users to help them generate new tokens. You can read more information about CDS's tokens [here](https://documentation.notification.canada.ca/en/keys.html#live).

All users can scan for and block CDS tokens from entering their public repositories for free with [push protection](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning). GitHub Advanced Security customers can also scan for and block CDS tokens in their private repositories.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)