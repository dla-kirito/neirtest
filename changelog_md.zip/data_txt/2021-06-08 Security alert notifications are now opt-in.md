June 8, 2021 

Last month, we [announced](https://github.blog/changelog/2021-05-05-repository-level-notification-controls-for-security-alerts/) that security alert notifications were changing to an opt-in model. We have completed this change and users now receive notifications only for repositories they watch and have selected to receive `All Activity` or configured `Custom` to include `Security alerts`. 

![Watching control with new security alerts setting](https://i0.wp.com/user-images.githubusercontent.com/12853539/116278037-eeb96000-a73a-11eb-9a8b-a8077f69f245.png?ssl=1)

* [Learn more about configuring notifications for vulnerable dependencies](https://docs.github.com/en/code-security/supply-chain-security/configuring-notifications-for-vulnerable-dependencies)
* [Learn more about configuring notifications for secret scanning](https://docs.github.com/en/code-security/secret-security/managing-alerts-from-secret-scanning)