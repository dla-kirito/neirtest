May 18, 2023 

In the coming week, GitHub will upgrade the host operating system for the virtual machines that build and run the dev containers in GitHub Codespaces from Ubuntu 18.04 to Ubuntu 22.04\. Ubuntu 18.04 will reach its end of standard support on May 31, 2023, so we are upgrading in order to maintain the highest quality of support and security for all development environments. Most users will not be impacted by this update.

The host virtual machine is responsible for building and running the dev container configured in the devcontainer.json. When a developer connects to a codespace, they connect directly to the dev container, whose operating system is defined by the devcontainer.json configuration. This maintenance upgrade will not impact the development container configuration or prebuilds, and will not require any package updates within the development environment itself.

We recommend decoupling your dev container configuration from the host operating system. If your dev container depends on a specific host operating system version or Linux kernel version, this upgrade will impact you. For example, if you are installing specific kernel headers from the host into your dev container, you should change your configuration to install the [generic linux headers](https://packages.ubuntu.com/search?keywords=linux-headers-generic), as this package will properly update independent of the host operating system kernel version.

If you see any issues that you believe are related to this change, please reach out to [GitHub Support](https://support.github.com/).

Helpful Links:

* [Ubuntu 22.04 information](https://releases.ubuntu.com/jammy/)
* [Ubuntu 18.04 end of standard support notice](https://ubuntu.com/blog/ubuntu-18-04-eol-for-devices)