September 29, 2022 

We’ve been responding to your feedback – here’s a recap of some changes recently made to Dependabot alerts.

* Dependabot Alerts details pages now auto-magically refresh after PR generation attempts are completed, rather than spinning forever
* Alerts are more accurately mapped to Dependabot pull requests
* Labels in the Dependabot Alerts row page now act as filters
* You can now suggest improvements to an advisory directly from the alert details page (shown below).

![Suggest improvements from a Dependabot alert](https://i0.wp.com/user-images.githubusercontent.com/5788563/191867442-aad06579-c1a0-44c7-bc4a-e136ae6e0d00.gif?ssl=1)

Let us know of other improvements you’d like to see in our [GitHub community discussion page](https://github.com/community/community/discussions/categories/code-security).