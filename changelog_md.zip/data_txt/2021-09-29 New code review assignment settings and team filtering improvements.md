September 29, 2021 

Announcing new settings to help teams manage code review assignments. Also improved pull request filtering that lets you see just the pull requests you have been directly requested to review.

### New ways to manage code review assignment[](#new-ways-to-manage-code-review-assignment)

[Code review assignment](https://docs.github.com/organizations/organizing-members-into-teams/managing-code-review-assignment-for-your-team) helps distribute a team's pull request review across the team members so reviews aren't the responsibility of just one or two team members. New settings give teams more control over the behavior:

* Limit assignment to only direct members of the team. Previously, team review requests could be assigned to direct members of the team or members of child teams.
* Continue with automatic assignment even if one or more members of the team are already requested. Previously, a team member who was already requested would be counted as one of the team's automatic review requests.
* Keep a team assigned to review even if one or more members is newly assigned. Previously, the team review request was always replaced by one or more individual review requests. This would make it difficult to find pull requests where a specific team was requested.

Code review assignments settings can be managed under **Team settings** \> **Code review assignment**:

![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/134927199-77fbb389-bd6a-46c4-8313-9616683694f6.png?ssl=1)

### Better indication when a review request is assigned to a team member[](#better-indication-when-a-review-request-is-assigned-to-a-team-member)

The timeline and reviewers sidebar on the pull request page now indicate if a review request was automatically assigned to one or more team members (because the team uses code review assignment):

![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/134931920-409dea07-7a70-4557-b208-963357db7a0d.png?ssl=1)

![review assignment](https://i0.wp.com/user-images.githubusercontent.com/2503052/134932999-6eb9df9d-3871-4aa6-8f6c-a1a6b7e783bb.gif?ssl=1)

This avoids some of the mystery that previously existed around automatic code review assignments, including whether a user was directly requested to review or the request was assigned.

### Discovering just the pull requests you are requested to review[](#discovering-just-the-pull-requests-you-are-requested-to-review)

Regardless of whether your team uses code review assignment, you can now filter [pull request searches](https://docs.github.com/github/searching-for-information-on-github/searching-on-github/searching-issues-and-pull-requests) to only include those you are directly requested to review (**Awaiting review from you**):

![image](https://i0.wp.com/user-images.githubusercontent.com/2503052/134924635-8da72061-bef3-427e-adf1-253dd3a97660.png?ssl=1)

Previously, you could filter to see your review requests, but this list would include pull requests you or any team you are a member of was requested on. You can still see this list by filtering on **Awaiting review from you or your team**.

---

Learn more about [pull requests](https://docs.github.com/github/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests), [code review assignment](https://docs.github.com/organizations/organizing-members-into-teams/managing-code-review-assignment-for-your-team), and [searching pull requests](https://docs.github.com/github/searching-for-information-on-github/searching-on-github/searching-issues-and-pull-requests).