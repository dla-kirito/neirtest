January 20, 2022 

GitHub audit log streaming is now out of beta and generally available. Your experience using audit log streaming will not change, but we expanded the number of options you have for where you can stream your audit and Git events:

* Amazon S3
* Azure Blob Storage
* Azure Event Hubs
* Google Cloud Storage
* Splunk

Enterprise owners can set up their stream in minutes by navigating to their enterprise account settings under the `Audit log` tab and configuring the collection endpoint.

[Learn more about audit log streaming](https://docs.github.com/en/enterprise-cloud@latest/admin/user-management/managing-organizations-in-your-enterprise/streaming-the-audit-logs-for-organizations-in-your-enterprise-account)