August 1, 2022 

Organizations participating in the security manager role public beta may now manage security manager teams via the GitHub REST API. In addition, legacy organizations can now participate in the public beta.

[Learn more about the security manager REST API](https://docs.github.com/rest/orgs/security-managers) and [send us your feedback](https://github.com/github-community/community/discussions/categories/code-security)

[Learn more about GitHub Advanced Security](https://github.com/features/security)