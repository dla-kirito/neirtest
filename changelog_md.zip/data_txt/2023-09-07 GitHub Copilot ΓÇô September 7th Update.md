September 7, 2023 

In today’s update, we’re showing some love to our Copilot for Business admins with the release of the Copilot settings redesign and audit log integration!

## 💅🏻 Copilot for Business settings update[](#copilot-for-business-settings-update)

We’ve updated the Copilot for Business admin experience to provide an overview of important information and streamline the seat purchasing flow for Copilot. Quickly review the Copilot seats assigned and estimated charges at the top of the page, update your assignment settings without having to remember to hit a `Save` button, and verify the update to your bill when adding or removing users and teams.

![Updated Copilot Overview settings page with seats assigned, estimated bill, and seat assignment](//github.com/github/release-assets/assets/3174849/38b0d60c-a9f0-4269-9889-f2ca846b31fe)

## 🪵 Review Copilot updates with audit log integration[](#review-copilot-updates-with-audit-log-integration)

Tracing updates to settings or seat assignments is key to help admins troubleshoot unexpected behavior within their organizations. Until now, admins had to contact support to help understand changes but as of today, they can now review Copilot events by using the GitHub Audit Log. To ensure administrators can quickly review Copilot updates, we included a new filter titled “Copilot Activity”. Understand settings changes, policy updates, and seat addition/removals right from the Audit Log UI in your organization settings.

![Copilot filter selected in the audit log and the log showing Copilot events](//github.com/github/release-assets/assets/3174849/554edc31-990c-4d1d-948c-b7465cc4f61d)

## Questions, suggestions, or ideas?[](#questions-suggestions-or-ideas)

Join the conversation in the [Copilot community discussion](https://github.com/orgs/community/discussions/categories/copilot). We’d love to hear from you!