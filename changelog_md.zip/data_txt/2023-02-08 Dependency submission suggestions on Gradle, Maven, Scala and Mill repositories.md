February 8, 2023 

Dependency graph automatically supports [many ecosystems](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-the-dependency-graph#supported-package-ecosystems), but some additional ecosystems require configuration to submit dependencies with the [dependency submission API](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/using-the-dependency-submission-api). The community maintains several GitHub Actions that make this easier.

Users with write access to Gradle, Maven, Scala, and Mill repositories now see messaging on their dependency graph that directs them to an action that will scan and submit dependencies for their ecosystem. Users with access to Dependabot alerts will also see messaging on their repository's Dependabot alerts tab.

![img](https://i0.wp.com/user-images.githubusercontent.com/3474250/215532424-81457e15-5aa0-4bbf-bf51-d20f5bf6b7a3.png?ssl=1)

Prompts will display if a repository includes any of the following files: `pom.xml`, `build.gradle`, `build.gradle.kts`, `build.sbt`, or `build.sc`.

The dependency graph team is working to have native support for these types of ecosystems with more news to come later this year.

* [Learn more about the dependency graph](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/about-the-dependency-graph)
* [Explore dependency submission actions in GitHub Marketplace](https://github.com/marketplace?query=dependency+submission+)