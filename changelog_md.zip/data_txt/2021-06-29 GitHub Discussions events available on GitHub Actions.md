June 29, 2021 

GitHub Discussions integrations are now available on GitHub Actions. You can now trigger workflows on `Discussion` and `DiscussionComment` webhook events. 

Get started with [GitHub Discussions & Actions](https://docs.github.com/en/actions/reference/events-that-trigger-workflows#discussion).

For questions or feedback, visit [GitHub Discussions feedback](https://github.com/github/feedback/discussions/categories/discussions-feedback).