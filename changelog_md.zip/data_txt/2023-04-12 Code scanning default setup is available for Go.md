April 12, 2023 

Code scanning default setup is now available for Go! 

Default setup automatically finds and sets up the best CodeQL configuration for your repository. It detects the languages in the repository and enables CodeQL analysis for every pull request and every push to the default branch and any protected branches. A repository is eligible for default setup if it uses GitHub Actions and contains JavaScript/TypeScript, Python, Ruby or Go. 

You can use default setup on your repository's "Settings" tab under "Code security and analysis".

![Code scanning default setup Go](https://github.blog/wp-content/uploads/2023/04/231187975-df5168c1-21fa-4cf1-9aeb-2aa7447e33b8.png?w=300&resize=671%2C340)

This new feature is available on GitHub.com today, and will also ship with GHES 3.10\. More language support will be provided soon, and all other [CodeQL-supported languages](https://codeql.github.com/docs/codeql-overview/supported-languages-and-frameworks/) continue to work using a GitHub Actions workflow file. The options to set up code scanning using API uploads or third party analysis tools remain supported and are unchanged. 

For more information on code scanning default setup, see [Configuring code scanning automatically](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/configuring-code-scanning-for-a-repository#configuring-code-scanning-automatically).