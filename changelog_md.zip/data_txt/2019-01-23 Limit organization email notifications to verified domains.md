January 23, 2019 

Organizations on the Enterprise Cloud plan can now restrict email notifications for activity within their organization to emails within one or more verified domains. This setting allows organization admins to restrict notification routing preferences organization-wide ensuring that notifications will only be sent to approved email servers.

[Learn more about restricting email notifications about organization activity](http://help.github.com/articles/restricting-email-notifications-about-organization-activity-to-an-approved-email-domain/)