April 5, 2022 

The _CodeQL runner_ has been deprecated in favor of the _CodeQL CLI_. As [previously announced](https://github.blog/changelog/2021-09-21-codeql-runner-deprecation/), starting March 14th, the [CodeQL bundle](https://github.com/github/codeql-action/releases) now no longer includes the _CodeQL runner_. This deprecation only affects users who use CodeQL code scanning in 3rd party CI/CD systems; users of GitHub Actions are not affected.

## GitHub Enterprise Server (GHES)[](#github-enterprise-server-ghes)

The CodeQL runner was shipped as part of GitHub Enterprise Server (GHES) versions up to and including 3.3.x. GitHub Enterprise Server 3.4 and later no longer include the CodeQL runner. We strongly recommend that customers migrate to the CodeQL CLI, which is a feature-complete replacement for the CodeQL runner and has many additional features.

## How does this affect me?[](#how-does-this-affect-me)

If you’re using CodeQL code scanning on GitHub Actions, you are _not_ affected by this change.

If you’ve configured code scanning to run the CodeQL runner inside another CI/CD system, we recommend migrating to the [CodeQL CLI](https://docs.github.com/en/code-security/code-scanning/using-codeql-code-scanning-with-your-existing-ci-system/installing-codeql-cli-in-your-ci-system) as soon as possible.  
Starting April 1st, changes to both the CodeQL analysis engine and the code scanning API are not guaranteed to be compatible with older CodeQL runner releases.

## What actions should I take?[](#what-actions-should-i-take)

You should configure your CI/CD system to [use the CodeQL CLI](https://docs.github.com/en/code-security/code-scanning/using-codeql-code-scanning-with-your-existing-ci-system/installing-codeql-cli-in-your-ci-system) before upgrading to GHES 3.4.0\. When setting up the CodeQL CLI, we recommend that you [test the CodeQL CLI set up](https://docs.github.com/en/code-security/code-scanning/using-codeql-code-scanning-with-your-existing-ci-system/installing-codeql-cli-in-your-ci-system#testing-the-codeql-cli-set-up) to verify that the CLI is correctly configured to analyze your repository.

Learn more about migrating from the CodeQL runner to the CodeQL CLI [here](https://docs.github.com/en/code-security/code-scanning/using-codeql-code-scanning-with-your-existing-ci-system/migrating-from-the-codeql-runner-to-codeql-cli).