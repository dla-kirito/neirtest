September 29, 2023 

If you are a security manager or a user with admin permissions to a repository, you can now delete the workspace directly from the repository advisory, regardless of the state of the advisory. Before this, there was no option to delete such private forks.

![New delete private fork button](https://i0.wp.com/user-images.githubusercontent.com/8700883/271699377-9b1752cb-45dd-4411-8fa8-0b4613404ad0.png)