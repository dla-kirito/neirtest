December 16, 2022 

GitHub Actions hosted runner images are now more secure than ever, with the ability to see exactly what software is pre-installed on the image that was used by the runner during your build. GitHub now attaches a software bill of materials (SBOM) as an asset to each image release for Ubuntu and Windows. Support for Mac runners is targeted for Q1 2023.

In the context of GitHub Actions hosted runners, an SBOM details the software pre-installed on the virtual machine that is running your Actions workflows. This is useful in the situation where there is a vulnerability detected, you will be able to quickly tell if you are affected or not. If you are building artifacts, you can include this SBOM in your bill of materials for a comprehensive list of everything that went into creating your software.

To check out the new files, head over to the runner-images repository [release page](https://github.com/actions/runner-images/releases) now or check out our [docs](https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions) for more information.