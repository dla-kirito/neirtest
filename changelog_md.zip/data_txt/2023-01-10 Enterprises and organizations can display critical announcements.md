January 10, 2023 

GitHub Enterprise Cloud admins can now display critical announcements to members of their enterprise or specific organizations. GitHub Enterprise Server already has this capability.

With this enhancement, Enterprise Cloud admins can display a critical message on all pages of their enterprise or in specific organizations. For example, you could announce a release cutoff date or an upcoming permission change. Announcements are displayed at the tops of pages as shown here:

![An image showing how an announcement message appears on GitHub](https://i0.wp.com/user-images.githubusercontent.com/1767415/210844773-1be97cb6-734d-4546-9d67-3da486c81ac3.png?ssl=1)

To publish an announcement, you must be an enterprise owner or organization owner. Open your enterprise or organization settings and select **Announcement**. Enter your announcement message, an optional expiration when the announcement should be automatically unpublished, and select whether to allow users to dismiss the announcement when they see it. Click **Publish announcement** to publish it.

![An image showing configuration of an announcement](https://i0.wp.com/user-images.githubusercontent.com/1767415/210845434-fd186c4c-10ae-4e1f-b5a7-f3d4c7e6375d.png?ssl=1)

For the best user experience, we recommend publishing only critical announcements and keeping the message brief to occupy less display space on each page. Link the message to a [discussion](https://github.com/features/discussions) for more context, guidance, and optional conversation. For non-critical messages or extended announcements, use a discussion instead.

For more details, see [Customizing user messages for your enterprise](https://docs.github.com/en/enterprise-cloud@latest/admin/user-management/managing-users-in-your-enterprise/customizing-user-messages-for-your-enterprise) in the GitHub Enterprise Cloud documentation.