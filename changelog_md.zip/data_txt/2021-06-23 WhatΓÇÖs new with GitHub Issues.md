June 23, 2021 

![GitHub Issues banner image](https://i0.wp.com/user-images.githubusercontent.com/22751162/122999697-38f24280-d374-11eb-970b-f0156d026d88.png?ssl=1)

Today we are announcing new beta features within GitHub Issues, with better ways to plan, track, and manage projects.

Read more on the [GitHub Issues](http://github.com/features/issues) page or in the [FAQ](http://github.com/features/issues#faq). 

### ✨ NEW – Project planning for developers[](#✨-new---project-planning-for-developers)

_Available in limited public beta_

Built like a spreadsheet, [project tables](https://docs.github.com/en/issues/trying-out-the-new-projects-experience/about-projects) give you a live canvas to filter, sort, and group issues and pull requests. Tailor them to your needs with custom fields and saved views. [Sign up for the beta now](https://github.com/features/issues).

* Prioritize your work across repositories with a new spreadsheet-like table
* Extend issues with custom fields with support for text, number, date and single-select types
* Change custom field values right from the issues sidebar
* Filter, sort, and group by any field
* Instantly switch between project tables and boards
* Save your view options to share with your team
* Build custom workflows with a GraphQL API to access project issues and metadata
* Use cmd \+ k to bring up a [command palette](https://docs.github.com/en/issues/trying-out-the-new-projects-experience/customizing-your-project-views#command-palette) that lets you filter, sort, group, and manage views

### ✨ NEW – Break issues into actionable tasks[](#✨-new---break-issues-into-actionable-tasks)

_Available in public beta_

When [lists of tasks are created in markdown](https://docs.github.com/en/issues/tracking-your-work-with-issues/creating-issues/about-task-lists) and referenced in another issue, this will now create a dynamic relationship that helps you break down your work and track it to completion. Convert text into issues quickly after brainstorming ideas with your team, and stay up to date on progress now that tracked issues are automatically checked off when closed.

* Create task lists of issues and pull requests
* Quickly convert text into issues
* Track status of tasks with progress indicators
* See which issues another issue is being tracked in
* Automatically update the status of a task when the tracked issue is closed

![View the progress of your issues and see how work is related with task lists](https://i0.wp.com/user-images.githubusercontent.com/22751162/123090900-4ea44e00-d3ee-11eb-85cb-cad7c0894224.png?ssl=1)

### 📣 Got feedback?[](#📣-got-feedback)

[Join our feedback community](https://github.com/github/feedback/discussions/categories/issues-feedback) and let us know how we can improve.