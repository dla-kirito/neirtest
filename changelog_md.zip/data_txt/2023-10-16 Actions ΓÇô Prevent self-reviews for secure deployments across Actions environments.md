October 16, 2023 

Actions environments now makes it more secure to review and control deployments using manual approvals.

Previously, any user could trigger a workflow and also manually approve/reject a deployment job targeting a protected environment, if they are a required reviewer.

We are now introducing an option for environment admins to [prevent required reviewers from self-reviews](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#required-reviewers) to secure deployments targeting their critical environments.  
This would enforce that a different reviewer could approve and sign off the deployments, rather than the same user who triggered the run – making the deployments more secure.  
![Prevent self-reviews](https://i0.wp.com/user-images.githubusercontent.com/25389593/275635597-ad54403a-5898-4e20-b2bd-c4677ba95d5d.png)

Learn more about securing environments using [deployment protection rules](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#deployment-protection-rules).  
For questions, visit the [GitHub Actions community](https://github.com/orgs/community/discussions/categories/actions-and-packages).  
To see what's next for Actions, visit our [public roadmap](https://github.com/orgs/github/projects/4247).