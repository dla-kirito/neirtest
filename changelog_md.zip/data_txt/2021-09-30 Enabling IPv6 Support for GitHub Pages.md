September 30, 2021 

GitHub Pages now supports IPv6 for all Pages hosted on \*.github.io and custom domains. Documentation for enabling IPv6 with custom domains can be found [here](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site).