July 26, 2021 

We have shipped improvements to the code scanning alerts branch filter! These changes make it clearer which code scanning alerts are being displayed on the alerts page.

By default, the code scanning alerts are filtered to show alerts for the default branch of the repository only. You can use the branch filter to display the alerts on any of the non-default branches. Any branch filter that has been applied is shown in the search bar.

We have simplified the search syntax to the format `branch:` You can use this syntax multiple times in the search bar to filter on multiple branches. The previous syntax `ref:refs/heads/[branch name]` is still supported, so any saved URLs will continue to work.

![Branch filter](https://i0.wp.com/user-images.githubusercontent.com/19343236/126979612-974aae26-510f-40e9-9bd5-15f13908268d.png?ssl=1)