July 28, 2022 

The GitHub Enterprise Server 3.6 Release Candidate is available and contains exciting updates and additions across the board.

Release Candidates are a way for you to try the latest features at the earliest time, and they help us gather feedback early to ensure the release works in your environment. They should be tested on non-production environments. Here are some highlights for this release.

* System administrators will welcome the introduction of [audit log streaming](https://docs.github.com/en/enterprise-server@3.6/admin/monitoring-activity-in-your-enterprise/reviewing-audit-logs-for-your-enterprise/streaming-the-audit-log-for-your-enterprise) and those using [GitHub Connect](https://docs.github.com/en/enterprise-server@3.6/admin/configuration/configuring-github-connect/about-github-connect) now have access to [Server Statistics](https://docs.github.com/en/enterprise-server@3.6/admin/monitoring-activity-in-your-enterprise/analyzing-how-your-team-works-with-server-statistics/about-server-statistics).
* Developers will be delighted with the arrival of [GitHub Discussions](https://docs.github.com/en/enterprise-server@3.6/discussions). Get a 60 second video introduction to GitHub Discussions [here](https://youtu.be/IpBw2SJkFyk).
* General security improvements see the removal of insecure SSH keys and protocols from Git, and the addition of TLS enforcement for inbound SMTP connections.
* Advanced Security security overview now includes all alert types and dependency review now has an API and an associated Action, making it easy to break the build if a vulnerable dependency is being introduced. Secret scanning adds push protection for the web UI and the much requested [dry run for custom patterns](https://github.blog/changelog/2022-06-16-secret-scanning-dry-runs-for-custom-patterns-on-edits/).

Read about these features and more in the full [GitHub Enterprise Server 3.6 release notes](https://docs.github.com/en/enterprise-server@3.6/admin/release-notes#3.6.0.rc1). We look forward to hearing your feedback! [Contact our Support team](https://support.enterprise.github.com/) with any questions.

[Download it today](https://enterprise.github.com/releases/3.6.0/download).