February 4, 2020 

Find all the open issues in a repository that have closing pull requests references with the `linked:pr` search qualifier. Similarly, locate all the pull requests in a repository that are  
missing a supporting issue with `-linked:issue`.

[Try it on your personal issues list](https://github.com/issues?utf8=%E2%9C%93&q=is%3Aopen+is%3Aissue+author%3A%40me+archived%3Afalse+linked%3Apr)!