November 5, 2019 

You’re now required to obtain an OAuth token via the [web application flow](https://developer.github.com/apps/building-oauth-apps/authorizing-oauth-apps/#web-application-flow) for SAML access to organizations requiring SSO. In most cases, this change also prohibits access via tokens granted from the [Authorizations API](https://developer.github.com/v3/oauth%5Fauthorizations/).

[Learn more about upcoming security API deprecations announcements](https://developer.github.com/changes/2019-11-05-deprecated-passwords-and-authorizations-api/)