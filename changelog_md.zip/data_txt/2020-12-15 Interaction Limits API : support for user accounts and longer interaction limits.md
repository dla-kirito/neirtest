December 15, 2020 

We’ve expanded our REST and GraphQL APIs for interaction limits to include two recently released features:

* [set and query interaction limits for user accounts](https://github.blog/changelog/2020-12-15-temporary-interaction-limits-for-user-accounts/)
* [set longer interaction limits on repositories, organizations, and user accounts](https://github.blog/changelog/2020-10-01-temporary-interaction-limits-can-now-be-set-for-up-to-six-months/)

[Learn more about the GitHub Interaction Limits REST API](https://docs.github.com/en/free-pro-team@latest/rest/reference/interactions)

[Learn more about the GitHub Interaction Limits GraphQL API](https://docs.github.com/en/free-pro-team@latest/graphql/reference/objects#repositoryinteractionability) 