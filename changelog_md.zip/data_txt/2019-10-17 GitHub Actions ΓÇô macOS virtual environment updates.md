October 17, 2019 

We’ve fully deployed updates to the [GitHub Actions macOS 10.14 virtual environment](https://help.github.com/en/articles/software-in-virtual-environments-for-github-actions#macos-1014). Highlights include:

* Upgraded macOS 10.14.6 (18G95) to 10.14.6 (18G103)
* Upgraded NVM 12.11.0 to 12.11.1
* Upgraded Go 1.13 to 1.13.1
* Upgraded CocoaPods 1.8.0 to 1.8.1
* Upgraded Yarn 1.17.3 to 1.19.0
* Upgraded fastlane 2.131.0 to 2.132.0
* Added Xcode 11.1
* Downgraded lldb 3.1.4508709 to 2.3.3614996
* Upgraded VS for Mac 8.3.0.1805 to 8.3.1.18
* Added iOS 13.1 SDKs