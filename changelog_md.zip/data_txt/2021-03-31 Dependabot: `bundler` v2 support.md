March 31, 2021 

Dependabot now supports `bundler` v2 for both security and version updates.

Learn more about Dependabot [version updates](https://docs.github.com/en/github/administering-a-repository/about-dependabot-version-updates) and [security updates](https://docs.github.com/en/code-security/supply-chain-security/about-dependabot-security-updates).

[To see what’s next for Dependabot, visit the public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=label%3A%22security+%26+compliance%22).