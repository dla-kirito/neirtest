June 29, 2023 

Enterprise users will now notice added functionality where Dependabot security and version updates may be paused for repositories.

If you are an enterprise user that uses Dependabot updates and there has been no activity in a repository, such as merging, closing, or any other interaction, with Dependabot pull requests for a period exceeding 90 days, the updates will be paused. To resume activity, simply merge or close one of Dependabot's pull requests, or modify the Dependabot config file in the repository.

This change will help Dependabot be more focused to the repositories you care about and reduce use of GitHub Actions minutes on inactive Dependabot pull requests.

If you are using security overview with GitHub Advanced Security, you will be able to see which repositories in your organization have been paused from the security coverage view.

You will also be able to see whether Dependabot has been paused for a repository by querying the `/repos/{owner}/{repo}/automated-security-fixes` REST API endpoint, which will return both the enablement status and paused status of the repository.

### When will Dependabot become paused?[](#when-will-dependabot-become-paused)

This change only applies to repositories where Dependabot pull requests exist but remain untouched. If no Dependabot pull requests have been opened, Dependabot will never become paused.

The following must be true for at least 90 days:

* Has not had a Dependabot PR merged
* Has not had changes made to the Dependabot config file
* Has not had any @dependabot comment-ops performed
* Has not had any Dependabot PRs closed by the user
* **Has received at least one Dependabot PR before the 90 day window**
* **Has at least one Dependabot PR open at the end of the 90 day window**
* Has had Dependabot enabled for this entire period

### How will Dependabot let me know?[](#how-will-dependabot-let-me-know)

Dependabot will add a notice to the body of all open Dependabot pull requests and add a `dependabot-paused` label to them. Dependabot will also add a banner notice in the UI of your repository settings page (under “Dependabot”) as well as your Dependabot alerts page (if Dependabot security updates are affected).

### Who can use this feature?[](#who-can-use-this-feature)

This change _does not_ apply to Dependabot alerts or subsequent notifications. So, only repositories that have automated Dependabot version updates or security updates, but haven't interacted with these pull requests for a while, will be affected.

Learn more [about this change](https://github.blog/2023-01-12-a-smarter-quieter-dependabot)  
Learn more [about how to interact with the REST API](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28)