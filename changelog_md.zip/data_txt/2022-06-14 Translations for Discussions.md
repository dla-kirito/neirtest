June 14, 2022 

Translations are now available for discussion comments in Spanish, Portuguese, Korean, and English. If your first preference browser language is different from the language of the discussion comment, you will now see an option to translate the comment’s contents.

![Discussion comment in Spanish being translated to English and back again](https://i0.wp.com/user-images.githubusercontent.com/8298818/173657068-97b30954-39ea-4a3d-9d5d-4c3529c74e09.gif?ssl=1)

This feature is in beta and we’d love your feedback. Leave us a note [here](https://github.com/github-community/community/discussions/4373) and let us know what you think.

**Traduções para Discussões**

As traduções estão agora disponíveis para comentários de discussão em espanhol, português, coreano e inglês. Se seu primeiro idioma de navegação preferido for diferente do idioma do comentário da discussão, você verá agora uma opção para traduzir o conteúdo do comentário.

Esta funcionalidade está em versão beta e adoraríamos seu feedback. Escreva um comentário para a gente [aqui](https://github.com/github-community/community/discussions/4374) e diga o que você acha.

**Traducciones para Discusiones**

Las traducciones ahora están disponibles para comentarios de discusión en español, portugués, coreano e inglés. Si el idioma de tu navegador predeterminado es diferente al del idioma del comentario de discusión, ahora verás una opción para traducir el contenido del comentario.

Esta funcionalidad está en versión beta y nos encantaría recibir tu opinión. Déjanos una nota [aquí](https://github.com/github-community/community/discussions/6534) y cuéntanos lo que piensas.

**디스커션 번역 기능**

깃허브 디스커션 코멘트/댓글에서 이제 한국어, 스패인어, 포르투갈어, 그리고 영어로 번역 가능한 기능이 더해졌습니다. 웹브라우져에서 디폴트로 설정 되어 있는 언어가 깃허브 디스커션 코멘트/댓글 언어와 다르다면 내용을 자동 번역 할수 있는 링크 옵션을 선택하실수 있습니다.

현재 이 기능은 베타 버전이며 여러분의 소중한 의견이 필요합니다. [여기 링크](https://github.com/github-community/community/discussions/4372) 를 통해서 피드백을 남겨 주시면 깃허브 디스커션 번역 기능을 개선 시키는데 많은 도움이 될것 입니다. 감사합니다.