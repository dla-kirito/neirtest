June 21, 2019 

New issues on mobile web now have improved editing features! We’ve optimized the design for the mobile authoring experience, making it easier to add links, format text, and take quick actions like referencing pull requests and issues.

![Screen recording of Markdown toolbar actions](https://i0.wp.com/user-images.githubusercontent.com/334891/59943428-316bcc00-9430-11e9-8179-b0348eb365c1.gif?resize=2600%2C1676&ssl=1)