December 16, 2021 

Today you will begin to see a new workflow running called `pages build and deployment` in your public GitHub Pages repositories. This workflow is automatically triggered when you push to the branch configured for GitHub Pages in your repository. As the name suggests, it builds and deploys your pages site. The initial benefit of this change is enabling you to see your build logs and any errors that may occur which has been a long standing issue for Pages users. However, in the future this will enable us to give you the ability to fully customize your pages build and deployment workflow to use any static site generator you want without having to push the build output to a special branch of the repository.

You may notice this workflow uses some new actions `actions/pages-deploy`, and `actions/jekyll-build-pages`. For now these actions are designed to be used in the generated workflow, however, starting early next year we will introduce some additional changes that will enable you to take advantage of them.

[Learn more about GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages)