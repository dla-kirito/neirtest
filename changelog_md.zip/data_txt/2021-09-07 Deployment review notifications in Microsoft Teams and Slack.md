September 7, 2021 

Deployment review notifications for your GitHub Actions environments can now be tracked end-to-end using the GitHub app for Microsoft Teams or Slack. You will be notified when a review is pending on your environment, when an approval is completed and you can see the real time status of your deployment.

The following capabilities have been added to our Microsoft Teams and Slack applications:

1. Deployment review pending notifications for your environments being deployed through GitHub Actions workflow.
2. Deployment review completed notifications for your environments being deployed through GitHub Actions workflow.
3. Deployment status notifications for your environments.

For more information visit the GitHub app guidance for [Microsoft Teams](https://github.com/integrations/microsoft-teams/blob/master/Readme.md#deployments-and-actions-approval-notifications) or for [Slack](https://github.com/integrations/slack/blob/master/README.md#deployments-and-actions-approval-notifications)