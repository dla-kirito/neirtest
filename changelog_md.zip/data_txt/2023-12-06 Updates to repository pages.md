December 6, 2023 

We are rolling out a few minor updates to the user experience for GitHub repositories starting today, in order to be more responsive, performant and more easily accessed by a broader range of users.

**Repository Overview:**  
![Screenshot of repository overview page showing entering a letter to expand to go to file menu.](https://github.com/github/release-assets/assets/7575792/39941608-672c-439f-92e2-3852a65ba111)

* Go to file: Quickly get to the file you want from the top of every repository using our existing code search and navigation experience.
* Special files: If you have Code of Conduct, License, or Security files in your repository, they are now shown in tabs alongside your README.

**Branches:**  
![Screenshot of branches page showing the overview tab for branches of GitHub Docs repos.](https://github.blog/wp-content/uploads/2023/12/GitHubScreenShot-Google-Chrome-04-12-2023-002221.jpg?resize=1520%2C764)

* Status checks: At a glance, see the status checks’ details on any branch.
* Stale Branches: The overview page for branches no longer defaults to showing stale branches to improve load times. You can still easily see stale branches by clicking the “Stale branches” tab.

**Commits:**  
![Screenshot of Commits page filtered by date and user.](https://github.com/github/release-assets/assets/7575792/dffba416-fd6d-401a-8c82-91a17e08bf6f)

* Filters: New commits filters allow you to sort by users or limit results to specific date ranges.

These changes have been in a feature preview for the past few months and thanks to community insights, we’ve made several improvements that allowed us to now exit the preview, and bring these enhancements to everyone on GitHub. Join the conversation about this release in the [community discussion.](https://github.com/orgs/community/discussions/77999)