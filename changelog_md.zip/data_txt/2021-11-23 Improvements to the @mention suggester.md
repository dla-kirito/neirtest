November 23, 2021 

The @mention suggester now ranks participants in Issues, Pull Requests, and Discussions higher so that it’s more likely the person you are looking for will be listed first.

[![A screenshot of the GitHub issues UI showing a comment from Lizz and in the textarea below a user who typed "@l" which triggered the suggester dropdown to show with @LizzHale as the first entry.](https://i0.wp.com/user-images.githubusercontent.com/3369400/138904398-194bd492-4bd3-457e-91e4-b985597c6eef.png?ssl=1)](https://i0.wp.com/user-images.githubusercontent.com/3369400/138904398-194bd492-4bd3-457e-91e4-b985597c6eef.png?ssl=1)