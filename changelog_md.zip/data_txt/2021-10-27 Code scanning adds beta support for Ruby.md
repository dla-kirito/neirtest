October 27, 2021 

Ruby is the [10th most popular language](https://octoverse.github.com/) within the open source community. To help more open source maintainers and organizations find potential vulnerabilities in their code, we’ve added Ruby support (beta) to the CodeQL engine that powers [GitHub code scanning](https://docs.github.com/en/github/finding-security-vulnerabilities-and-errors-in-your-code/about-code-scanning).

Our [CodeQL analysis](https://codeql.github.com/) identifies security issues in your code, along with the flow of data to the vulnerable location. To help secure services and tools created with Ruby, the CodeQL [beta](https://github.com/github/roadmap/issues/136) release spots many of the most common security issues:

* SQL injection ([CWE-089](https://cwe.mitre.org/data/definitions/89.html))
* ReDoS (regular expression denial-of-service, [CWE-1333](https://cwe.mitre.org/data/definitions/1333.html))
* OS command and argument injection ([A1:2017-Injection](https://owasp.org/www-project-top-ten/2017/A1%5F2017-Injection), [CWE-078](https://cwe.mitre.org/data/definitions/78.html), [CWE-088](https://cwe.mitre.org/data/definitions/88.html))
* XML entity expansion ([CWE-611](https://cwe.mitre.org/data/definitions/611.html), [CWE-827](https://cwe.mitre.org/data/definitions/827.html))
* Reflected cross-site scripting (XSS) ([A7:2017-Cross-Site Scripting](https://owasp.org/www-project-top-ten/2017/A7%5F2017-Cross-Site%5FScripting%5F%28XSS%29), [CWE-079](https://cwe.mitre.org/data/definitions/79.html))
* Stored XSS ([CWE-079](https://cwe.mitre.org/data/definitions/79.html), [CWE-116](https://cwe.mitre.org/data/definitions/116.html))
* Unsafe deserialization ([CWE-502](https://cwe.mitre.org/data/definitions/502.html))
* Hard-coded credentials ([CWE-798](https://cwe.mitre.org/data/definitions/798.html))

We’ve been putting this beta through its paces by analyzing some of the world's largest Ruby codebases at GitHub and select customers. The feedback has been overwhelmingly positive, and in many cases CodeQL identified real vulnerabilities, all while keeping the number of false-positives at a minimum.

CodeQL for Ruby is available by default in [GitHub.com](http://github.com/) code scanning, the [CodeQL CLI](https://github.com/github/codeql-cli-binaries/releases), and the [CodeQL extension for VS Code](https://marketplace.visualstudio.com/items?itemName=GitHub.vscode-codeql) starting today. It will also be included in GitHub Enterprise Server 3.4\. Ruby joins the list of [supported CodeQL languages](https://codeql.github.com/docs/codeql-overview/supported-languages-and-frameworks/), which also includes C/C++, C#, Java, JavaScript/TypeScript, Python, and Go.

We currently support all common Ruby versions, up to and including 3.02\. Check out [the documentation](https://codeql.github.com/docs/codeql-language-guides/codeql-for-ruby/) for more details on compatibility. 

To start using the new Ruby analysis, simply [update your existing workflow file](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/configuring-code-scanning#changing-the-languages-that-are-analyzed) by adding Ruby to the language matrix:

```yaml
jobs:
  analyze:
    name: Analyze
    ...
    strategy:
      fail-fast: false
      matrix:
        # add here
        language: ['ruby']
```

If you’re new to code scanning, set up a [CodeQL analysis workflow](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-code-scanning-with-codeql) from the Security tab in your repository.

Want to contribute or write your own CodeQL queries for Ruby? [This guide](https://codeql.github.com/docs/codeql-language-guides/codeql-for-ruby/) will help you get started. 

To give us feedback, join [the Ruby beta discussion](https://github.com/github/codeql/discussions/6922) in the public CodeQL repository, which is also a good place to ask questions about anything CodeQL.