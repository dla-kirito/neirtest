January 10, 2023 

Today, we are announcing public beta of required workflows in GitHub Actions 🎉

Required workflows allow DevOps teams to define and enforce standard CI/CD practices across many source code repositories within an organization without needing to configure each repository individually. Organization admins can configure required workflows to run on all or selected repositories within the organization.

![Required workflows at the organization level](https://i0.wp.com/user-images.githubusercontent.com/25578249/211551996-c32d315d-e9a5-47fd-b74b-7263773ce77a.png?ssl=1)

Required workflows will be triggered as required status checks for all the pull requests opened on the default branch, which blocks the ability to merge the pull request until the required workflow succeeds.  
Individual development teams at the repository level will be able to see what required workflows have been applied to their repository.

![Required workflows run at repo](https://i0.wp.com/user-images.githubusercontent.com/25578249/211552010-d7aa7c25-f204-4c20-a04b-9c53f74ec52e.png?ssl=1)

In addition to reducing duplication of CI/CD configuration code, required workflows can also help companies with the following use cases:

* Security: Invoke external vulnerability scoring or dynamic analysis tools.
* Compliance: Ensure that all code meets an enterprise’s quality standards.
* Deployment: Ensure that code is continuously deployed in a standard way.

[Learn more about required workflows](https://docs.github.com/actions/using-workflows/required-workflows)