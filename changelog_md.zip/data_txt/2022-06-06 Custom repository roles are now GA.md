June 6, 2022 

[Custom repository roles](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization) are now GA for GitHub.com and [Enterprise Server 3.5](https://docs.github.com/enterprise-server@3.5/admin/release-notes#custom-repository-roles-are-generally-available).

Organization admins can create custom repository roles available to all repositories in their organization. Roles can be configured from a set of [35 fine grained permissions](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization#additional-permissions-for-custom-roles) covering discussions, issues, pull requests, repos, and security alerts. Once a role is created, repository admins can assign a custom role to any individual or team in their repository.

Custom repository roles can be managed in the Repository roles tab of your Organization settings:

![image](https://i0.wp.com/user-images.githubusercontent.com/1666363/172208538-271bddc0-f374-4c6c-9c47-e1f246a9235b.png?ssl=1)

Custom repository roles are also supported in the GitHub REST APIs. The [Custom Roles API](https://docs.github.com/en/rest/orgs/custom-roles) can be used to list all custom repository roles in an organization, and the existing APIs for granting repository access to [individuals](https://docs.github.com/en/rest/collaborators/collaborators#add-a-repository-collaborator) and [teams](https://docs.github.com/en/enterprise-cloud@latest/rest/teams/teams#add-or-update-team-repository-permissions) support custom repository roles.

To get started with custom repository roles, [read the docs](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization).