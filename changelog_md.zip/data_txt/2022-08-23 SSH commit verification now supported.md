August 23, 2022 

GitHub now supports SSH commit verification, so you can sign commits and tags locally using a self-generated SSH public key, which will give others confidence about the origin of a change you have made. If a commit or tag has an SSH signature that is cryptographically verifiable, GitHub makes the commit or tag "Verified" or "Partially Verified." 

![image-of-verified-commit](https://i0.wp.com/user-images.githubusercontent.com/4021812/186039068-d0d84d96-873b-44ec-8536-5e3e0ab648a3.png?ssl=1)

If you already use an SSH key to authenticate with GitHub, you can now upload the same or a different key pair’s public key to use it as a signing key. There is no limit to the number of signing keys you can add to your account. For more information, visit [SSH Commit Verification](https://docs.github.com/en/authentication/managing-commit-signature-verification/about-commit-signature-verification#ssh-commit-verification) in the GitHub documentation.

![image-of-ssh-signing-key-ui](https://i0.wp.com/user-images.githubusercontent.com/4021812/186039066-03b2d56f-6e15-44ee-a6ef-37bab5d5b47d.png?ssl=1)