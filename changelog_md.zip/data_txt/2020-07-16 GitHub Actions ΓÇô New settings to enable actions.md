July 16, 2020 

We have introduced the ability [for enterprises to enable or disable GitHub Actions for specific organizations](https://docs.github.com/en/github/setting-up-and-managing-your-enterprise-account/enforcing-github-actions-policies-in-your-enterprise-account). GitHub organization admins can also opt in or opt out specific repositories from using GitHub Actions.

Additionally, organizations and repositories may now be able to choose Actions settings that are more restrictive than their organization or enterprise settings. 

If you have any questions or thoughts about these changes, we recommend asking in our GitHub Community Forum's [Actions Board](https://github.community/c/github-actions/41)!