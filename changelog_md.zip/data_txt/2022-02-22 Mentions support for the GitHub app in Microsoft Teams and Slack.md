February 22, 2022 

Are you using our GitHub app in Microsoft Teams or Slack? Do you find it difficult to track all the notifications you get in your channels?  
If yes, here comes a feature that helps you focus on the notifications that are relevant to you! 🎉

![Teams PR mentions](https://i0.wp.com/user-images.githubusercontent.com/25578249/154482898-be7c6937-0ef4-4582-a639-dcd05d5ec725.png?w=490&ssl=1)  
![Slack PR mentions](https://i0.wp.com/user-images.githubusercontent.com/25578249/155087354-71b9b7c9-5694-4af5-88a9-113d6c86c5b4.png?w=515&ssl=1)

When you subscribe to a repository in Microsoft Teams or Slack, you will now see yourself mentioned in the notifications where you are referred and needs your attention.  
As you receive notifications for Issues, PRs, Discussions and Deployments, here are the cases when you will be mentioned.

* Assignee in an Issue
* Reviewer for a PR
* Mentioned in a PR/Issue description/comment/discussion
* Reviewer for a Deployment
* Scheduled reminders for PR review requests

See [GitHub for Microsoft Teams](https://github.com/integrations/microsoft-teams/blob/master/Readme.md) or [GitHub for Slack](https://github.com/integrations/slack/blob/master/README.md) for more information about this feature.