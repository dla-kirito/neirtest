March 18, 2019 

The Reviews filter on pull request pages can now filter for pull requests not reviewed by you.

[Learn more about pull requests](https://help.github.com/articles/about-pull-requests/)