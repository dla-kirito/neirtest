August 29, 2023 

Enterprise Managed User namespace repositories were previously able to use GitHub-hosted Actions runners outside of the owning enterprise's entitlements. This was not an intentional configuration. Today we have disabled the ability for EMU user namespace repositories to use GitHub-hosted runners.

For customers using inner source workflows we recommend forking from an organization owned repository into your user namespace. You may then open a pull request back to the upstream repository and actions workflows will run as usual within the context of that organization and enterprise.

Learn more about [enabling private repositories to run actions workflows from forks](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#enabling-workflows-for-forks-of-private-repositories).