July 19, 2022 

Starting next week, workflow re-runs in GitHub Actions will use the initial run’s actor for privilege evaluation. The actor who triggered the re-run will continue to be displayed in the UI, and can be accessed in a workflow via the `triggering_actor` field in the [github context](https://docs.github.com/en/actions/learn-github-actions/contexts#github-context).

Currently, the privileges (e.g. – secrets, permissions) of a run are derived from the triggering actor. This poses a challenge in situations where the actor triggering a re-run is different than the original executing actor. The upcoming change will differentiate the initial executing actor from the triggering actor, enabling the stable execution of re-runs.

For more details see [Re-running workflows and jobs](https://docs.github.com/en/actions/managing-workflow-runs/re-running-workflows-and-jobs).

For questions, [visit the GitHub Actions community](https://github.community/c/code-to-cloud/github-actions/41).

To see what’s next for Actions, [visit our public roadmap](https://github.com/orgs/github/projects/4247/views/1?filterQuery=actions).