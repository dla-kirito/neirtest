August 2, 2021 

API requests made by a GitHub App on behalf of a user that has authorized the app are known as _user-to-server requests_.

The resources that can be accessed by these requests are constrained to the set of _private_ resources that _both_ the App and the authorizing user can access.

GitHub is now extending this access model, allowing user-to-server requests to also read public resources over [the REST API](https://docs.github.com/en/rest/reference). This includes, for example, the ability to list a public repository's [issues](https://docs.github.com/rest/reference/issues#list-repository-issues) and [pull requests](https://docs.github.com/rest/reference/pulls#list-pull-requests), and to access a public repository's [comments](https://docs.github.com/rest/reference/issues#list-issue-comments-for-a-repository) and [content](https://docs.github.com/rest/reference/repos#get-repository-content).

Read more about [authorizing GitHub Apps](https://docs.github.com/en/github/authenticating-to-github/keeping-your-account-and-data-secure/authorizing-github-apps).