November 7, 2018 

[Transfer issue](https://blog.github.com/changelog/2018-10-30-issue-transfer/) and [delete issue](https://blog.github.com/changelog/2018-11-07-delete-an-issue/) now include webhook support. 

[Learn more about GitHub webhooks](https://developer.github.com/webhooks/)