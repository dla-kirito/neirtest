April 28, 2020 

You can now filter the package search results for an account by type and visibility. You can also sort by the number of downloads.

![image](https://i0.wp.com/user-images.githubusercontent.com/20052233/80499909-88d5a500-893b-11ea-8de0-a70380911ed0.png?ssl=1)