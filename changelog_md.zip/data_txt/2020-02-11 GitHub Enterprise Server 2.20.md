February 11, 2020 

The 2.20.0 release of GitHub Enterprise Server is now [available for download](https://enterprise.github.com/releases/2.20.0/download). The latest release includes additional security features, a new internal visibility option, and more.

[See the full release notes](https://enterprise.github.com/releases/2.20.0/notes)