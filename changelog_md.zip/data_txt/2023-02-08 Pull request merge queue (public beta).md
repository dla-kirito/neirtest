February 8, 2023 

Today we are announcing the public beta of pull request merge queue for repos on GitHub Enterprise Cloud and open source organizations! 🎉

Merge queue helps increase velocity in software delivery by automating pull request merges into your busiest branches.

![Pull request merge queue](https://i0.wp.com/user-images.githubusercontent.com/2503052/217027654-f570fb25-092d-476e-b6f5-0b31b8514662.png?ssl=1)

Before merge queue, developers were often required to update their pull request branches prior to merging to ensure their changes wouldn't break the main branch when merged. Each update resulted in a fresh round of continuous integration (CI) checks that would have to finish before the developer could attempt to merge. If another pull request got merged, every developer would have to go through the process again.

Merge queue automates this process by ensuring each pull request queued for merging is built with the pull requests ahead of it in the queue.

## Queueing a pull request to merge[](#queueing-a-pull-request-to-merge)

If your pull request targets a branch that uses merge queue, instead of merging your pull request directly when it meets the requirements to merge, you will add it to the queue by clicking **Merge when ready** from the pull request page or from GitHub Mobile.

![Queue to merge](https://i0.wp.com/user-images.githubusercontent.com/2503052/217023882-cf4bf568-af5d-469e-882a-14f1837add72.gif?ssl=1)

The queue then creates a temporary branch that contains the latest changes from the base branch, the changes from other pull requests already in the queue, and the changes from your pull request. CI then starts, with the expectation that all required status checks must pass before the branch (and the pull requests it represents) are merged.

If a queued pull request has merge conflicts or fails any required status check, it is automatically removed from the queue when it reaches the front, and a notification is sent. Once the problem is resolved, it can be added back to the queue.

Learn more about [merging a pull request with merge queue](https://docs.github.com/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/merging-a-pull-request-with-a-merge-queue) from the pull request page. You can also queue your pull request on the go using the beta version of GitHub Mobile from [iOS TestFlight](https://testflight.apple.com/join/NLskzwi5) or [Google Play (Beta)](https://play.google.com/apps/testing/com.github.android)!

## Viewing the queue[](#viewing-the-queue)

Always know where you are in the queue.

The queue details page, which can be accessed from the Branches page or pull request page, shows the pull requests in the queue and status for each, including the required status checks and estimated time to merge. It also shows how many pull requests have been merged and the trend over the last 30 days.

![Merge queue details page](https://i0.wp.com/user-images.githubusercontent.com/2503052/217023511-13c729f7-7458-4ee3-8f7c-be5a7cf06f99.png?ssl=1)

Depending on your permissions, you can also remove a pull request from the queue or clear the queue from this page.

## Getting started[](#getting-started)

Merge queue can help improve overall velocity and avoid manual branch updates that impact developer productivity. Learn more about how to [enable merge queue](https://docs.github.com/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue) on your busiest branches.

We want to hear from you on how we can improve merge queue! Join the conversation in the [merge queue public beta discussion](https://github.com/community/community/discussions/46757).