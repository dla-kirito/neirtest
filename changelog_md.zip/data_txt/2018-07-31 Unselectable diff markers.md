July 31, 2018 

The `+` and `-` diff markers are no longer copied to your clipboard when you copy the contents of a diff.