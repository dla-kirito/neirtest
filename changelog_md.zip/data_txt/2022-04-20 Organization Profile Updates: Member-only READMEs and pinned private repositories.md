April 20, 2022 

![tortenfabrik-relaode_final!-Apple ProRes 422 HQ 2022-04-20 17_18_03](https://i0.wp.com/user-images.githubusercontent.com/3369400/164266350-b13f8ab0-6586-4ac3-986f-a44c80a54ce5.gif?ssl=1)

Now you can customize your organization's Overview page to show content dedicated to public users or members of the organization. A new member view is only visible to members of the organization and can be controlled in the sidebar to toggle between public and member view.

## A README only visible to members[](#a-readme-only-visible-to-members)

Similar to the [public organization README](https://github.blog/changelog/2021-09-14-readmes-for-organization-profiles/) that we released last year, you can now create a README that is only visible to members of your organization. In the `.github-private` repository the `/profile/README.md` will be displayed on your organization's Overview page.

## Pinned private repositories[](#pinned-private-repositories)

Organization owners are able to define a set of six public, private or internal repositories that are only visible to members of their organization, enabling members to quickly access popular or frequented repositories.

For more information about the new features, see ["Customizing your organization's profile"](https://docs.github.com/en/organizations/collaborating-with-groups-in-organizations/customizing-your-organizations-profile).