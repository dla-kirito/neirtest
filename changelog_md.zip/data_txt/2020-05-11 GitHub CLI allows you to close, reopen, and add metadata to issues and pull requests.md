May 11, 2020 

[GitHub CLI 0.8](https://github.com/cli/cli/releases/tag/v0.8.0) makes working with pull requests and issues from your terminal even simpler. This release includes two primary features:

* You no longer need to open your issue or pull request in the browser immediately after creating it just to add metadata. Now you can add reviewers, labels, assignees, projects, and milestones (as applicable) when creating pull requests and issues.
* Close and reopen pull requests and issues right from the CLI with `gh pr close`, `gh pr reopen`, `gh issue close`, and `gh issue reopen`.

See how to upgrade in our [README](https://github.com/cli/cli#installation)!

[Learn more about GitHub CLI](https://cli.github.com)