January 14, 2022 

GitHub is updating the retention policy as it pertains to Checks data. Checks created by GitHub Actions and third-party GitHub Apps will be affected by the new retention policy.

Starting on February 14th, 2022 GitHub will begin archiving detailed checks data older than 400 days. As part of the archiving process we will create a rollup commit status representing the state of all checks for that commit. As a consequence, the merge box in any pull request with archived required checks will be in a blocked state and checks will need to be rerun in order to merge it.

[Learn more about checks](https://docs.github.com/en/rest/guides/getting-started-with-the-checks-api)