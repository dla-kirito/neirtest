December 15, 2020 

GitHub Enterprise Cloud administrators may now download and view current GitHub compliance reports from the `Security` settings tab of their enterprise account: `https://github.com/enterprises/"your-enterprise"/settings/security`. 

Enterprise plan organization owners may also view the reports from the `Organization security` settings tab of their organization: `https://github.com/organizations/"your-org"/settings/security`.

The artifacts available are SOC 1 and SOC 2 Type 2 reports, and a Cloud Security Alliance CAIQ self-assessment.