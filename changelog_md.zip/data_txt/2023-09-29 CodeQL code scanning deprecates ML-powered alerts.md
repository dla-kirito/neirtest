September 29, 2023 

In February 2022, we [introduced experimental CodeQL queries](https://github.blog/2022-02-17-code-scanning-finds-vulnerabilities-using-machine-learning/) that utilize machine learning to identify more potential vulnerabilities. This feature was only available for JavaScript / TypeScript code and was available to code scanning users that enabled the optional `security-extended` or `security-and-quality` [query suites](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/customizing-code-scanning#using-queries-in-ql-packs).

We disabled this experimental feature for new code scanning users in June 2023\. Today, we're sunsetting it for all users.

Any currently open code scanning alerts from these queries (Rule ID starts with `js/ml-powered/`) will be closed. Closed alerts will still be visible in [the code scanning alerts view](https://docs.github.com/en/code-security/code-scanning/managing-code-scanning-alerts/managing-code-scanning-alerts-for-your-repository#) in your repository’s Security tab. The complete history of each alert will remain accessible by clicking on the alert.

CodeQL will continue to run the existing non-ML versions of these queries and provide you with highly precise and actionable alerts.

We’ve learned a lot from the feedback and experience of the repositories that participated in this experiment, and we’ve since ramped up our investment in AI-powered security technology. This new technology [is already boosting our ability to cover more sources and sinks of untrusted data](https://github.blog/2023-09-12-codeql-team-uses-ai-to-power-vulnerability-detection-in-code/) in order to significantly increase the coverage and depth of all queries.