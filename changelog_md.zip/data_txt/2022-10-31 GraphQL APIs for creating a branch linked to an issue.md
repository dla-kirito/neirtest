October 31, 2022 

We've added GraphQL API support for creating a branch linked to an issue. [Learn more about creating a branch for an issue in the UI in the documentation.](https://docs.github.com/en/issues/tracking-your-work-with-issues/creating-a-branch-for-an-issue)

The GraphQL API supports:

* [Creating a branch linked to an issue](https://docs.github.com/en/graphql/reference/mutations#createlinkedbranch)
* [Removing the link between a branch and an issue](https://docs.github.com/en/graphql/reference/mutations#deletelinkedbranch)
* A `linkedBranches` field on the [Issue Object](https://docs.github.com/en/graphql/reference/objects#issue)