November 3, 2023 

GitHub.com now remembers multiple accounts in your browser. You can find the account switcher in your profile picture context menu, letting you more easily switch between user accounts without re-entering your credentials.

![image](https://github.com/github/release-assets/assets/1666363/bd646682-187d-42e5-96c2-1ddfdc76f240)

The account switcher helps developers alternate between Enterprise Managed User accounts provided by an employer and personal accounts for use with personal projects and open source contributions. It also helps administrators manage service accounts they use for automation and integration purposes.

Because these accounts often have significantly different privileges, there's never any mixing of user permissions between saved accounts. When you visit a page that your current account can't access, you'll see a prompt to switch accounts if you have more than one signed in.

When you switch accounts, you won't need to sign in again or perform 2FA unless the account session has expired. Session expiration occurs after two weeks without activity. SAML/OIDC SSO authorization is also saved for sessions, but often expires every 1 or 24 hours, and may need to be done again before you can access your organization resources.

To learn more, see "[Switching between accounts](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/switching-between-accounts)".