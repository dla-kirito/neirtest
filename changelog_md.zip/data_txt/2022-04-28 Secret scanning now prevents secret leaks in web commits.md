April 28, 2022 

Organizations with GitHub Advanced Security can now prevent secrets leaked in code committed via the command line _and_ the GitHub web editor with secret scanning’s push protection feature.

For repositories with push protection enabled, GitHub will block any pushes where a high-confidence token is detected in a commit made via the web editor. Developers can bypass the block by providing details of why the secret needs to be committed via the UI.

Push protection scans for tokens that can be detected with a very low false positive rate. If you run a service that issues tokens we’d love to work with you to make them highly identifiable and include them in push protection. We changed the [format of GitHub’s own personal access tokens](https://github.blog/2021-04-05-behind-githubs-new-authentication-token-formats/) last year with this in mind.

For more information:

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Learn more about protecting secrets on push](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)
* [Read our blog post about secret scanning push protection](https://github.blog/2022-04-04-push-protection-github-advanced-security/)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)