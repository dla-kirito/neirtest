November 20, 2023 

Shortly after releasing Copilot content exclusions on November 8, 2023, our team observed that the feature was causing clients to be incorrectly blocked from using Copilot. This necessitated an immediate rollback of this feature.

**What Happened?**  
Once the feature was enabled for all Copilot Business customers, we observed a spike in errors and some end-users being completely blocked from using Copilot. The problem was related to the way content exclusions policies are fetched from the client.

**Current Actions and Next Steps:**  
Our engineering team is engaged in deploying the necessary fixes. We have identified the faulty code in the client and are also deploying more verifications both server and client side to ensure this does not happen again. However, we want to approach the reintroduction of this feature with caution. Customers who had previously setup a content exclusions configuration are not affected by the rollback.

**We expect to re-deploy the feature within the next few weeks.**

Join the discussion within [GitHub Community](https://github.com/orgs/community/discussions/categories/announcements).