October 16, 2018 

Our latest Enterprise 2.15 release unifies the GitHub experience across deployment types and brings the open source community to developers at work. This Enterprise release introduces GitHub Connect—a new way for development teams to work across your organization’s Enterprise and Business Cloud accounts. It also includes security enhancements, such as automatically protected branches and S/MIME Git signing.

The 2.15.0 release for GitHub Enterprise is now [available for download](https://enterprise.github.com/releases/2.15.0/download).

[Learn more from the full release notes](https://enterprise.github.com/releases/2.15.0/notes)