February 21, 2020 

Starting March 3rd, 2020, the Ubuntu virtual environments will no longer start the MySQL service automatically. If you are using MySQL, this may be a breaking change for your workflows. To keep using MySQL, you'll need to start the service as part of your job:

```yaml
- run: |
    sudo /etc/init.d/mysql start
```

For the latest updates, be sure to subscribe to the announcement in the [actions/virtual-environments](https://github.com/actions/virtual-environments/issues/375) repository.