October 12, 2021 

You can now choose to use a fixed-width font in Markdown-enabled fields, like issue comments and pull request descriptions. Currently these fields use a variable-width font, which can make it difficult to edit advanced Markdown structures like tables and code snippets.

To enable, go to [your appearance settings](https://github.com/settings/appearance) and toggle on **Use a fixed-width (monospace) font when editing Markdown** in the “Markdown editor font preference” section.

![fixed-width-font](https://i0.wp.com/user-images.githubusercontent.com/2503052/137012608-bb2653bd-5870-47b7-9db6-0cb05969507a.gif?ssl=1)

Learn more about [writing and formatting on GitHub](https://docs.github.com/github/writing-on-github/getting-started-with-writing-and-formatting-on-github/about-writing-and-formatting-on-github).