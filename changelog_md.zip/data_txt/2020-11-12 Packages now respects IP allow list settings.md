November 12, 2020 

If your organization uses [IP allow lists](https://docs.github.com/en/free-pro-team@latest/github/setting-up-and-managing-organizations-and-teams/managing-allowed-ip-addresses-for-your-organization) to restrict access, GitHub Packages now respects those settings.