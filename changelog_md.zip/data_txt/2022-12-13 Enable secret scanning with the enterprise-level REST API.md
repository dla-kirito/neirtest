December 13, 2022 

Enterprises with GitHub Advanced Security can now enable secret scanning and push protection on all their organizations using a single call to an [enterprise-level REST API endpoint](https://docs.github.com/en/rest/enterprise-admin/code-security-and-analysis?apiVersion=2022-11-28).

You can also use the enterprise API to set a default custom link that will appear on a push protection block.

This new endpoint supplements the existing [enterprise enablement settings in the UI](https://github.blog/changelog/2022-10-06-enable-secret-scanning-for-an-enterprise-with-one-click/) and the [repository-level](https://docs.github.com/en/enterprise-cloud@latest/rest/repos/repos?apiVersion=2022-11-28#update-a-repository--parameters) and [organization-level](https://docs.github.com/en/enterprise-cloud@latest/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization) REST API enablement endpoints.

* Learn more about [managing GitHub Advanced Security features for your enterprise](https://docs.github.com/en/enterprise-cloud@latest/admin/code-security/managing-github-advanced-security-for-your-enterprise/managing-github-advanced-security-features-for-your-enterprise)
* Learn more about [securing private repositories with secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning)