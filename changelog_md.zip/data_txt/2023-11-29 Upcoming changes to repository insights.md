November 29, 2023 

Beginning January 8th, 2024, we will be making changes to the repository insights UI and API on GitHub for repositories with over 10,000 commits. The targeted UI and API have very low usage and rely on a legacy service we’re moving away from.

## User Interface Updates[](#user-interface-updates)

We are removing the following data:

1. Under Insights > Contributors, we are removing addition/deletion counts for repositories with over 10,000 commits, as well as the dropdown that shows the graphs associated with additions and deletions. All the commit counts and commit count graphs will remain unchanged.

| Current page                                                                                                                 | Repos with over 10,000 commits after the change is made                                                                                                                                   |
| ---------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ![The current Insights > Contributors tab](https://github.com/curl/curl/assets/3157267/5b43d432-f843-4a2e-8080-1a97bc51e49c) | ![The new tab which shows no dropdown for additions and deletions, and no addition and deletion counts](https://github.com/curl/curl/assets/3157267/91866079-e47e-4bb7-a0c0-8bdb3f852614) |

1. Under Insights > Code Frequency, we will only show data for repos with under 10k commits.

| Current page                                                                                                                                                                            | Repos with over 10,000 commits after the change is made                                                                                                             |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ![The current Insights > Code Frequency tab which shows a graph of additions and deletions over time](https://github.com/curl/curl/assets/3157267/915c6e32-d535-4a10-828b-a904ddda8131) | ![The new tab which shows that there are too many commits to generate this graph](https://github.com/curl/curl/assets/3157267/f20af741-fceb-4815-adcb-93f901814cb7) |

## REST API Modifications[](#rest-api-modifications)

Alongside the UI changes, the following API changes will be implemented:

1. The REST API responses for repositories with 10,000+ commits will report `0` values for the addition and deletion counts to improve performance. This impacts the `/repos/{owner}/{repo}/stats/contributors` endpoint to [get all contributor commit activity](https://docs.github.com/en/rest/metrics/statistics?apiVersion=2022-11-28#get-all-contributor-commit-activity)
2. The `/repos/{owner}/{repo}/stats/code_frequency` [API endpoint](https://docs.github.com/en/rest/metrics/statistics?apiVersion=2022-11-28#get-the-weekly-commit-activity) will return a 422 status code for repos with 10,000 or more commits.  
   * This is different from the previous two because this endpoint _only_ returns additions/deletions, which we will no longer return for repos with over 10k commits. The previous two endpoints also return the total number of commits, which we will continue to generate.

For users who continue to need detailed addition and deletion statistics for large-scale repositories, we suggest using the following Git command, as described in the [Git documentation](https://git-scm.com/docs/git-log):

`git log --pretty="format:%m%ad----%ae%n%-(trailers:only,unfold)" --date=raw --shortstat --no-renames --no-merges`