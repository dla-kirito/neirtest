October 5, 2021 

As [previously announced](https://github.blog/2021-08-23-npm-registry-deprecating-tls-1-0-tls-1-1/), the npm registry now requires TLS 1.2 or higher for all requests, including package installation.