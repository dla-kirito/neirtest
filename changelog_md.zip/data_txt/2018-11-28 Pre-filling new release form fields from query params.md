November 28, 2018 

You can now pre-fill values in the new Release form fields using URL query parameters, making it a little easier to automate [creating a new release](https://help.github.com/articles/creating-releases/).

[Learn more about using releases to package your software for others to use](https://help.github.com/articles/about-releases/)