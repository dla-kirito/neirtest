October 18, 2022 

OpenID Connect (OIDC) support in GitHub Actions enables secure cloud deployments using short-lived tokens that are automatically rotated for each deployment.

You can now use the enhanced OIDC support to [configure the subject claim format](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect#customizing-the-subject-claims-for-an-organization-or-repository) within the OIDC tokens, by defining a customization template at either org or repo levels. Once the configuration is completed, the new OIDC tokens generated during each deployment will follow the custom format.

This enables organization & repository admins to standardize OIDC configuration across their cloud deployment workflows that suits their compliance & security needs.

Learn more about [Security hardening your GitHub Workflows using OpenID Connect](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments).