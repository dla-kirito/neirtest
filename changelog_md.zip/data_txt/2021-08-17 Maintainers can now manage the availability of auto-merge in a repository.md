August 17, 2021 

Maintainers can now manage the repository-level "_Allow auto-merge_" setting. This setting, which is off by default, controls whether auto-merge is available on pull requests in the repository. Previously, only admins could manage this setting.

Additionally, this setting can now by controlled using the "[Create a repository](https://docs.github.com/en/rest/reference/repos#create-an-organization-repository)" and "[Update a repository](https://docs.github.com/en/rest/reference/repos#update-a-repository)" REST APIs.

Learn more about [managing auto-merge for pull requests in your repository](https://docs.github.com/github/administering-a-repository/configuring-pull-request-merges/managing-auto-merge-for-pull-requests-in-your-repository).