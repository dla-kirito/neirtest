October 31, 2023 

GitHub is introducing GPU hosted runners for GitHub Actions to provide teams working with ML models to have a single platform to build, test and deploy from.

## GPU accelerated Builds[](#gpu-accelerated-builds)

GitHub enables teams working with GPU accelerated ML models as part of their applications to fully adopt Actions as their DevOps platform to test and deploy their services. These new runners empower teams working with models such as large language models (LLMs) to run these more efficiently as part of their CI/CD process, empowering teams to do complete application testing, including the ML components, in Actions.

We know that developers and data scientists love GitHub Actions. Data scientists are moving away from ‘working in isolation’ towards a model of ML Ops and trying to understand how this feeds into the wider DevOps practices of their teams.

These runners will be entering private beta in November.

**Interested?**

Click [here](https://resources.github.com/devops/accelerate-your-cicd-with-arm-and-gpu-runners-in-github-actions/) to join the waitlist for the private beta.