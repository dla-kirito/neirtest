March 4, 2022 

GitHub Advanced Security customers can now scan their public repositories using Advanced Security secret scanning. Like scanning on private repositories, scanning on public repositories can be enabled at the repository, organization, and enterprise levels. Results can be viewed at each level in both the UI and API.

In addition, GitHub continues to scan all public repositories for secrets issued by our [secret scanning partners](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/secret-scanning-patterns#supported-secrets-for-partner-patterns) and to send any detections to the relevant partners. Secret detections that overlap between partner patterns and Advanced Security patterns will be sent to the partner and appear in the secret scanning UI.

[Learn more about secret scanning for GitHub Advanced Security](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning#about-secret-scanning-for-advanced-security)