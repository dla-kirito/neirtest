June 22, 2020 

GitHub for mobile 1.2 adds more details to diffs, renders markdown files, and lets you mark files as viewed as you’re reviewing them.

The top features include:

* Improved pull request review experience, with support for marking files as viewed, collapsing files, deleted files, and more
* Markdown, image, and PDF files now render if you click on them while browsing code
* Typing new comments is now smoother than ever, with no jumping or flickering
* Labels, user statuses, and commit messages that used emoji shortcodes now properly render emojis
* Organization badges on user profiles link to the mentioned organization
* You can view multiple author avatars for commits on pull request timelines
* New fork badge on repository profile that links to the parent repository
* New “Metaphorical Technology” custom app icon!
* New support for iPad pointer effects
* Fixed an iPad bug where keyboard dismisses while typing a review
* Fixed voice-over bugs in the inbox filter view

[Learn more about GitHub for mobile](https://github.com/mobile)