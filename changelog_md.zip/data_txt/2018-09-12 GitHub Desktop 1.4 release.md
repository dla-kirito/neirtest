September 12, 2018 

The release of GitHub Desktop 1.4 includes two important improvements:

* You’ll now know before you click “Merge” whether you’re going to encounter merge conflicts between the branches you’re merging.
* You’ll also be able to see what’s new in each release inside the app without having to go to the GitHub Desktop website.

[View the full release notes](https://desktop.github.com/release-notes/)