September 30, 2021 

GitHub Enterprise Cloud's Services Continuity and Incident Management Plan is now available for self-service alongside additional resources under the Compliance tab. Enterprise owners may download and view current GitHub compliance reports from the `Compliance` tab of their enterprise account: `https://github.com/enterprises/"your-enterprise"/settings/compliance`. 

Enterprise plan organization owners may view the reports from the `Organization security` settings tab of their organization: `https://github.com/organizations/"your-org"/settings/security`.