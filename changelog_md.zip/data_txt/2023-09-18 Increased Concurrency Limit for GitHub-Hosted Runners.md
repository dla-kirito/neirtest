September 18, 2023 

GitHub-hosted runners now support up to 1000 concurrent jobs for our 4 – 64 vCPU runners, enhancing their capability to handle large-scale CI/CD workloads.

Our runners are designed to automatically scale to meet your needs. The concurrency limit feature allows users to specify the maximum number of jobs that can run simultaneously to execute Actions workflows. Previously capped at 250, we've made backend improvements to now support a maximum of 1000 concurrent jobs for runners within the 4-64 vCPU range for Windows and Linux operating systems.

Enterprise or organization administrators can set this concurrency limit under the [Auto-scaling setting](https://docs.github.com/en/actions/using-github-hosted-runners/managing-larger-runners#configuring-autoscaling-for-larger-runners). GitHub-hosted runners with 4 or more vCPUs are available on both the GitHub Team and Enterprise plans. 

![](https://i0.wp.com/user-images.githubusercontent.com/2180038/268706590-ac49f3c1-b54f-45cc-a313-45c55254a63d.png)

 If you have any feedback to help improve this experience, be sure to post it on our [GitHub Community Discussion](https://github.com/orgs/community/discussions/58739).