June 24, 2019 

Organizations on Team and GitHub Enterprise Cloud plans can now choose to display their member’s profile names in comments on private repositories.

[Learn more about managing the display of member names in your organization on GitHub](https://help.github.com/en/articles/managing-the-display-of-member-names-in-your-organization)