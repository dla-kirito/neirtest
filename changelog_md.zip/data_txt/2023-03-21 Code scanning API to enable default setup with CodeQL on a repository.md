March 21, 2023 

Code scanning have shipped an API for repositories to programmatically enable [code scanning default setup with CodeQL](https://docs.github.com/en/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/configuring-code-scanning-for-a-repository#configuring-code-scanning-automatically).

The API can be used to: 

* Onboard a repository to default setup: `gh api -X PATCH /repos/[org-name]/[repo-name]/code-scanning/default-setup -f state=configured`
* Specify which CodeQL query suite to use in the default setup configuration: `gh api -X PATCH /repos/[org-name]/[repo-name]/code-scanning/default-setup -f query_suite=extended`
* View the current default setup configuration for a repository: `gh api /repos/[org]/[repo-name]/code-scanning/default-setup`
* Offboard a repository from default setup: `gh api -X PATCH /repos/[org-name]/[repo-name]/code-scanning/default-setup -f state=not-configured`

When you onboard a repository via the API, you will recieve a workflow run ID which can be used to monitor the setup progress. This can be used to see the status and conclusion of the run: `gh api repos/[org-name]/[repo-name]/actions/runs/[run-id] --jq '.status, .conclusion'`

```
{
  "state": "configured",
  "languages": ["javascript", "ruby"],
  "query_suite": "default", 
  "updated_at": "2023-02-24T20:00:42Z"
}
```

For more information, see ["Get the code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning#get-a-code-scanning-default-setup-configuration) and ["Update the code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning#update-a-code-scanning-default-setup-configuration).