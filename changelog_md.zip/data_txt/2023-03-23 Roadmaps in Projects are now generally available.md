March 23, 2023 

Today we are announcing the general availability (GA) of roadmaps in GitHub Projects! 🎉

## 🗺 Roadmaps for all[](#world%5Fmap-roadmaps-for-all)

Since we announced the [public beta of roadmaps](https://github.blog/changelog/2023-01-31-roadmap-in-projects-public-beta/) earlier this year, we've shipped exciting updates that allow you to quickly adjust your roadmaps and visualize and track work with important milestones and dates, alongside lots of bug fixes and improvements. Thank you to everyone who participated in the beta for all of the feedback! 💖

To get started with a roadmap, select the roadmap layout when creating a new project, or create a new roadmap in an existing project by selecting "Roadmap" in the view options menu.

<//user-images.githubusercontent.com/101840513/227036955-dd7dbc03-efc4-41ed-8c53-0a1f649d47a9.mp4>

### 📍 Track important dates with roadmap markers[](#round%5Fpushpin-track-important-dates-with-roadmap-markers)

If you are using milestones to track progress for larger bodies of work, `iteration` fields to plan out your weeks and months, or `date` fields for important deadlines, roadmap markers help you and your team keep track of important upcoming dates. Configure these from the `Markers` menu to make sure all of your important dates are visible on your roadmap.  
![Roadmap with markers](https://i0.wp.com/user-images.githubusercontent.com/101840513/227029097-2e8c9645-0f20-489e-a196-53da25a93c14.jpg?w=1432&ssl=1)

### ⚡ Quickly adjust roadmap items[](#zap-quickly-adjust-roadmap-items)

Plans often change, and so can your roadmaps! Quickly make edits to your roadmap items by dragging and dropping them to a different date or iteration, or moving them to another status or team.

<//user-images.githubusercontent.com/101840513/227029260-670ee402-5f0c-48e4-8e37-10d8f81cc320.mp4>

### ✨ Other enhancements[](#sparkles-other-enhancements)

* Create a roadmap from the `Select a template` dialog when creating a new project
* Edit item titles directly from the table
* Use arrow keys for navigating table items
* Use the floating `+ Add items` bar when there is no 'Group' field selected
* Resize the table using keyboard navigation

### ✍ Tell us what you think![](#writing%5Fhand-tell-us-what-you-think)

We want to hear from you! Be sure to drop a note in the [discussion](https://github.com/orgs/community/discussions/39766) and let us know how we can improve. Check out the [documentation](https://docs.github.com/en/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/customizing-the-roadmap-layout) for more details.

## ✨ Bug fixes and improvements[](#sparkles-bug-fixes-and-improvements)

* Enabled vertical scrolling in the Workflows page
* Fixed a bug where the `New column` menu was appearing again when adding a new board column
* Fixed a bug where the `Add selected items` button was out of view in the bulk-add pane
* Updated the `github-project-automation` link in the issue timeline to redirect to [Automating your project documentation](https://docs.github.com/en/issues/planning-and-tracking-with-projects/automating-your-project)
* Moved reactions on issues and pull requests to the bottom left of the comment box, making it easier to respond after reading and creating consistency with discussions
* (Tasklists Private Beta) "Convert to Issue" is now more discoverable on the tasklist item versus in the three-dot menu
* (Tasklists Private Beta) Fixed a bug where some repository names were getting cut off

See how to use GitHub for project planning with [GitHub Issues](http://github.com/features/issues), check out what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/issues).