March 15, 2022 

GitHub changed which keys are supported in SSH and removed the unencrypted Git protocol.  
You can read more about the motivation behind these changes in our [blog post](https://github.blog/2021-09-01-improving-git-protocol-security-github/) from last September.  
As a reminder, these changes were:

* Removed all support for DSA keys
* Required SHA-2 signatures on all RSA keys uploaded after November 2, 2021 (RSA keys uploaded prior to the cutoff may still use SHA-1 signatures)
* Removed legacy SSH algorithms HMAC-SHA-1 and CBC ciphers
* Permanently disabled the unencrypted Git protocol