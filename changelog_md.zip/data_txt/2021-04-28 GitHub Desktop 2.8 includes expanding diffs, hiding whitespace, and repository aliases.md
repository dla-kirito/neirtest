April 28, 2021 

GitHub Desktop 2.8 now allows you to:

* Expand diffs to view more context around the changes
* Hide whitespace in diffs to view substantive changes more easily
* Create aliases for repositories in Desktop to differentiate between them more easily

Learn more about each of these new features and see them in action in today's [blog post](https://github.blog/2021-04-28-github-desktop-hiding-whitespace-expanding-diffs-repo-aliases/).