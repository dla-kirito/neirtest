January 19, 2023 

GitHub, the [Rust Foundation](https://foundation.rust-lang.org/), and the [Rust Project](https://rust-lang.org) are collaborating to help protect you from leaked [crates.io](https://crates.io/) keys.

From today, GitHub will scan every commit to a public repository for exposed crates.io keys. We will forward any tokens we find to crates.io, who will automatically disable the tokens and notify their owners. The end-to-end process takes only a few seconds.

Crates.io is the latest GitHub secret scanning integrator; since 2018, GitHub has partnered with over 100 token issuers to help keep our mutual customers safe. We continue to welcome new partners for public repository secret scanning. In addition, GitHub Advanced Security customers can scan their private repositories for leaked secrets.

We’d like to thank the [crates.io](https://crates.io/) team, the staff at the Rust Foundation, and the work from AWS’ Dan Gardner on this [GitHub pull request](https://github.com/rust-lang/crates.io/pull/5495) that made our collaboration with Rust possible.

[Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)  
[Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)