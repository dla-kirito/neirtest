June 30, 2021 

GitHub Sponsors now lets makers write welcome messages that are automatically sent to new sponsors at specific tiers.

![Filling out a welcome message for a new tier](https://i0.wp.com/user-images.githubusercontent.com/964912/124037462-77ab7c80-d9b4-11eb-84f8-04db1c31076b.gif?ssl=1)