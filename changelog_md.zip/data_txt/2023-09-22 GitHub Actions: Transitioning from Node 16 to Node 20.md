September 22, 2023 

Node 16 has reached its [end of life](https://github.com/nodejs/Release/#end-of-life-releases), prompting us to initiate its deprecation process for GitHub Actions. Our plan is to transition all actions to run on Node 20 by Spring 2024\. We will actively monitor the migration's progress and gather community feedback before finalizing the transition date. Starting October 23rd, workflows containing actions running on Node 16 will display a warning to alert users about the upcoming migration.

## What you need to do[](#what-you-need-to-do)

### For Actions maintainers[](#for-actions-maintainers)

Modify your actions to run on Node 20 instead of Node 16\. For guidance, refer to the [Actions configuration settings](https://docs.github.com/en/actions/creating-actions/metadata-syntax-for-github-actions#runs-for-javascript-actions).

### For Actions users[](#for-actions-users)

Ensure your workflows use the latest versions of actions that are running on Node 20\. For more information, see [Using Versions for Actions](https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#example-using-versioned-actions).

### For self-hosted runner administrators:[](#for-self-hosted-runner-administrators)

Update your self-hosted runners to runner version [v2.308.0](https://github.com/actions/runner/releases/tag/v2.308.0) or later to ensure compatibility with Node 20 actions.