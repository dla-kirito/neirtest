November 4, 2022 

GitHub Advanced Security customers using secret scanning can now specify a custom link via the [organization level REST API](https://docs.github.com/en/rest/orgs/orgs#update-an-organization) that will show in the message when push protection detects and blocks a potential secret. Admins can use the custom link to point their developers to company-specific guidance on secrets.

Previously, admins could only set a custom link [through the UI](https://github.blog/changelog/2022-08-24-secret-scanning-admins-can-now-provide-a-link-to-display-when-a-push-is-blocked/).

* Learn more about [secret scanning for GitHub Advanced Security](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/about-secret-scanning#about-secret-scanning-for-advanced-security)
* Learn more about [protecting pushes with secret scanning](https://docs.github.com/en/enterprise-cloud@latest/code-security/secret-scanning/protecting-pushes-with-secret-scanning)