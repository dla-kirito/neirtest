June 30, 2023 

Auto-scaling self-hosted runners using the Actions runner controller and [runner scale sets](https://github.com/actions/actions-runner-controller/releases/tag/gha-runner-scale-set-0.4.0) is now in generally avaliable.

[Learn more about scalling self hosted runners](https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners-with-actions-runner-controller/quickstart-for-actions-runner-controller) and share your feedback with us in the [Community Discussion](https://github.com/orgs/community/discussions/59735)!