October 30, 2023 

Arm-based hosted runners are coming to GitHub Actions!

## Unlock the power of Arm in Actions[](#unlock-the-power-of-arm-in-actions)

By leveraging the power and efficiency of the Arm® architecture, GitHub is offering a new solution that will accelerate software development in GitHub. These new capabilities empower GitHub users to shift-left software development on the Arm architecture across the embedded edge, IoT and cloud infrastructure while providing significant power, performance and sustainability improvements to all users. Developers can now take advantage of Arm hardware hosted by GitHub to build and deploy their release assets anywhere Arm’s architecture is used.

Seamlessly integrated into GitHub Actions, these runners are powered by Arm-based Ampere® Altra® processors. Preloaded with a base image that contains a foundational set of development tools to build upon, these runners are extremely versatile and can handle any embedded software project from key markets such as automotive, IoT and industrial. The benefits do not stop at the embedded edge, as non-embedded, cloud native and everything in between will benefit by reducing their carbon footprint and getting more done within existing budgets.

These runners will be entering private beta in January 2024.

“With Arm-based GitHub-hosted runners, software developers can move faster while taking full advantage of the efficient Arm architecture, from cloud to edge,” said Bhumik Patel, director of software ecosystem development, Infrastructure Line of Business, Arm. “Our partnership with GitHub allows developers to optimize their Arm-based software development workflows and leverage GitHub’s ubiquitous deployment capability to more efficiently deliver code wherever they deploy – all while reducing costs and time to market.”

**Interested?**  
Click [here](https://resources.github.com/devops/accelerate-your-cicd-with-arm-and-gpu-runners-in-github-actions/) to join the waitlist for the private beta.