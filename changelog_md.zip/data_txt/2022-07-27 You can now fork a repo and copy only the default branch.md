July 27, 2022 

Previously, when creating a fork all branches from the parent repository were copied to the new fork repository. There are several scenarios where this is unneeded, such as contributing to open-source projects. When all branches are copied, it could result in slow repo cloning and unnecessary disk usage. With this new feature, only the default branch is copied; no other branches or tags. This may result in faster clones because only reachable objects will be pulled down.

![New fork page with ability to copy only the default branch](https://i0.wp.com/user-images.githubusercontent.com/90000203/178603603-f8006ac9-c6e1-431d-a458-f4f9b8cf529f.png?ssl=1)

If you want to copy additional branches from the parent repository, you can do so from the **Branches** page.

[Read more about copying additional branches](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-and-deleting-branches-within-your-repository).

[Read more about branches](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-branches).

[Read more about working with forks](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/working-with-forks/about-forks).