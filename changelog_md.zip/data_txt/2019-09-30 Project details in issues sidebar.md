September 30, 2019 

Project board columns can now be changed directly from an issue sidebar. This means less context switching between an issue and a project. There are also updated issue sidebar visuals for projects which better delineates the details from multiple projects. In addition, issues that are moved to a column from the sidebar or via project board automation will now appear at the bottom of the board column (previously they appeared at the top of the column).

[Learn more about these project board improvements on GitHub](https://github.blog/2019-09-25-project-board-improvements/)