August 25, 2021 

A dark high contrast theme, with greater contrast between foreground and background elements, is now generally available to all github.com users. Navigate to the "Appearance" page in your [profile settings](https://github.com/settings/appearance) to choose the dark high contrast theme. This release also includes improvements to our color system across all GitHub themes. 

[Share feedback](https://github.community/c/github-help/dark-mode-beta/65)

![Animated image of switching between dark default theme and dark high contrast on the appearance settings page](https://i0.wp.com/user-images.githubusercontent.com/334891/123645834-ad096c00-d7f4-11eb-85c9-b2c92b00d70a.gif?ssl=1)