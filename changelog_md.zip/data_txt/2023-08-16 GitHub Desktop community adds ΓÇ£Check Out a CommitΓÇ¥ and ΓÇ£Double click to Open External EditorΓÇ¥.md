August 16, 2023 

In 3.2.8, GitHub Desktop is shipping two great community contributions of highly requested features — “Check Out a Commit” and “Double Click to Open in Your External Editor”.  
Alongside that, we have a nice addition to the clone dialog where you can quickly see if a repository has been archived, as well as many accessibility enhancements.

### Check Out a Commit[](#check-out-a-commit)

A big thanks to [@kitswas](https://github.com/kitswas) for his work in adding the ability to check out a commit from the history tab, a much asked for feature.

![Shows check out a tag commit with new context menu option](https://i0.wp.com/user-images.githubusercontent.com/2180038/261034257-0e9f860a-981f-45aa-835f-d4c258f642f0.gif?ssl=1)

### Double Click to Open in Your External Editor[](#double-click-to-open-in-your-external-editor)

We would also like to give a shout out to [@digitalmaster](https://github.com/digitalmaster) with another highly requested feature add of being able to double click on a file to open it in your external editor, whether that is in the history or changes view.

![Shows double clicking in the history view to open a file](https://i0.wp.com/user-images.githubusercontent.com/2180038/261034386-a86e7fb2-f427-410e-8406-dac344975dc8.gif?ssl=1)

### Quickly Identify Archived Repositories when Cloning[](#quickly-identify-archived-repositories-when-cloning)

Another great add with this release is being able to tell at a glance which repositories in your cloning dialog are archived and likely not suitable for cloning.

![Clone dialog with one repo having the Archive tag added](https://i0.wp.com/user-images.githubusercontent.com/75402236/261010271-501a06f2-0ff8-4d7d-b7aa-ec60a36779d8.png?ssl=1)

### Accessibility[](#accessibility)

GitHub Desktop is actively working to improve accessibility in support of [GitHub’s mission to be a home for all developers](https://accessibility.github.com/).

In so, we have the:  
 – addition of `aria-label` and `aria-expanded` attributes to the diff options button – [#17062](https://github.com/desktop/desktop/issues/17062)  
 – number of pull requests found after refreshing the list screen reader announced – [#17031](https://github.com/desktop/desktop/issues/17031)  
 – ability to open the context menu for the History view items via keyboard shortcuts – [#17035](https://github.com/desktop/desktop/issues/17035)  
 – ability to navigate the “Clone a Repository” dialog list by keyboard – [#16977](https://github.com/desktop/desktop/issues/16977)  
 – checkboxes in dialogs receiving initial keyboard focus in order not to skip content – [#17014](https://github.com/desktop/desktop/issues/17014)  
 – progress state of the pull, push, fetch button announced by screen readers – [#16985](https://github.com/desktop/desktop/issues/16985)  
 – inline errors being consistently announced by screen readers – [#16850](https://github.com/desktop/desktop/issues/16850)  
 – group title and position correctly announced by screen readers in repository and branch lists – [#16968](https://github.com/desktop/desktop/issues/16968)  
 – addition of an `aria-label` attribute to the “pull, push, fetch” dropdown button for screen reader users – [#16839](https://github.com/desktop/desktop/issues/16839)  
 – aria role of alert applied to dialog error banners so they are announced by screen readers – [#16809](https://github.com/desktop/desktop/issues/16809)  
 – file statuses in the history view improved to be keyboard and screen reader accessible – [#17192](https://github.com/desktop/desktop/issues/17192)  
 – ability to open the file list context menu via the keyboard – [#17143](https://github.com/desktop/desktop/issues/17143)  
 – announcing of dialog titles and descriptions on macOS Ventura – [#17148](https://github.com/desktop/desktop/issues/17148)  
 – announcing of the “Overwrite Stash”, “Discard Stash”, “Delete Tag”, and “Delete Branch” confirmation dialogs as alert dialogs – [#17197](https://github.com/desktop/desktop/issues/17197), [#17166](https://github.com/desktop/desktop/issues/17166), [#17210](https://github.com/desktop/desktop/issues/17210)  
 – improvements of contrast in text to links – [#17092](https://github.com/desktop/desktop/issues/17092)  
 – tab panels in the branch dropdown announced by screen readers – [#17172](https://github.com/desktop/desktop/issues/17172)  
 – stash restore button description associated to the button via an `aria-describedby` – [#17204](https://github.com/desktop/desktop/issues/17204)  
 – warnings in the rename branch dialog placed before the input for better discoverability – [#17164](https://github.com/desktop/desktop/issues/17164)  
 – errors and warnings in the “Create a New Repository” dialog are screen reader announced – [#16993](https://github.com/desktop/desktop/issues/16993)

### Other Great Fixes[](#other-great-fixes)

* The remote for partial clone/fetch is recognized. Thanks [@mkafrin](https://github.com/mkafrin)! – [#16284](https://github.com/desktop/desktop/issues/16284)
* Association of repositories using nonstandard usernames is fixed – [#17024](https://github.com/desktop/desktop/issues/17024)
* The “Preferences” are renamed to “Settings” on macOS to follow platform convention – [#16907](https://github.com/desktop/desktop/issues/16907)
* The addition of the Zed Preview as an external editor option – [#17097](https://github.com/desktop/desktop/issues/17097). Thanks [@filiptronicek](https://github.com/filiptronicek)
* The addition of the Pulsar code editor as an external editor option on Windows – [#17120](https://github.com/desktop/desktop/issues/17120). Thanks [@confused-Techie](https://github.com/confused-Techie)
* Fixing the detection of VSCodium Insider for Windows – [#17078](https://github.com/desktop/desktop/issues/17078). Thanks [@voidei](https://github.com/voidei)
* The \\”Restore\\” button in stashed changes is not disabled when uncommitted changes are present. – [#12994](https://github.com/desktop/desktop/issues/12994). Thanks [@samuelko123](https://github.com/samuelko123)

Automatic updates will roll out progressively, or you can [download the latest GitHub Desktop here.](https://desktop.github.com)