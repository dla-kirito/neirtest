July 31, 2023 

Organization owners and security managers can now view metrics associated with push protection usage across their organization. 

The overview shows a summary of how many pushes containing secrets have been successfully blocked across the organization by push protection, as well as how many times push protection was bypassed.

You can also find more granular metrics, including:

* the secret types that have been blocked or bypassed the most
* the repositories that have had the most pushes blocked
* the repositories that are bypassing push protection the most
* the percentage distribution of reasons that users give when they bypass the protection

These metrics are found under the Security tab of your organization and are based on activity from the last 30 days.

![screenshot of push protection metrics, showing overall secrets blocked and details on most blocked types, repositories with most pushes blocked, and bypassed secret metrics](https://github.com/courtneycl/monorepo/assets/3474250/3b91c69c-6160-499f-9cdf-26d51069678c)

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)