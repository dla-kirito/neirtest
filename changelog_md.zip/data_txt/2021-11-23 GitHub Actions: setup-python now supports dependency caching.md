November 23, 2021 

You can now run workflows for Python projects faster on GitHub Actions by enabling dependency caching on the [setup-python](https://github.com/actions/setup-python) action. setup-python supports caching for both pip and pipenv projects.

The following example enables caching for a Python project with pip:

```yaml
steps:
- uses: actions/checkout@v2
- uses: actions/setup-python@v2
  with:
    python-version: '3.9'
    cache: 'pip'
- run: pip install -r requirements.txt
- run: pip test
```

For additional examples, visit the [setup-python repository](https://github.com/actions/setup-python#caching-packages-dependencies).