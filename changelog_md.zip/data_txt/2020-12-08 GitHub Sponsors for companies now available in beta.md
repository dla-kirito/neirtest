December 8, 2020 

Companies can now invest in open source with GitHub Sponsors!

* **We’re launching GitHub Sponsors for companies in beta on December 8 (Tuesday) at [Universe](https://githubuniverse.com/).**
* **Self-service (payment via credit card or PayPal) orgs can sign up right away.** During the beta, companies with invoiced accounts are not yet supported but can [join a waitlist](http://www.github.com/sponsors/) for updates.
* **Companies will be charged a 10% fee after the beta.** We’re waiving the fee during the beta to thank early adopters for getting the program jump-started. After the beta, we will charge sponsors a 10% fee on top of the sponsorship amount to cover our operational costs.
* **We’ve added more discoverability with [an improved Explore page](https://github.com/sponsors/community).**

[Learn more](http://www.github.com/sponsors/)