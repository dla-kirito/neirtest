February 13, 2019 

Comments now indicate if they were left by the author of the issue or pull request.

[Learn more about commenting](https://help.github.com/articles/commenting-on-a-pull-request/)