November 13, 2019 

GitHub Sponsors is now available in beta for projects to receive sponsorship as a team. If you’re part of an open source project with a corporate or non-profit entity and bank account, you can [sign up for the waitlist](http://github.com/sponsors) today.