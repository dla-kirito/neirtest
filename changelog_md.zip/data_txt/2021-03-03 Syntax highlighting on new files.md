March 3, 2021 

Syntax highlight is now available when creating a file from the web. Previously it was only available when editing a file that was already committed. 

Highlighting is based on the new file's extension. Learn more about [syntax highlighting](https://docs.github.com/en/github/writing-on-github/creating-and-highlighting-code-blocks#syntax-highlighting).

![New file with .md and .rb syntax highlighting](https://i0.wp.com/user-images.githubusercontent.com/7900087/109227944-f9289f00-7775-11eb-89e7-4bdd287ccb89.gif?ssl=1)