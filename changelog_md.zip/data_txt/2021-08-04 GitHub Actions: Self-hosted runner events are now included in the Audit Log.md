August 4, 2021 

The Audit Log now includes events associated with GitHub Actions self-hosted runners. This data provides enterprise customers with an expanded data set for security and compliance audits.

New events will be incorporated into the audit log when:

* A self-hosted runner application has started and can begin processing new jobs
* A self-hosted runner application has stopped and will no longer process jobs

These new events are only available to customers on the Enterprise plan and can be viewed using the REST API. 

[Learn more about Audit Log events](https://docs.github.com/en/free-pro-team@latest/github/setting-up-and-managing-organizations-and-teams/reviewing-the-audit-log-for-your-organization#audit-log-actions)

[For questions please visit the GitHub Actions community forum](https://github.community/t5/GitHub-Actions/bd-p/actions)