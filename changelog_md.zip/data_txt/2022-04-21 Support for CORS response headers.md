April 21, 2022 

The following `registry.npmjs.com` endpoints will now serve [CORS](https://en.wikipedia.org/wiki/Cross-origin%5Fresource%5Fsharing) response headers.

1. `GET /package-name`
2. `GET /package-name/-/package-name.tgz`
3. `GET /package-name/version`