August 10, 2023 

As an organization owner or member of the security manager role, you can now [use the repository security advisories REST API](https://docs.github.com/en/rest/security-advisories/repository-advisories#list-repository-security-advisories-for-an-organization) to get all repository security advisories across your organization.

Learn more about [repository security advisories](https://docs.github.com/en/code-security/security-advisories/repository-security-advisories/about-repository-security-advisories).