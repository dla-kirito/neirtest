September 9, 2021 

The GitHub Enterprise Server 3.2 Release Candidate is available. This release includes more than 70 new features and changes to improve the developer experience and deliver new security capabilities for our customers. 

[Read the blog](https://github.blog/2021-09-09-github-enterprise-server-3-2-color-modes-security/) to discover the highlights in this release. Or, dive into the full [GitHub Enterprise Server 3.2 release notes](https://docs.github.com/en/enterprise-server@3.2/admin/release-notes#3.2.0.rc1), and [download it today](https://enterprise.github.com/releases/3.2.0/download). 

Release Candidates are a way for you to try the latest features at the earliest time, and they help us gather feedback early to ensure the release works in your environment. They should be tested on non-production environments. 