April 22, 2020 

The new web notifications interface is now generally available. Filter through your notifications more efficiently to act on the work that is most important to you and your team. 

The new interface allows for custom filter workflows in addition to clearing notifications quickly with keyboard shortcuts.

[Learn more about web notifications](https://help.github.com/en/github/managing-subscriptions-and-notifications-on-github/about-notifications)