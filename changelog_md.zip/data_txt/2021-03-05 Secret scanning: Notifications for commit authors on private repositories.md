March 5, 2021 

Secret scanning on private repositories now notifies commit authors when they push a change that includes a potential secret. The commit author can view the associated alert and mark it as revoked or false positive. As always, details of the last action taken on the alert are displayed in the UI and in the API.

[Learn more about secret scanning for private repositories](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning#about-secret-scanning-for-private-repositories)