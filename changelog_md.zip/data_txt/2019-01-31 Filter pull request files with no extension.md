January 31, 2019 

Files with no extension such as `CODEOWNERS` and `LICENSE` can now be toggled with the pull request file filter.

[Learn more about filtering files in a pull request by file type](https://help.github.com/articles/filtering-files-in-a-pull-request-by-file-type)