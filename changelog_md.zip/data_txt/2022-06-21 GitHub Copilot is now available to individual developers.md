June 21, 2022 

Today, we’re officially releasing GitHub Copilot, an AI pair programmer that suggests code in your editor, to all developers for $10 USD/month or $100 USD/year.

To show our appreciation to the Open Source and Learning communities, it will also be free to use for verified students and maintainers for popular open source project on GitHub.

Also thanks to users who are already in the technical preview program. You can continue enjoy free access until August 22nd.

[Learn more in the GitHub CEO’s blog](https://github.blog/2022-06-21-github-copilot-is-generally-available-to-all-developers)