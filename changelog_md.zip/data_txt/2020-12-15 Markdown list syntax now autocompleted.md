December 15, 2020 

When you’re writing an issue, pull request, or discussion comment the list syntax for bullets, numbers, and tasks will now be autocompleted after you press return or enter.

![User types a bullet, number, and task list faster now that the syntax autocompletes](https://i0.wp.com/user-images.githubusercontent.com/22751162/101221056-c457f080-363b-11eb-96be-2e260f376112.gif?ssl=1)

If you’re at the end of your list, use shift \+ enter to skip the autocomplete and continue writing on the next line.

[Learn more about writing Markdown on GitHub](https://docs.github.com/en/free-pro-team@latest/github/writing-on-github/basic-writing-and-formatting-syntax)