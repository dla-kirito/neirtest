April 17, 2023 

Available in public beta today, the security coverage page now includes multi-repository enablement, which lets you enable or disable security features across several repositories at once. This feature improves upon the "enable all" feature that only allows you to enable one security feature at a time for all repositories within the organization.

Multi-repository enablement also allows you to filter repositories based on attributes such as team or repository topic, and to enable or disable security features for only those repositories in just a few clicks.  

![multi-repository enablement panel on security coverage page](https://i0.wp.com/user-images.githubusercontent.com/2262535/232230535-8b916a4e-7622-4459-8588-63a276fe8359.png?ssl=1) 

The following security features can be enabled/disabled using multi-repository enablement:

* Dependency graph
* Dependabot alerts
* Dependabot security updates
* GitHub Advanced Security
* Code scanning default setup
* Secret scanning
* Push protection

These improvements have shipped as a public beta to GitHub.com and will be available in GitHub Enterprise Server 3.10.

[Learn more about multi-repository enablement](https://docs.github.com/en/enterprise-cloud@latest/code-security/security-overview/enabling-security-features-for-multiple-repositories) and [send us your feedback](https://github.com/github-community/community/discussions/categories/code-security)  
  
[Learn more about GitHub Advanced Security](https://github.com/features/security)