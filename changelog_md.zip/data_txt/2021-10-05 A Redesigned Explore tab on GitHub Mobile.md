October 5, 2021 

The Explore tab on GitHub Mobile has been redesigned to make it easier to find the best projects on GitHub!

Find personalized repository recommendations based on your past contributions and previously starred repositories. It's now possible to find trending projects in the last day, week, or month, and get even more specific with filters for specific programming or spoken languages.

The Explore tab now also displays a list of contributors for each repository, so be sure to go give your favorites a follow.

Read more about [GitHub Mobile](https://github.com/mobile) and [send us your feedback](https://github.com/github/feedback/discussions/categories/mobile-feedback) to help us improve.