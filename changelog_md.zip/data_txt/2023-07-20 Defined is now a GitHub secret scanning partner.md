July 20, 2023 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, our scans help prevent data leaks and fraud.

We have partnered with [Defined](https://www.defined.net/) to scan for their tokens and help secure our mutual users on public repositories. Defined tokens allow users to access various administrative functions of their managed mesh networking offerings. GitHub will forward access tokens found in public repositories to Defined, which will then email the user. You can read more information about Defined's tokens [here](https://docs.defined.net/api/defined-networking-api/).

All users can scan for and block Defined's tokens from entering their public repositories for free with [push protection](https://docs.github.com/en/code-security/secret-scanning/protecting-pushes-with-secret-scanning). GitHub Advanced Security customers can also scan for and block Defined tokens in their private repositories.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)