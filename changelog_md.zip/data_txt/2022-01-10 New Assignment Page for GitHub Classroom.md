January 10, 2022 

The GitHub Classroom team is excited to announce our new experience for viewing information about your assignments! These changes will be gradually rolling out over the next week. The revamped view adds a higher-level summary of your students' progress with their assignment as well as refreshes the overall UI. 

For more information on how to use this new experience, check out our [Documentation](https://docs.github.com/en/education/manage-coursework-with-github-classroom/teach-with-github-classroom). Your feedback is welcome at our [Education Community Forum](https://education.github.community/).

![Assignment page in Classroom](https://i0.wp.com/user-images.githubusercontent.com/16325997/148771648-2647e873-1f03-4a58-a7f6-0b793a71112b.png?ssl=1)