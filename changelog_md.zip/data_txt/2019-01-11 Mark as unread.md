January 11, 2019 

Web notifications on GitHub now allow you to mark a notification as unread. After opening a new notification or viewing a previously read notification you can mark them as unread.

![A demonstration of marking unread](https://github.blog/wp-content/uploads/2019/01/mark-as-unread.gif?resize=1024%2C512)

[Learn more about marking notifications as unread](https://help.github.com/articles/marking-notifications-as-read)