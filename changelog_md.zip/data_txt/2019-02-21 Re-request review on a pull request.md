February 21, 2019 

If changes have been made to a pull request that has already been reviewed, you can now re-request a review with a single click in the pull request’s sidebar. This will notify the requested reviewers that changes have been made.

For more information on these APIs, please visit our documentation:

* [Requesting a pull request review](https://help.github.com/en/articles/requesting-a-pull-request-review)