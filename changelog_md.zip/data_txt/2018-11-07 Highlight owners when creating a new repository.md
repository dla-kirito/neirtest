November 7, 2018 

The owner dropdown is now highlighted first on the “Create a new repository” page, so that you don’t forget to set it before publishing a new repository.

[Learn more about creating new repos](https://help.github.com/articles/create-a-repo/)