November 13, 2023 

In the upcoming days, Codespaces will be adding the Australia region to prebuild configurations under region availability. This will enable users to have prebuilds specifically in Australia.

### How do I get access to Prebuilds in the Australia region?[](#how-do-i-get-access-to-prebuilds-in-the-australia-region)

If you would like to have Australia selected as a region, go to your prebuilds and select the Australia region.

### What if I already have all regions selected for my Prebuilds?[](#what-if-i-already-have-all-regions-selected-for-my-prebuilds)

If you have all regions currently selected you will have all regions except for Australia selected once this change is implemented. This will be change to ensure users do not get billed in a region they do not want.

If you would like to have all regions, including Australia, selected, please go to your prebuilds and select all regions again.

### What if I am already using the Southeast Asia as a region?[](#what-if-i-am-already-using-the-southeast-asia-as-a-region)

Prebuild configurations with Southeast Asia already selected as a region with users in Australia may experience decreased codespace creation time as Australia will now be a separate region from Southeast Asia. To continue to get improved codespace creation time, add Australia as a region under region availability.

Please [contact support](https://support.github.com/) if you have any issues.