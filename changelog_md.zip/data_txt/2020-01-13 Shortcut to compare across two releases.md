January 13, 2020 

You can now compare tags between two releases – in order to determine what changes have been made – by clicking on the `Compare ▾` button for a given release.

[Learn more about releases on GitHub](https://help.github.com/en/github/administering-a-repository/about-releases)