July 28, 2022 

In April 2022, we released improvements to help [streamline your Codespaces experience when working with multi-repository and monorepo projects](https://github.blog/2022-04-20-codespaces-multi-repository-monorepo-scenarios/). Today we're announcing support for [prebuilding](https://aka.ms/ghcs-prebuild) these project types as well to enable you take advantage of fast creation times across any project configuration.

### Prebuilding codespaces for multi-repository projects[](#prebuilding-codespaces-for-multi-repository-projects)

For multi-repository projects, or projects that need additional dev time resources (ex. packages), repository administrators can now [specify required permissions in the dev container configuration](https://docs.github.com/en/codespaces/managing-your-codespaces/managing-repository-access-for-your-codespaces#setting-additional-repository-permissions) for a prebuild-enabled branch. The prebuild configuration UI will then guide the administrator to authorize those permissions during the creation of the prebuild. This means that users no longer have to set up and manage repository level personal access tokens for prebuild-enabled multi-repository projects.  
![Authorize permissions for prebuilds!](https://i0.wp.com/user-images.githubusercontent.com/30297258/181124531-79511d5a-7381-4485-a2a0-40af898d109b.png?w=700&ssl=1)

### Prebuilding codespaces for monorepo projects[](#prebuilding-codespaces-for-monorepo-projects)

For monorepo projects, repository administrators can choose a specific [dev container configuration](https://docs.github.com/en/enterprise-cloud@latest/codespaces/setting-up-your-project-for-codespaces/introduction-to-dev-containers#devcontainerjson) from within their repository to be prebuilt while configuring the prebuild. This enables sub-teams working on specific parts of a monorepo to have a prebuild that is optimized for their scenario and requirements.  
![Select a specific dev container to prebuild](https://i0.wp.com/user-images.githubusercontent.com/30297258/181075785-6252fb24-830e-44cf-a480-a52b023a58a1.png?ssl=1)

### Get started[](#get-started)

Here are some helpful links to get you started:

* [Creating a prebuild configuration for multi-repository projects](https://aka.ms/ghcs-prebuild-multirepo)
* [Creating a prebuild configuration for monorepo projects](https://aka.ms/ghcs-prebuild-monorepo)

If you have any feedback to help improve this experience, be sure to post it on our [discussions forum](https://aka.ms/ghcs-feedback).