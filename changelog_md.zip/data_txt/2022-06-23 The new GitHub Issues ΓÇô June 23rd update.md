June 23, 2022 

This marks 1️⃣ year since our initial [private beta announcement](https://github.blog/changelog/2021-06-23-whats-new-with-github-issues/)! 🎉

Today's Changelog brings you the ability to bulk add items to projects and GraphQL API improvements!

### 🪷 Bulk add items[](#🪷-bulk-add-items)

To make it even easier to add your issues and pull requests to a project, we have now added a new way to bulk add issues to your projects.

* Hit the `+` button by the omnibar.
* Select `Add item from repository`.
* Pick your repository and get adding.

![2022-06-22 19-30-46 2022-06-22 20_02_27](https://i0.wp.com/user-images.githubusercontent.com/2086381/175290011-a4b82bac-4a66-42fa-bff6-518e3a3052e3.gif?ssl=1)

### 🤖 GraphQL API improvements[](#🤖-graphql-api-improvements)

The projects GraphQL API is now generally available 🎉. With this update, we are announcing:

1) The introduction of new [ProjectV2](https://docs.github.com/en/graphql/reference/objects#projectv2) object and mutations.  
2) The deprecation of [ProjectNext](https://docs.github.com/en/graphql/reference/objects#projectnext) object and mutations, scheduled for 1st October 2022.

**What are the new changes?**

We have added a new [ProjectV2](https://docs.github.com/en/graphql/reference/objects#projectv2) object to our GraphQL API to programmatically access a project.

The fields of the project are now available as:

* [ProjectV2Field](https://docs.github.com/en/graphql/reference/objects#projectv2field) for a text, number or date field.
* [ProjectV2IterationField](https://docs.github.com/en/graphql/reference/objects#projectv2iterationfield) for an iteration field. The iteration details are available under the configuration object.
* [ProjectV2SingleSelectField](https://docs.github.com/en/graphql/reference/objects#projectv2singleselectfield) for a single select field. The details about the different options are available under the options object.

The items of the project are represented by the [ProjectV2Item](https://docs.github.com/en/graphql/reference/objects#projectv2item) object. It contains a field `type` to identify the item type – `Issue`, `Pull Request`, `Draft Issue` or `Redacted`. The values of the item are available under the `fieldValues` field.

We are also adding the following mutations for updating a project:

* [updateProjectV2](https://docs.github.com/en/graphql/reference/mutations#updateprojectv2)
* [addProjectV2ItemById](https://docs.github.com/en/graphql/reference/mutations#addprojectv2itembyid)
* [updateProjectV2ItemFieldValue](https://docs.github.com/en/graphql/reference/mutations#updateprojectv2itemfieldvalue)
* [updateProjectV2ItemPosition](https://docs.github.com/en/graphql/reference/mutations#updateprojectv2itemposition)
* [addProjectV2DraftIssue](https://docs.github.com/en/graphql/reference/mutations#addprojectv2draftissue)
* [updateProjectV2DraftIssue](https://docs.github.com/en/graphql/reference/mutations#updateprojectv2draftissue)

Based on feedback that more granular scopes would be useful, we have introduced new OAuth scopes specifically for this update:

* The `read:project` scope provides query access to `ProjectV2` objects.
* The `project` scope provides query access to `ProjectV2` objects and access to mutations.

### ✨ Bug fixes & improvements[](#✨-bug-fixes--improvements)

Other changes include:

* Bug fix where @mentions didn't include all users when editing a comment.
* Ability to open the issues side-panel using the spacebar.
* Long project titles no longer truncate when there is room to display the full title.
* Bug fix to resolve a flash that occurs when creating or editing a project view title.

See how to use GitHub for project planning with [GitHub Issues](http://github.com/features/issues), check out what's on the [roadmap](https://github.com/orgs/github/projects/4247/views/7), and learn more in the [docs](https://docs.github.com/issues).