August 2, 2021 

You can now use the API (beta) to configure custom autolinks to external resources. The REST API now provides GET/POST/DELETE endpoints from which you can view, add or delete custom autolinks associated with a repository.

Learn more about [custom autolinks](https://docs.github.com/en/github/writing-on-github/working-with-advanced-formatting/autolinked-references-and-urls#custom-autolinks-to-external-resources) or view the full [API schema](https://docs.github.com/en/rest/reference/repos#autolinks).