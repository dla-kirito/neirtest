September 26, 2019 

The Actions tab is getting an exciting new look and many new features based on feedback from our users. Today you will see the following improvements:

* Runs are now organized by the workflows that _currently_ exist on the repository. To see older runs – like those from workflows with a different name or new ones from a branch, you can check out the “All workflows” filter.
* In addition to linking your runs to their respective pull requests, there’s now the option to cancel a run that’s in progress as well as view the workflow file within the context of that run.
* The “New workflow” button takes you back to the “Get started with GitHub Actions” page.
* With a few performance tweaks, the tab now loads even faster!

![](https://github.blog/wp-content/uploads/2019/09/actions-new-1.png?w=1024&resize=1024%2C656)

If you have any questions or thoughts about these changes, we recommend sharing in our GitHub Community Forum’s [Actions Board](https://github.community/t5/GitHub-Actions/bd-p/actions)!