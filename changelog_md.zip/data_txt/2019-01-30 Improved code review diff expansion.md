January 30, 2019 

GitHub code review now supports expanding the diff view in upward and downward directions so you can see more context around the diff you’re viewing.

[Learn more about reviewing changes in pull requests](https://help.github.com/articles/reviewing-changes-in-pull-requests)