June 27, 2023 

We have received customers reporting errors with Actions’ [OIDC integration with AWS](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services).  
This happens for customers who are pinned to a single intermediary thumbprint from the Certificate Authority (CA) of the Actions SSL certificate.

There are two possible intermediary certificates for the Actions SSL certificate and either can be returned by our servers, requiring customers to trust both. This is a known behavior when the intermediary certificates are cross-signed by the CA.

Customers experiencing issues authenticating via OIDC with AWS should [configure both thumbprints to be trusted in the AWS portal](https://docs.aws.amazon.com/IAM/latest/UserGuide/id%5Froles%5Fproviders%5Fcreate%5Foidc.html).  
The two known intermediary thumbprints at this time are:

* `6938fd4d98bab03faadb97b34396831e3780aea1`
* `1c58a3a8518e8759bf075b76b750d4f2df264fcd`

[Learn more about using OIDC with GitHub Actions](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect).