November 14, 2019 

Token leaks are one of the most common security mistakes, and they can have disastrous consequences. GitHub Token Scanning looks for leaked tokens in public repositories and works with the issuer to notify the developer and/or revoke the token as appropriate. This protects users from fraud or data leaks. Starting today, GitHub has partnered with [GoCardless](https://gocardless.com), [HashiCorp](https://hashicorp.com), [Postman](https://www.getpostman.com/), and [Tencent Cloud](https://intl.cloud.tencent.com/) to scan for their respective developer tokens.

[Learn more about token scanning](https://help.github.com/en/articles/about-token-scanning)  
[Partnering with GitHub on token scanning](https://developer.github.com/partnerships/token-scanning/)