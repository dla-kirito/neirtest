March 14, 2023 

GitHub Discussions now supports the ability to close a Discussion. Discussions can be closed for one of three reasons: Resolved, Outdated, or Duplicate. Closing a Discussion is much like closing an Issue or a Pull Request. Users can select a reason for closing in the dropdown. A screenshot of the dropdown is shown below:

![Dropdown showing Close Discussion options](https://i0.wp.com/user-images.githubusercontent.com/3157267/224842821-c451b3b9-9cb0-427b-81af-1dddd3935bc9.png?ssl=1)

The reason for closing is visible to users in two places on the page.

First, in the icon at the top of the Discussion:

![Icon at the top of Discussions showing that it is closed](https://i0.wp.com/user-images.githubusercontent.com/3157267/224843498-f5aa49d4-fd3a-4a30-bdcc-bd7954ec2537.png?ssl=1)

Second, on the events timeline:

![The event timeline showing a Discussion being closed](https://i0.wp.com/user-images.githubusercontent.com/3157267/224843530-66bb8bf5-bf3a-4410-87ef-6657ec7d2b20.png?ssl=1)

Besides the state of the Discussion being visible on the page, we're also now surfacing the state of a Discussion in search. We're adding three new filters:

`is:<closed/opened>`  
filters out open/closed discussions

`reason:<resolved/outdated/duplicate>`  
returns closed discussions that were closed with the provided reason

`closed:<date>`  
returns discussions closed on a certain date. Supports `<` and `>` operators to get discussions closed before or after the date.