March 28, 2019 

Phone numbers are now partially hidden in the account recovery settings dialog to provide an extra layer of safety and security.

[Learn more about updating your security settings on GitHub](https://help.github.com/en/articles/about-two-factor-authentication)