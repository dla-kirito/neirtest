July 25, 2018 

We have redesigned the two-factor authentication profile settings to make it easier to keep your account up to date. You will occasionally be prompted with a reminder to confirm your settings are correct to avoid being locked out of your account.

For more information on securing your account with two-factor authentication, please view our [documentation](https://help.github.com/articles/securing-your-account-with-two-factor-authentication-2fa/).