April 19, 2021 

GitHub Actions now supports a `concurrency` key at both the workflow and job level that will ensure that only a single run or job is in progress.

There are a number of scenarios where you only want a single instance of a particular workflow or job running at any given time. For example: if you have a deployment to your production environment ensuring that only a single deployment is happening at any given time and that you are always deploying the latest code can be important. The `concurrency` key can be any string or an expression using the `github` context. When a job or run starts it first checks to see if anything is currently holding on to the concurrency group specified. If not, it will start. If there is a lock on the group, the job or run will be marked as pending and will only start after the blocking job or run completes. 

[Learn more about concurrency groups in GitHub Actions](https://docs.github.com/en/actions/reference/workflow-syntax-for-github-actions#concurrency)

[For questions, visit the GitHub Actions community](https://github.community/c/code-to-cloud/github-actions/41)

[To see what's next for Actions, visit our public roadmap](https://github.com/github/roadmap/projects/1?card%5Ffilter%5Fquery=label%3Aactions)