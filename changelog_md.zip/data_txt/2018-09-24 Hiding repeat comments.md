September 24, 2018 

All consecutive duplicate comments in discussion threads are now hidden by default. This means that threads with numerous, duplicate emoji or `+1`s will now become shorter to read.

To view comments that have been hidden, simply click on the “…similar comments” button below the first comment.