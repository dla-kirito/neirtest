November 1, 2021 

It's now possible to dismiss Dependabot alerts via the GraphQL API. For more info, see [our docs](https://docs.github.com/en/graphql/reference/mutations#dismissrepositoryvulnerabilityalert).