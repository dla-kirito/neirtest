August 7, 2023 

For security reasons, source IP addresses have been removed from error messages that are returned from the GitHub API when callers try to access protected resources from non-permitted IP addresses.

To learn more about IP allow lists, visit [Restricting network traffic to your enterprise with an IP allow list](https://docs.github.com/en/enterprise-cloud@latest/admin/configuration/hardening-security-for-your-enterprise/restricting-network-traffic-to-your-enterprise-with-an-ip-allow-list) in the GitHub documentation.

If you'd like to learn more about your source IP addresses, please contact [GitHub Support](https://support.github.com/).