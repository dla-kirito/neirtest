June 13, 2023 

Node12 has been out of support since [April 2022](https://github.com/nodejs/Release/#end-of-life-releases). As a result we have started the deprecation process of Node12 for GitHub Actions. We plan to migrate all actions to run on Node16 by Summer 2023.  
Following on from our [warning in workflows using Node12](https://github.blog/changelog/2022-09-22-github-actions-all-actions-will-begin-running-on-node16-instead-of-node12/) we will start enforcing the use of Node16 rather than Node12 on the 14th of June.

To opt out of this and continue using Node12 while it is still available in the runner, you can choose to set `ACTIONS_ALLOW_USE_UNSECURE_NODE_VERSION=true`  
as an 'env' in their workflow or as an environment variable on your runner machine. This will only work until we upgrade the runner removing Node12 later in the summer.

## What you need to do[](#what-you-need-to-do)

For Actions maintainers: Update your actions to run on Node16 instead of Node12 ([Actions configuration settings](https://docs.github.com/en/actions/creating-actions/metadata-syntax-for-github-actions#runs-for-javascript-actions))  
For Actions users: Update your workflows with latest versions of the actions which runs on Node16 ([Using versions for Actions](https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#example-using-versioned-actions))