April 14, 2022 

GitHub secret scanning protects users by searching repositories for known types of secrets. By identifying and flagging these secrets, we help protect users from data leaks and fraud associated with exposed data.

We have partnered with [JD Cloud](https://www.jdcloud.com/) to scan for their access tokens, which are used for cloud computing services. We'll forward access tokens found in public repositories to JD Cloud, who will notify the user by email without making any changes to the tokens. Users can request support for their JD Cloud API tokens [here](https://ticket.jdcloud.com/).

We continue to welcome new partners for public repository secret scanning. GitHub Advanced Security customers can also scan their private repositories for leaked secrets.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)