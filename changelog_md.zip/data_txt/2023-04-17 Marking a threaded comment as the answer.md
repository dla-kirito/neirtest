April 17, 2023 

When we [introduced GitHub Discussions](https://github.blog/changelog/2020-12-08-github-discussions-now-available-as-a-public-beta/) in 2020, we allowed users to mark an answer to a question in the "Q&A" Discussions category. As the feature began getting more usage, we noticed that often, the real answer to a question may live in a reply to an answer. Today, we are introducing the ability for users to mark a threaded reply as the answer to a question.

All replies will now have a button to allow the questioner to mark them as the answer.  
![Screenshot 2023-04-05 at 3 11 51 PM](https://i0.wp.com/user-images.githubusercontent.com/3157267/230223264-5e87c0ee-c0aa-4dd1-8ebf-8a96b5ff418d.png?w=951&ssl=1)

Marking the reply as the answer highlights it and makes it clear to the reader where the real answer to the original question lives.  
![Screenshot 2023-04-05 at 3 12 33 PM](https://i0.wp.com/user-images.githubusercontent.com/3157267/230223509-603303e7-ed2d-4ae4-ba50-a6707fcb0420.png?w=951&ssl=1)

This feature improves the accuracy of marked answers, while also reducing the burden on users to duplicate their text to get their answer marked as correct.

For questions or feedback, please visit [our community](https://github.com/community/community/discussions/categories/discussions).