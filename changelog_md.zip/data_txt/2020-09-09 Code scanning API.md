September 9, 2020 

If you are enrolled in the GitHub Advanced Security code scanning beta, we are releasing new APIs for you to start using. This release also includes some breaking changes to the existing code scanning `/alerts` API.

### New capabilities[](#new-capabilities)

* Get recent code scanning analyses for a repository
* Update the state of a code scanning alert
* Upload a SARIF file to create alerts from your GitHub App or GitHub Actions workflow
* Get webhook events for code scanning alerts

### Breaking changes[](#breaking-changes)

* The existing code scanning `/alerts` endpoint has changed.  
   * `open` has been replaced by `state`, which can have values `open`, `fixed`, or `dismissed`  
   * `closed_at`, `closed_reason`, and `closed_by` have been replaced by `dismissed_at`, `dismissed_reason` and `dismissed_at`.  
   * Rule properties are now nested within a `rule` object  
   * Tool properties are now nested within a `tool` object  
   * You can now get status about alerts across multiple branches. This state is stored in the `instances` object

For more information, see the [code scanning API reference](https://docs.github.com/en/rest/reference/code-scanning)