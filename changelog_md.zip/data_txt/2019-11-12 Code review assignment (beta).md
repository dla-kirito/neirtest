November 12, 2019 

Teams can now be configured to assign a specified number of reviewers when a team is requested for code review. When coupled with [CODEOWNERS](https://help.github.com/en/github/creating-cloning-and-archiving-repositories/about-code-owners), organizations can now ensure that code is reviewed by the proper team and automate distribution of code reviews across team members. Code review assignment is available for all users who are members of an organization as public beta.

[Learn more about code review assignment on GitHub](https://help.github.com/en/github/setting-up-and-managing-organizations-and-teams/managing-code-review-assignment-for-your-team)