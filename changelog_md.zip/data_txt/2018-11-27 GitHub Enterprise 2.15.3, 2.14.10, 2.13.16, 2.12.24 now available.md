November 27, 2018 

The 2.15.3, 2.14.10, 2.13.16, and 2.12.24 releases for GitHub Enterprise are now [available for download](https://enterprise.github.com/releases).

View the full release notes:

* [See Enterprise 2.15.3 release notes](https://enterprise.github.com/releases/2.15.3/notes)
* [See Enterprise 2.14.10 release notes](https://enterprise.github.com/releases/2.14.10/notes)
* [See Enterprise 2.13.16 release notes](https://enterprise.github.com/releases/2.13.16/notes)
* [See Enterprise 2.12.24 release notes](https://enterprise.github.com/releases/2.12.24/notes)