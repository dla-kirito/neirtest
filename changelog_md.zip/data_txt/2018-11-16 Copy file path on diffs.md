November 16, 2018 

We’ve added the ability to copy the file path for a diff in a pull request.

[Learn more about pull requests](https://help.github.com/articles/about-pull-requests/)