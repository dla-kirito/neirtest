March 6, 2020 

[GitHub CLI](https://cli.github.com/) 0.6 was just released with various bug fixes, improvements, and support for four new commands:

* `gh repo clone` – clone a repository locally
* `gh repo create` – create a new repository
* `gh repo fork` – create a fork of a repository
* `gh repo view` – view a repository in the browser

[View the release notes](https://github.com/cli/cli/releases/tag/v0.6.0) · [Download GitHub CLI](https://cli.github.com/)

**Please note:** GitHub CLI is in early stages of development. We’d love to [hear your feedback](https://forms.gle/umxd3h31c7aMQFKG7).