August 12, 2021 

As [previously announced](https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/), starting on August 13, 2021, at 09:00 PST, we will no longer accept account passwords when authenticating Git operations on GitHub.com. Instead, token-based authentication (for example, personal access, OAuth, SSH Key, or GitHub App installation token) will be required for all authenticated Git operations.

Please refer to this [blog post](https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/#what-you-need-to-do-today) for instructions on what you need to do to continue using git operations securely.

#### Removal[](#removal)

* August 13, 2021, at 09:00 PST