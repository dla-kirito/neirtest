September 13, 2021 

The new GraphQL mutation [createCommitOnBranch](https://docs.github.com/en/graphql/reference/mutations#createcommitonbranch) makes it easier to add, update, and delete files in a branch of a repository.

This new API offers a simpler way to commit changes compared to the existing [Git database REST APIs](https://docs.github.com/en/rest/reference/git). With the new `createCommitOnBranch` mutation, you do not need to manually create blobs and trees before creating the commit. This allows you to add, update, or delete multiple files in a single API call.

Commits authored using the new API are automatically GPG signed and are [marked as verified](https://docs.github.com/en/github/authenticating-to-github/managing-commit-signature-verification/about-commit-signature-verification) in the GitHub UI. GitHub Apps can use the mutation to author commits directly or [on behalf of users](https://docs.github.com/en/developers/apps/building-github-apps/identifying-and-authorizing-users-for-github-apps#user-to-server-requests).

<https://github.blog/wp-content/uploads/2021/09/API-commit-authoring.mp4>

---

See the [GraphQL API reference](https://docs.github.com/en/graphql/reference/mutations#createcommitonbranch) for more information on using `createCommitOnBranch`. You can also try it in the [GraphQL API Explorer](https://docs.github.com/en/graphql/overview/explorer)! If you need a refresher on how to use the GraphQL API, see our [guide](https://docs.github.com/en/graphql/guides).