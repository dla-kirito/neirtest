June 29, 2021 

We've shipped a couple of changes to our APIs:

* The code scanning API now returns the CodeQL query version used for an analysis. This can be used to reproduce results or confirm that an analysis used the latest query.
* Admin users can now use the REST API to enable or disable GitHub Advanced Security for repositories using the `security_and_analysis` object on `repos/:org/:repo`. In addition, admin users can check whether Advanced Security is currently enabled for a repository by using a `GET /repos/{owner}/{repo}` request. These changes help you manage Advanced Security repository access at scale. For more information, see the [repos REST API documentation](https://docs.github.com/en/rest/reference/repos#update-a-repository).