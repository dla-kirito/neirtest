August 30, 2019 

The `triage` and `maintain` roles now have expanded permissions. Users with the `triage` role can request reviews on pull requests, mark issues and pull requests as duplicates, and add or remove milestones on issues and pull requests. Updates to the `maintain` role include the ability to [configure pull request merges](https://help.github.com/en/articles/configuring-pull-request-merges), push to protected branches, and [manage the interaction limits](https://help.github.com/en/articles/limiting-interactions-in-your-repository) for assigned repositories.

[Learn more about repository permission levels for an organization](https://help.github.com/en/articles/repository-permission-levels-for-an-organization)