December 16, 2020 

Pull request auto-merge is now rolling out as a public beta! With auto-merge, pull requests can be automatically merged when all requirements for merging are met. No more waiting for long checks to finish just so you can press the merge button!

To use auto-merge, a repository maintainer or admin must first toggle on the repository setting to allow auto-merge ([see steps](https://docs.github.com/github/administering-a-repository/managing-auto-merge-for-pull-requests-in-your-repository)). Then any user with write permission can enable or disable auto-merge by navigating to the pull request page.

Note that auto-merge can only be enabled on pull requests that target a branch protected by required reviews or status checks.

Learn more about [pull request auto-merge](https://docs.github.com/github/collaborating-with-issues-and-pull-requests/automatically-merging-a-pull-request)