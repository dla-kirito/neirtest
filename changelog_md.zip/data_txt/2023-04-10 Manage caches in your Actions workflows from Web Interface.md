April 10, 2023 

Caching dependencies and other commonly reused files enables developers to speed up their GitHub Actions workflows and make them more efficient.  
We have now enabled [Cache Management from the web interface](https://docs.github.com/en/enterprise-cloud@latest/actions/using-workflows/caching-dependencies-to-speed-up-workflows#managing-caches) to enable developers to get more transparency and control over their cache usage within their GitHub repositories.

Actions users who use [actions/cache](https://github.com/actions/cache) can now:

* View a list of all cache entries for a repository.
* Filter and sort the list of caches using specific metadata such as cache size, creation time, or last accessed time.
* Delete a corrupt or a stale cache entry
* Monitor aggregate cache usage for repositories and organizations.

In addition to the Cache Management UX that we have now enabled, you could also use our [Cache APIs](https://docs.github.com/en/rest/actions/cache) or install the [GitHub CLI extension for Actions cache](https://github.com/actions/gh-actions-cache#readme) to manage your caches from your terminal.

Learn more about [dependency caching to speed up your Actions workflows](https://docs.github.com/en/actions/using-workflows/caching-dependencies-to-speed-up-workflows).  
For questions or to share your feedback, [visit the GitHub Actions community](https://github.com/orgs/community/discussions/categories/actions-and-packages).