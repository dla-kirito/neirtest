February 12, 2020 

Self-Hosted Runners now fully support environments that use a proxy server to connect to GitHub. You can add your proxy server as a Runner setting and leverage common Unix-style proxy environment variables like `no_proxy` exclusion lists.

Additionally, Actions built using the [toolkit](https://github.com/actions/toolkit) will now follow your proxy settings. This includes the common Actions included at [github.com/actions](https://github.com/actions).

[Learn more about using self-hosted runners behind a proxy here](https://help.github.com/en/actions/hosting-your-own-runners/using-a-proxy-server-with-self-hosted-runners).