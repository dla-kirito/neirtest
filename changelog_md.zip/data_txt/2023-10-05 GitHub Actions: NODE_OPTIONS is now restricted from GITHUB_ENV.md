October 5, 2023 

Due to security restrictions, users can no longer use GITHUB\_ENV to set the NODE\_OPTIONS environment variable in their workflows. Developers who have NODE\_OPTIONS set as an environment variable will now receive an error: `Can't store NODE_OPTIONS output parameter using '$GITHUB_ENV' command.`

This change was introduced in [actions/runner v2.309.0](https://github.com/actions/runner/releases/tag/v2.309.0).  
For more information on how to set environment variables, please see our docs [here](https://docs.github.com/en/actions/using-workflows/workflow-commands-for-github-actions#setting-an-environment-variable).