November 27, 2018 

You can now limit repository notifications exclusively to releases. Receive notifications when new releases are published in a repository without receiving notifications about other updates and conversations.

[Learn more about release notifications](https://help.github.com/articles/watching-and-unwatching-releases-for-a-repository)