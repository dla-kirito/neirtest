May 13, 2021 

GitHub Enterprise Cloud customers will now be able to approve domains for email notification routing that they are not [able to verify](https://docs.github.com/en/github/setting-up-and-managing-your-enterprise/verifying-or-approving-a-domain-for-your-enterprise-account#about-domain-approval). Enterprise and organization owners will be able to approve domains so that they may immediately augment their [email notification restriction policy](https://docs.github.com/en/github/setting-up-and-managing-your-enterprise/restricting-email-notifications-for-your-enterprise-account#restricting-email-notifications-for-your-enterprise-account), allowing notifications to collaborators, consultants, acquisitions or other partners.

This capability, along with the generally available feature enterprise verified domains, will ship to GitHub Enterprise Server 3.2\. 

[Learn more about restricting email notifications to an approved domain](https://docs.github.com/en/github/setting-up-and-managing-your-enterprise/restricting-email-notifications-for-your-enterprise-account)