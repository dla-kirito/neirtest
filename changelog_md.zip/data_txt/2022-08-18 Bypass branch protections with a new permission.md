August 18, 2022 

You can now create a custom role to [bypass branch protections](https://docs.github.com/en/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization#repository) without having to grant the Admin role. Previously, to bypass branch protections you had to be an Admin which provides additional permissions that may not be needed. For tighter control of Admin permissions, you can now craft a custom role that has the **Bypass branch protections** permission, allowing just the right amount of access.

![Image of Custom roles Inherited from Maintain role that adds the new Bypass branch protections permission](https://i0.wp.com/user-images.githubusercontent.com/7575792/185173387-d982a441-eedc-4f28-96a3-cc49ba9484ca.png?ssl=1)

To enforce branch protections for all Admins and roles with the "Bypass branch protections" permission, enable **Do not allow bypassing the above settings** in your [branch protection rules](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/defining-the-mergeability-of-pull-requests/about-protected-branches#do-not-allow-bypassing-the-above-settings).

![Image of checkbox selecting Do not allow bypassing the above settings](https://i0.wp.com/user-images.githubusercontent.com/7575792/185174391-420680fd-dfa2-4821-b137-94dea3ba9037.png?ssl=1)

This permission differs from the [Push commits to protected branches](https://docs.github.com/en/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization#repository) permission, which allows pushing to a protected branch, but branch protection rules will still apply and could result in a push being denied.

For more information, visit [Managing custom repository roles for an organization](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization) in the GitHub documentation.

We appreciate feedback on this and other topics in GitHub's [public feedback discussions](https://github.com/orgs/community/discussions/categories/general).