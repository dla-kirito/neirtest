March 16, 2021 

The latest version of GitHub Mobile includes native support of [GitHub Releases](https://docs.github.com/en/github/administering-a-repository/about-releases):

* View your repository's releases on the go.
* Read release notes to keep up with everything new in the projects you care about.
* Download the release assets right from your phone!

[Read more about GitHub Mobile](https://github.com/mobile) or [GitHub Releases](https://docs.github.com/en/github/administering-a-repository/about-releases). 