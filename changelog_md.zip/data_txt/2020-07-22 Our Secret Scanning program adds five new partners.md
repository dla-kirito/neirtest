July 22, 2020 

Secret leaks are one of the most common security mistakes, and they can have disastrous consequences. GitHub Secret Scanning looks for leaked secrets in all public repositories, and enrolled private repositories, and works with the issuer to notify the developer and/or revoke the token as appropriate. This protects users from fraud and data leaks.

In addition to our 24 existing partners, GitHub has partnered with [Shopify](https://www.shopify.com/), [MessageBird](https://messagebird.com/), [Dynatrace](https://www.dynatrace.com/), [SSLMate](https://sslmate.com/) and [Frame.io](https://frame.io/) to scan for their developer tokens! This brings our [total number of token scanning partners](https://help.github.com/en/articles/about-token-scanning) to 29.

* [Learn more about secret scanning](https://docs.github.com/en/github/administering-a-repository/about-secret-scanning)
* [Partner with GitHub on secret scanning](https://docs.github.com/en/developers/overview/secret-scanning/)