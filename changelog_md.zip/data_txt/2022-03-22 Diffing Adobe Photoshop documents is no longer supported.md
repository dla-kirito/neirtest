March 22, 2022 

GitHub can display several common image formats, including [Adobe Photoshop](https://www.adobe.com/products/photoshop.html) documents which have a `.psd` file extension. However, comparing differences between versions of Photoshop documents is no longer supported.

For more information about displaying and diffing images, visit [Working with non-code files](https://docs.github.com/en/repositories/working-with-files/using-files/working-with-non-code-files) in the GitHub documentation.