August 17, 2023 

As of August 17, 2023, Dependabot updates no longer support Python 3.6 or 3.7, which have reached their end-of-life. If your code uses these versions, Dependabot will no longer be able to open pull requests in your repository and will log errors. Update to at least Python 3.8 to ensure your code is secure and Dependabot can still run.

This change impacts Dependabot pull requests only – you will continue to receive Dependabot alerts for dependencies with known vulnerabilities. To resolve the alert, you can upgrade the affected package yourself manually.

View the official [release cycle for Python](https://devguide.python.org/versions/) for more information on supported versions.

[Learn more about supported package managers for Dependabot](https://docs.github.com/en/code-security/dependabot/dependabot-version-updates/about-dependabot-version-updates#supported-repositories-and-ecosystems)