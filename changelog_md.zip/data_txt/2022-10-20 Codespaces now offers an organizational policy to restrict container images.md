October 20, 2022 

With an organizational level policy to restrict container images, organization administrators can now control which base container images are used while creating organization-owned codespaces. This enables administrators to ensure that only verified container images are being used to create organization-owned codespaces.  
![allowed image policy screenshot](https://i0.wp.com/user-images.githubusercontent.com/30297258/196299994-9d413e42-d36b-4e7d-9679-e3e61efc020f.png?w=602&ssl=1)

Organization admins can specify which images and/or image sources are allowed to be used while creating organization-owned codespaces. If the image specified in the dev container configuration does not match one of the allowed images, then subsequent codespace creation will fail asking you to update the image in your [configuration](https://docs.github.com/en/codespaces/setting-up-your-project-for-codespaces/introduction-to-dev-containers#devcontainerjson). The base image policy does not apply to the default image, or the image that's used to recover a codespace if an error is introduced into a dev container configuration which prevents the container from being rebuilt.

For this release, the image policy will be applied at codespace creation and will not be applied when you rebuild a container. Support for the rebuild scenario is coming soon. We'd love your feedback on this policy and any additional policies that will help your scenarios on [Codespaces discussions](https://github.com/github/feedback/discussions/categories/codespaces-feedback).

For more information, see [Restricting base images for organization-owned codespaces](https://docs.github.com/en/codespaces/managing-codespaces-for-your-organization/restricting-the-base-image-for-codespaces)