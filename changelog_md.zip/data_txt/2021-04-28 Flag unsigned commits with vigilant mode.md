April 28, 2021 

To improve security and confidence in the authenticity of your contributions, you can flag commits and tags on GitHub.com that are attributed to you but not signed by you. With **vigilant mode** enabled (now available in beta), unsigned commits attributed to you are flagged with an **Unverified** badge. This can alert you and others to potential issues with authenticity.

The author and committer of a Git commit can easily be spoofed. For example, someone can push a commit that claims to be from you, but isn’t. Like showing a passport, committers can increase trust in their commits by signing them with a GPG or S/MIME key. And now, when you enable **vigilant mode**, commits will be flagged if they’re attributed to you but not signed by you. This raises attention if someone tries to spoof your identity as a committer or author. With vigilant mode enabled, all of your commits and tags are marked with one of three verification statuses: **Verified**, **Partially verified**, or **Unverified**.

![Commits and tags are marked with one of three verification statuses](https://i0.wp.com/user-images.githubusercontent.com/1767415/116419252-df094c80-a80a-11eb-91c4-4b3b27330673.png?ssl=1)

Try it yourself! First, check out how to [automatically sign your commits](https://docs.github.com/en/github/authenticating-to-github/about-commit-signature-verification). Then, enable **vigilant mode** in your [account settings](https://github.com/settings/keys):

![Vigilant mode in GitHub.com personal account settings](https://i0.wp.com/user-images.githubusercontent.com/1767415/116419242-dca6f280-a80a-11eb-9ac1-2fc624ef5032.png?ssl=1)

Be sure to enable vigilant mode after you start signing your commits and tags. Once you enable it, any unsigned commits or tags that you push to GitHub.com will be marked "Unverified," including past commits.

Learn more about [vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).