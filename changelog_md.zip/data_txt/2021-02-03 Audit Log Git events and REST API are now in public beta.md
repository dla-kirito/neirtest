February 3, 2021 

In December 2020 we [announced](https://github.blog/changelog/2020-12-10-audit-log-git-events-and-rest-api-now-available-in-limited-public-beta/) a limited beta of the new Audit Log Git events and REST API. We have now enabled these features in beta for all GitHub Enterprise Cloud customers. Your enterprise and organization administrators can now call the REST API and view Git events without needing to request access to the beta. 

To get started, check out our [Audit Log REST API](https://docs.github.com/en/free-pro-team@latest/github/setting-up-and-managing-organizations-and-teams/reviewing-the-audit-log-for-your-organization#using-the-rest-api) documentation. Note, Git events can only be viewed via the REST API or the Git events export button. 