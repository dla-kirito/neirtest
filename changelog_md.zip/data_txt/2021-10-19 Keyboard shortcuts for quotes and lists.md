October 19, 2021 

We've added keyboard shortcuts for quotes and lists in Markdown files, issues, PRs and comments.

To add quotes, use `cmd+shift+.` on Mac or `ctrl+shift+.` on Windows/Linux.  
To add an ordered list, use `cmd+shift+7` on Mac or `ctrl+shift+7` on Windows/Linux.  
To add an unordered list, use `cmd+shift+8` on Mac or `ctrl+shift+8` on Windows/Linux.

![Keyboard shortcuts](https://i0.wp.com/user-images.githubusercontent.com/8298818/133597156-c9070dd2-e963-4cdf-bbfa-8d7809cdfe2e.gif?ssl=1)

For a full list of all our keyboard shortcuts, see our [docs](https://docs.github.com/en/get-started/using-github/keyboard-shortcuts).