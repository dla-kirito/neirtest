July 2, 2020 

Dependabot can now keep your GitHub Actions workflows using the latest, greatest, and most secure actions.

Check out [the full blog post](https://github.blog/2020-06-25-dependabot-now-updates-your-actions-workflows/) to learn more.