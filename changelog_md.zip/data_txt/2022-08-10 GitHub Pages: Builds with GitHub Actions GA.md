August 10, 2022 

GitHub Pages now builds with GitHub Actions by default across all repositories.

For more details, see [this blog post](https://github.blog/2022-08-10-github-pages-now-uses-actions-by-default).