May 25, 2021 

On GitHub today, half of all pull request review conversations are left unresolved prior to merging. Now it is easier for authors to discover unresolved comments from the conversations menu in the files changed tab.

![image](https://i0.wp.com/user-images.githubusercontent.com/60158644/118853796-ff1bb100-b888-11eb-82df-ee785a46a21b.png?ssl=1)

In addition to making it easier for you to discover conversations in your pull requests, a new branch protection option gives admins the ability to require all review conversations be resolved before the pull request can be merged. This helps ensure all review conversations are seen and addressed prior to merging.

![image](https://i0.wp.com/user-images.githubusercontent.com/60158644/118853667-d85d7a80-b888-11eb-86ed-26d6e3e88d12.png?ssl=1)

Both features are currently in beta. Let us know what you think: [give feedback](https://support.github.com/contact/feedback?category=prs-and-code-review&subject=Conversations+menu).